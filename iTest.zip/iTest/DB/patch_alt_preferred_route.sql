Prompt "Altering AQRVW_PREFERRED_ROUTE table"
Prompt "Adding premium_certified field".

alter table aqrvw_preferred_route add (PREMIUM_CERTIFIED  varchar2(1) default 'N');