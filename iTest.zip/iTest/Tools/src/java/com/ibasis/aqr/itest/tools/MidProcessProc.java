package com.ibasis.aqr.itest.tools;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.common.iTestConstants;
import com.ibasis.aqr.itest.datamanager.iTestDataManager;

public class MidProcessProc {
    private static final Log logger = LogFactory.getLog(MidProcessProc.class);
    private iTestDataManager dataMgr = null;

    public MidProcessProc() throws Exception {
        try {
            dataMgr = new iTestDataManager();
        } catch (Exception e) {
            throw e;
        }
    }

    public int midProcessProcCall() throws Exception {
        int retVal = -1;
        try {
            // call mid process.
            logger.info("midProcessProcCall(): Mid Process starting ...");
            retVal = dataMgr.genMidProcess();

            if (retVal == iTestConstants.MID_PROCESS_SUCCESS) {
                logger.info("midProcessProcCall(): Successfully completed Mid Process run!");
            } else {
                logger.error("midProcessProcCall(): Mid Process run failed generating results!");
            }
        } catch (Exception e) {
            throw e;
        }
        return retVal;
    }

    public static void main(String[] args) {
        try {
            MidProcessProc midprocessProc = new MidProcessProc();
            midprocessProc.midProcessProcCall();
        } catch (Exception e) {
            logger.error(e);
            System.exit(1);
        }
    }
}
