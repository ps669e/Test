/*
 * Created on July 10, 2008
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.ibasis.aqr.itest.domain;

import java.util.Map;

import com.ibasis.aqr.itest.config.iTestConfigManager;
import com.ibasis.aqr.itest.util.TimeUtils;

/**
 * @author jzhou
 *
 */
public class TimeOfDay implements Comparable {
    private RatePeriod ratePeriod;

    private int periodId;

    private String startTime;

    private String endTime;

    private int startWeekDay;

    private int endWeekDay;

    private int startTimeInSeconds = -1;

    private int endTimeInSeconds = -1;

    private int adjEndTimeInSeconds = -1;

    public TimeOfDay(int periodId, String st, String et, int swd, int ewd) {
        Map<Integer, RatePeriod> ratePeriods = (Map<Integer, RatePeriod>) iTestConfigManager.getInstance().getRatePeriods();
        ratePeriod = ratePeriods.get(periodId);
        this.periodId = periodId;
        startTime = st;
        endTime = et;
        startWeekDay = swd;
        endWeekDay = ewd;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public int getEndWeekDay() {
        return endWeekDay;
    }

    public void setEndWeekDay(int endWeekDay) {
        this.endWeekDay = endWeekDay;
    }

    public int getPeriodId() {
        return periodId;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public int getStartWeekDay() {
        return startWeekDay;
    }

    public void setStartWeekDay(int startWeekDay) {
        this.startWeekDay = startWeekDay;
    }

    public String getPeriodCode() {
        return ratePeriod.getPeriodCode();
    }

    public String getPeriodDescription() {
        return ratePeriod.getDescription();
    }

    /**
     * compare start time, end time, start weekday and end weekday
     *
     * @param o
     * @return
     */
    @Override
    public int compareTo(Object o) {
        int retVal = 0;

        if (!(o instanceof TimeOfDay)) {
            throw new ClassCastException();
        }

        TimeOfDay otherTod = (TimeOfDay) o;

        // compare start time
        String time1 = this.getStartTime();
        String time2 = otherTod.getStartTime();
        if (time1 != null && time2 != null) {
            retVal = time1.compareTo(time2);
        } else if (time1 == null && time2 != null) {
            retVal = -1;
        } else if (time1 != null && time2 == null) {
            retVal = 1;
        }
        // compare end time
        if (retVal == 0) {
            time1 = this.getEndTime();
            time2 = otherTod.getEndTime();
            if (time1 != null && time2 != null) {
                retVal = time1.compareTo(time2);
            } else if (time1 == null && time2 != null) {
                retVal = -1;
            } else if (time1 != null && time2 == null) {
                retVal = 1;
            }
        }
        // compare start weekday
        if (retVal == 0) {
            retVal = this.getStartWeekDay() - otherTod.getStartWeekDay();
        }
        // compare end weekday
        if (retVal == 0) {
            retVal = this.getEndWeekDay() - otherTod.getEndWeekDay();
        }

        return retVal;
    }

    @Override
    public String toString() {
        String todString = getPeriodCode() + " " + startTime + " " + endTime;
        if (DomainConstants.NULL_VALUE != startWeekDay) {
            todString += " " + startWeekDay + " " + endWeekDay;
        }
        return todString;
    }

    public String toStringWithoutPeriod() {
        String todString = startTime + " " + endTime;
        if (DomainConstants.NULL_VALUE != startWeekDay) {
            todString += " " + startWeekDay + " " + endWeekDay;
        }
        return todString;
    }

    /**
     * start time in seconds.
     * if it is weekend or weekday, the start week day will be included
     *
     * @return
     */
    public int getStartTimeInSeconds() {
        if (startTimeInSeconds == -1) {
            computeStartStopTime();
        }
        return startTimeInSeconds;
    }

    public int getEndTimeInSeconds() {
        if (endTimeInSeconds == -1) {
            computeStartStopTime();
        }
        return endTimeInSeconds;
    }

    /**
     * end time in seconds relative to start time.
     * if it is weekend or weekday, the end week day will be included
     *
     * @return
     */
    public int getAdjEndTimeInSeconds() {
        if (adjEndTimeInSeconds == -1) {
            computeStartStopTime();
        }
        return adjEndTimeInSeconds;
    }

    /**
     * compute start time in seconds
     * compute end time in seconds relative to start time
     *
     * Case 1: end time > start time
     * start time 06:00:00 end time 18:00:00
     * becomes
     * start time = 6th hr ---> this will converted into seconds
     * adjusted end time = 18th hr ---> this will converted into seconds
     *
     * Case 2: end time < start time
     * start time 18:00:00 end time 06:00:00
     * becomes
     * start time = 18th hr ---> this will converted into seconds
     * adjusted end time = (end)6hr + (one day advanced 24hr) = 30th hr ---> this will converted into seconds
     *
     * For weekend/weekday
     *
     * Case 3: end week day > start week day and end time > start time
     * start Mon 06:00:00 end Fri 18:00:00
     * becomes
     * adjusted start time = Mon(1*24hr) + (start)6hr = 30th hr ---> this will converted into seconds
     * adjusted end time = Fri(5*24hr) + (end)18hr = 138th hr ---> this will converted into seconds
     *
     * Case 4: end week day < start week day; end time < start time
     * start Fri 18:00:00 end Mon 06:00:00
     * becomes
     * adjusted start time = Fri(5*24hr) + (start)18hr = 138th hr ---> this will converted into seconds
     * adjusted end time = Mon(1*24hr) + one week advanced(7*24hr) + (end)6hr + (one day advanced)24hr = 222th hr ---> this will converted into seconds
     */
    private void computeStartStopTime() {
        this.startTimeInSeconds = TimeUtils.time2Seconds(this.startTime);
        this.endTimeInSeconds = TimeUtils.time2Seconds(this.endTime);
        this.adjEndTimeInSeconds = TimeUtils.time2Seconds(this.endTime);
        if (DomainConstants.RMS_WEEKEND_PERIOD_ID == this.periodId || DomainConstants.RMS_WEEKDAY_PERIOD_ID == this.periodId) {
            //add start/end week day (in seconds) to start/end time
            int startWeekDayInSeconds = this.startWeekDay * DomainConstants.ONE_DAY;
            if (this.startWeekDay == 0) {
                // add 1 week to Sunday to make Sunday the 7th day instead of 1st day of week
                startWeekDayInSeconds += DomainConstants.ONE_WEEK;
            }
            int endWeekDayInSeconds = this.endWeekDay * DomainConstants.ONE_DAY;
            this.endTimeInSeconds += endWeekDayInSeconds;
            if (this.endWeekDay == 0) {
                // add 1 week to Sunday to make Sunday the 7th day instead of 1st day of week
                endWeekDayInSeconds += DomainConstants.ONE_WEEK;
                this.endTimeInSeconds += endWeekDayInSeconds;
            }
            if (endWeekDayInSeconds < startWeekDayInSeconds) {
                endWeekDayInSeconds += DomainConstants.ONE_WEEK;
            }
            this.startTimeInSeconds += startWeekDayInSeconds;
            this.adjEndTimeInSeconds += endWeekDayInSeconds;

            // Special handling for weekend / weekday
            //   need to add ONE_DAY to weekend/weekday start/end time if it is "23:59:59" since time2Seconds
            //   method converted "23:59:59" to "00:00:00" which cause one day lost
            String defaultEndTime = iTestConfigManager.getInstance().getTodDefaultWeekDayStopTime();
            if (this.startTime.equals(defaultEndTime)) {
                this.startTimeInSeconds += DomainConstants.ONE_DAY;
            }
            if (this.endTime.equals(defaultEndTime)) {
                this.adjEndTimeInSeconds += DomainConstants.ONE_DAY;
                this.endTimeInSeconds += DomainConstants.ONE_DAY;
            }
        }
        if (this.adjEndTimeInSeconds < this.startTimeInSeconds) {
            this.adjEndTimeInSeconds += DomainConstants.ONE_DAY; // add 24 hours to end time
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof TimeOfDay)) {
            return false;
        }
        TimeOfDay otherTod = (TimeOfDay) obj;
        return this.periodId == otherTod.periodId && this.compareTo(obj) == 0;
    }

    @Override
    public int hashCode() {
        return Integer.valueOf(this.periodId).hashCode() + this.startTime.hashCode() + this.endTime.hashCode() + Integer.valueOf(this.startWeekDay).hashCode()
                + Integer.valueOf(this.endWeekDay).hashCode();
    }
}
