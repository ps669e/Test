package com.ibasis.aqr.itest.rulesengine;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.common.iTestConstants;
import com.ibasis.aqr.itest.common.iTestConstants.TestProduct;
import com.ibasis.aqr.itest.config.iTestConfigManager;
import com.ibasis.aqr.itest.datamanager.iTestDataManager;
import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.domain.DialPattern;
import com.ibasis.aqr.itest.domain.FloorRate;
import com.ibasis.aqr.itest.domain.PreferredRoute;
import com.ibasis.aqr.itest.domain.Product;
import com.ibasis.aqr.itest.domain.ProviderCoverage;
import com.ibasis.aqr.itest.domain.RouteClassification;
import com.ibasis.aqr.itest.domain.TestRule;
import com.ibasis.aqr.itest.domain.iTestVendor;
import com.ibasis.aqr.itest.domain.comparator.VendorRateComparator;

/**
 * @author schan
 *
 */
public class EligibilityRules implements iTestRules {
    private static final Log log = LogFactory.getLog(EligibilityRules.class);

    private iTestDataManager dataMgr;
    private iTestConfigManager configMgr = iTestConfigManager.getInstance();

    public EligibilityRules(iTestDataManager dataMgr) throws Exception {
        this.dataMgr = dataMgr;
    }

    @Override
    public void applyRulesOnCountry(Collection<Country> countries) throws Exception {
        try {
            if (countries != null) {
                for (Country country : countries) {
                    if (!country.isExcluded()) {
                        applyRulesOnCountry(country);
                    } else {
                        log.info("applyRulesOnCountry(): Country " + country.getName() + " excluded");
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception in applyRulesOnCountry(Collection): " + e.toString());
            throw e;
        }
    }

    @Override
    public void applyRulesOnCountry(Country country) throws Exception {
        if (country != null) {
            applyRulesOnPreferredRoute(country.getPreferredRoutes());
        } else {
            log.error("applyRulesOnCountry(Country): Null input!");
        }
    }

    @Override
    public void applyRulesOnPreferredRoute(Collection<PreferredRoute> prefRoutes) throws Exception {
        try {
            if (prefRoutes != null) {
                for (PreferredRoute prefRoute : prefRoutes) {
                    applyRulesOnPreferredRoute(prefRoute);
                }
            }
        } catch (Exception e) {
            log.error("Exception in applyRulesOnPreferredRoute(Collection): " + e.toString());
            throw e;
        }
    }

    @Override
    public void applyRulesOnPreferredRoute(PreferredRoute prefRoute) throws Exception {
        if (prefRoute != null) {
            log.info("applyRulesOnPreferredRoute() Applying vendor eligibility rules for preferred route " + prefRoute.getName());
            aggregateVendorPRStats(prefRoute);
            determineTestEligibility(prefRoute);
        } else {
            log.error("applyRulesOnPreferredRoute(PreferredRoute): Null input!");
        }
    }

    private void aggregateVendorPRStats(PreferredRoute prefRoute) {
        List<DialPattern> patterns = prefRoute.getDialPatterns();
        Collections.sort(patterns);

        for (DialPattern dp : patterns) {
            List<ProviderCoverage> pcvgs = dp.getPatternRoutingChoices();

            if (pcvgs != null) {
                for (ProviderCoverage pcvg : pcvgs) {
                    iTestVendor itestVendor = prefRoute.getiTestVendor(pcvg.getProvider());
                    if (itestVendor == null) {
                        itestVendor = new iTestVendor(prefRoute, pcvg.getProvider());
                        itestVendor.setMaxCost(pcvg.getCost());
                        itestVendor.setMaxNetCost(pcvg.getMaxNetCost());
                        prefRoute.addiTestVendor(itestVendor);
                    } else {
                        // test vendor exist, update its preferred route level stats
                        // record max cost and net cost among all PR patterns
                        if (pcvg.getCost() > itestVendor.getMaxCost()) {
                            itestVendor.setMaxCost(pcvg.getCost());
                        }
                        if (pcvg.getMaxNetCost() > itestVendor.getMaxNetCost()) {
                            itestVendor.setMaxNetCost(pcvg.getMaxNetCost());
                        }
                    }

                    if (pcvg.isNewPattern()) {
                        // If any dp is new, set the needTesting flag on preferred route leve.
                        // Whether to block or test the vendor is based on determineTestEligibility() logic
                        itestVendor.setHasNewPattern(true);
                    }
                }
            }
        }
    }

    private void determineTestEligibility(PreferredRoute prefRoute) throws Exception {
        List<iTestVendor> eligiblePvTestVendors = new ArrayList<>();
        List<iTestVendor> eligibleCvTestVendors = new ArrayList<>();

        for (iTestVendor itestVendor : prefRoute.getiTestVendors()) {

            // determine the test product (PV or CV)
            TestProduct testProduct = null;
            TestRule testRule = null;
            if (itestVendor.hasRequestedPvTesting()) {
                // vendor requested PV test
                testProduct = TestProduct.PV;
                testRule = dataMgr.getTestRule(iTestConstants.RULE_PV_TEST, itestVendor.getRouteStatusPv(), itestVendor.getRouteStatusCv());
            } else if (itestVendor.hasRequestedCvTesting() && !itestVendor.hasRequestedPvTesting()) {
                // vendor requested CV test
                testProduct = TestProduct.CV;
                testRule = dataMgr.getTestRule(iTestConstants.RULE_CV_TEST, itestVendor.getRouteStatusPv(), itestVendor.getRouteStatusCv());
            } else if (itestVendor.hasNewPattern() && !itestVendor.hasCvStatus() && !itestVendor.hasPvStatus()) {
                // Vendor has brand new patterns for preferred route, block it for All Customers, eligible for CV test if its rate and SLBR are good
                testProduct = TestProduct.CV;
                testRule = dataMgr.getTestRule(iTestConstants.RULE_NEW_PATTERN, null, null);
            } else if (itestVendor.hasPvStatus() && itestVendor.isNonRoutablePv() && itestVendor.hasCvStatus() && itestVendor.isNonRoutableCv()) {
                testRule = dataMgr.getTestRule(iTestConstants.RULE_NON_ROUTABLE, itestVendor.getRouteStatusPv(), itestVendor.getRouteStatusCv());
            }

            itestVendor.setTestRule(testRule);

            if (!itestVendor.isTgInService()) {
                // If vendor is OOS, here is how to handle "TG OOS"'s gcs_block_group_id / gcs_test_group_id
                //   - "TG OOS" record not exist                  -> no overriding
                //   - NULL gcs_block_group_id/gcs_test_group_id  -> no overriding
                //   - Non NULL                                   -> override (see below cases)
                //     -- empty -> do not block/test
                //     -- >=1   -> block/test according to gcs_block_group_id / gcs_test_group_id
                testRule = dataMgr.getTestRule(iTestConstants.RULE_TG_OOS, null, null);
                if (testRule != null && (testRule.hasBlockGroups() || testRule.hasTestGroups())) {
                    testProduct = null; // OOS vendor is not eligible for PV or CV testing
                    itestVendor.setTestRule(testRule);
                }
            }

            itestVendor.setTestProduct(testProduct);

            // Not eligible for testing without a SLBR. No need to block as GCS will not send traffic to vendor without a valid SLBR.
            Integer vendorSlbr = itestVendor.getSlbr();
            if (vendorSlbr != null) {
                // If there is no SLBR group floor (PV floor missing as well), do not allow testing
                FloorRate maxFloor = getMaxFloorRateBySlbr(dataMgr, vendorSlbr, prefRoute);
                if (maxFloor != null) {
                    itestVendor.setMaxFloorRate(maxFloor);

                    // vendor is not eligible for test if any of the following conditions is true
                    //   It is TG OOS
                    //   It already has routable CV and PV status
                    //   It is non-routable for PV and CV
                    //   Its SRC is not eligible for testing
                    //   Its rate is >= floor
                    if (!itestVendor.isTgInService()) {
                        continue;
                    }
                    if (itestVendor.isRoutablePv() && itestVendor.isRoutableCv()) {
                        continue;
                    }
                    if (itestVendor.hasPvStatus() && itestVendor.isNonRoutablePv() && itestVendor.hasCvStatus() && itestVendor.isNonRoutableCv()) {
                        continue;
                    }
                    if (itestVendor.getTestProduct() == null) {
                        continue;
                    }

                    RouteClassification vendorSrc = itestVendor.getSrc();
                    if (vendorSrc != null && vendorSrc.getSlbr() != vendorSlbr) {
                        // vendor SRC and SLBR does not match
                        continue;
                    }

                    // PV test - SRC PV or above (configurable)
                    // CV test - SRC CV or above (configurable)
                    if (!isTestAllowedBySrc(itestVendor, testProduct)) {
                        continue;
                    }

                    // PV test - SLBR 400 or above (configurable)
                    // CV test - SLBR 300 or above (configurable)
                    int minSlbr = configMgr.getMinSlbr(testProduct);
                    if (vendorSlbr < minSlbr) {
                        continue;
                    }

                    // Vendor cost must less than max SLBR group floor
                    double cost = itestVendor.getMaxCost();
                    if (cost < maxFloor.getFloorRate()) {
                        // Vendor passed all eligibility rules, add it to test bucket
                        itestVendor.setPassedEligibilityTest(true);

                        if (testProduct == TestProduct.PV) {
                            eligiblePvTestVendors.add(itestVendor);
                        } else {
                            eligibleCvTestVendors.add(itestVendor);
                        }
                    }
                }
            }
        } //for (iTestVendor itestVendor : itestVendors)

        // Sort all eligible test vendors by least cost, and put first 2 vendors to GCS test
        setGcsTestVendors(eligiblePvTestVendors);
        setGcsTestVendors(eligibleCvTestVendors);
    }

    /**
     * Per preferred route, per test product, add 2 vendors (based on LCR) to GCS and set 200 offers to each test vendor
     *
     * @param eligibleTestVendors
     * @throws Exception
     */
    private void setGcsTestVendors(List<iTestVendor> eligibleTestVendors) throws Exception {
        if (!eligibleTestVendors.isEmpty()) {
            // sort vendors by LCR
            Collections.sort(eligibleTestVendors, new VendorRateComparator(iTestConstants.COST));

            // add first 2 test vendors (configurable) to GCS and allocate each vendor 200 offers (configurable)
            int numTestVendors = configMgr.getNumTestVendors();
            int numTestOffers = configMgr.getNumTestOffers();

            int priority = 1;
            for (iTestVendor testVendor : eligibleTestVendors) {
                if (numTestVendors > 0) {
                    //Set<VoiceCarrierGroup> gcsTestGroups = dataMgr.getVoiceCarrierGroupsByTestProduct(testVendor.getTestProduct());
                    //testVendor.addGcsTestGroups(gcsTestGroups);
                    testVendor.setTestOffers(numTestOffers);
                    testVendor.setPriority(priority++);
                    numTestVendors--;
                } else {
                    break;
                }
            }
        }
    }

    /**
     * configuration: itvw_gcs_src_test_inclusion
     *
     * @param itestVendor
     * @param testProduct
     * @return
     */
    private boolean isTestAllowedBySrc(iTestVendor itestVendor, TestProduct testProduct) {
        boolean ret = false;
        if (configMgr.isEligibilitySrcCheck()) {
            RouteClassification vendorSrc = itestVendor.getSrc();
            if (vendorSrc != null) {
                if (testProduct == TestProduct.PV && vendorSrc.isAllowPvTesting() || testProduct == TestProduct.CV && vendorSrc.isAllowCvTesting()) {
                    ret = true;
                }
            }
        } else {
            return true;
        }
        return ret;
    }

    /**
     * Return the max product group floor rate based on SLBR
     *
     * @param dataMgr
     * @param slbr
     * @return
     */
    private FloorRate getMaxFloorRateBySlbr(iTestDataManager dataMgr, Integer slbr, PreferredRoute prefRoute) {
        FloorRate maxFloor = null;
        Set<Product> floorProducts = dataMgr.getSlbrFloorProducts(slbr);
        if (floorProducts == null || floorProducts.isEmpty()) {
            //default to PV floor
            log.error("getMaxFloorRateBySlbr(): product floor group not defined for SLBR " + slbr + ". Default to PV floor");
            floorProducts = new HashSet<>(1);
            floorProducts.add(dataMgr.getPvProduct());
        }

        for (Product product : floorProducts) {
            FloorRate floor = prefRoute.getFloorRateByProduct(product);
            if (floor == null && product.getProductId() != iTestConstants.PRODUCT_ID_PV) {
                floor = prefRoute.getFloorRateByProduct(dataMgr.getPvProduct());
            }
            if (floor != null) {
                if (maxFloor == null || (maxFloor != null && floor.getFloorRate() > maxFloor.getFloorRate())) {
                    maxFloor = floor;
                }
            }
        }
        return maxFloor;
    }

}
