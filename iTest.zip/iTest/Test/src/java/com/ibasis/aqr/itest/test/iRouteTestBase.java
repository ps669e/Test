package com.ibasis.aqr.itest.test;

import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.ibasis.aqr.itest.config.iTestConfigManager;
import com.ibasis.aqr.itest.domain.DomainConstants;
import com.ibasis.aqr.itest.domain.RatePeriod;

public abstract class iRouteTestBase extends TestCase {
	protected static final int P = DomainConstants.RMS_PEAK_PERIOD_ID;
	protected static final int O = DomainConstants.RMS_OFFPEAK_PERIOD_ID;
	protected static final int W = DomainConstants.RMS_WEEKEND_PERIOD_ID;
	protected static final int D = DomainConstants.RMS_WEEKDAY_PERIOD_ID;
	protected static final int NULL_VALUE = DomainConstants.NULL_VALUE;

	protected static iTestConfigManager iRouteConfigMgr = iTestConfigManager.getInstance();

	protected void setUp() throws Exception {
		super.setUp();
		
		Map<Integer, RatePeriod> ratePeriods = new HashMap<Integer, RatePeriod>();
		ratePeriods.put(P, new RatePeriod(P, "P", "Peak"));
		ratePeriods.put(O, new RatePeriod(O, "O", "Off-Peak"));
		ratePeriods.put(W, new RatePeriod(W, "W", "Weekend"));
		ratePeriods.put(D, new RatePeriod(D, "D", "Weekday"));
		
		iRouteConfigMgr.setRatePeriods(ratePeriods);
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

}
