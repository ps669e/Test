/*
 * Created on Sep 7, 2004
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.ibasis.aqr.itest.domain;

/**
 *
 * Domain class representign floor rate.
 *
 * @author csib
 */
public class FloorRate {

    private Product product; //Which product the floor rate is for

    private double floorRate;

    public FloorRate(double floorRate) {
        this.floorRate = floorRate;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public double getFloorRate() {
        return floorRate;
    }

    public void setFloorRate(double floorRate) {
        this.floorRate = floorRate;
    }

    @Override
    public String toString() {
        return "" + this.floorRate;
    }
}
