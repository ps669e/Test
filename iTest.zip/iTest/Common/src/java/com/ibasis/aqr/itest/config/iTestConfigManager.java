package com.ibasis.aqr.itest.config;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.common.iTestConstants.TestProduct;
import com.ibasis.aqr.itest.db.DBConnection;
import com.ibasis.aqr.itest.util.AQRPropertyReader;

/**
 * iTestConfigManager is responsible for loading default values table, or other configuration.
 * It may also be used as a wrapper to AQRPropertyReader in the future.
 *
 * @author schan
 *
 */
public final class iTestConfigManager {
    private static final Log logger = LogFactory.getLog(iTestConfigManager.class);

    private static iTestConfigManager instance = null;

    private static Map<String, Boolean> configurations = new HashMap<>();

    private static Map<String, String> defaultValues = new HashMap<>();

    // configuration defined in DEFAULT_VALUES table
    private static final String TOD_DEFAULT_WD_START_TIME = "TOD_DEFAULT_WD_START_TIME";
    private static final String TOD_DEFAULT_WD_STOP_TIME = "TOD_DEFAULT_WD_STOP_TIME";
    private static final String TOD_WEIGHTED_AVERAGE_PER = "TOD_WEIGHTED_AVERAGE_PER";

    private static Object ratePeriods = null; // Map<Integer, RatePeriod>

    public static final String PROP_PROPERTY_CHECK_ENANBLED = "PROPERTY_CHECK_ENANBLED";
    public static final String PROP_CONSOLE_TIME_OUT_SECONDS = "CONSOLE_TIME_OUT_SECONDS";
    public static final String PROP_PRE_PROCESS_ENABLED = "PRE_PROCESS_ENABLED";
    public static final String PROP_MID_PROCESS_ENABLED = "MID_PROCESS_ENABLED";
    public static final String PROP_POST_PROCESS_ENABLED = "POST_PROCESS_ENABLED";
    public static final String PROP_ITEST_VENDOR_REPORT_ENABLED = "ITEST_VENDOR_REPORT_ENABLED";
    public static final String PROP_OUTPUT_ENABLED = "OUTPUT_ENABLED";
    public static final String PROP_DECRYPT_DB_PASSWORD = "DECRYPT_DB_PASSWORD";
    public static final String PROP_PENDING_ACTIVE_PV_FLOOR_CHECK = "PENDING_ACTIVE_PV_FLOOR_CHECK";
    public static final String PROP_ELIGIBILITY_SRC_CHECK = "ELIGIBILITY_SRC_CHECK";

    /**
     * Dynamic Routing
     */
    public static final String NUM_OF_TEST_VENDORS = "MAIN_NUM_OF_TEST_VENDORS";
    public static final String NUM_OF_TEST_OFFERS = "MAIN_NUM_OF_TEST_OFFERS";
    public static final int DEFAULT_NUM_OF_TEST_VENDORS = 2;
    public static final int DEFAULT_NUM_OF_TEST_OFFERS = 200;

    public static final String CV_TEST_MIN_SLBR = "MAIN_CV_TEST_MIN_SLBR";
    public static final String PV_TEST_MIN_SLBR = "MAIN_PV_TEST_MIN_SLBR";
    public static final int DEFAULT_CV_TEST_MIN_SLBR = 300;
    public static final int DEFAULT_PV_TEST_MIN_SLBR = 400;

    public static final String CV_TEST_PM_TRAFFIC_GROUP = "MAIN_CV_TEST_PM_TRAFFIC_GROUP";
    public static final String PV_TEST_PM_TRAFFIC_GROUP = "MAIN_PV_TEST_PM_TRAFFIC_GROUP";
    public static final int DEFAULT_CV_TEST_PM_TRAFFIC_GROUP = 1;
    public static final int DEFAULT_PV_TEST_PM_TRAFFIC_GROUP = 2;

    private static long consoleTimeoutSeconds = 300;

    private iTestConfigManager() {
    }

    public static iTestConfigManager getInstance() {
        if (instance == null) {
            instance = new iTestConfigManager();

            //default values
            configurations.put(PROP_PRE_PROCESS_ENABLED, true);
            configurations.put(PROP_POST_PROCESS_ENABLED, true);
            configurations.put(PROP_OUTPUT_ENABLED, true);
            configurations.put(PROP_MID_PROCESS_ENABLED, true);
            configurations.put(PROP_ITEST_VENDOR_REPORT_ENABLED, true);
            configurations.put(PROP_DECRYPT_DB_PASSWORD, true);
            configurations.put(PROP_PROPERTY_CHECK_ENANBLED, true);
            configurations.put(PROP_PENDING_ACTIVE_PV_FLOOR_CHECK, true);
            configurations.put(PROP_ELIGIBILITY_SRC_CHECK, false);
            loadConfigurations(); // load override values
            loadDefaultValues(); // load from default_values table
        }
        return instance;
    }

    private static void loadConfigurations() {
        if (AQRPropertyReader.getProperty(PROP_CONSOLE_TIME_OUT_SECONDS) != null) {
            consoleTimeoutSeconds = Long.parseLong(AQRPropertyReader.getProperty(PROP_CONSOLE_TIME_OUT_SECONDS));
        }
        if (AQRPropertyReader.getProperty(PROP_PRE_PROCESS_ENABLED) != null
                && AQRPropertyReader.getProperty(PROP_PRE_PROCESS_ENABLED).equalsIgnoreCase("false")) {
            configurations.put(PROP_PRE_PROCESS_ENABLED, Boolean.FALSE);
        }
        if (AQRPropertyReader.getProperty(PROP_POST_PROCESS_ENABLED) != null
                && AQRPropertyReader.getProperty(PROP_POST_PROCESS_ENABLED).equalsIgnoreCase("false")) {
            configurations.put(PROP_POST_PROCESS_ENABLED, Boolean.FALSE);
        }
        if (AQRPropertyReader.getProperty(PROP_OUTPUT_ENABLED) != null && AQRPropertyReader.getProperty(PROP_OUTPUT_ENABLED).equalsIgnoreCase("false")) {
            configurations.put(PROP_OUTPUT_ENABLED, Boolean.FALSE);
        }
        if (AQRPropertyReader.getProperty(PROP_MID_PROCESS_ENABLED) != null
                && AQRPropertyReader.getProperty(PROP_MID_PROCESS_ENABLED).equalsIgnoreCase("false")) {
            configurations.put(PROP_MID_PROCESS_ENABLED, Boolean.FALSE);
        }
        if (AQRPropertyReader.getProperty(PROP_ITEST_VENDOR_REPORT_ENABLED) != null
                && AQRPropertyReader.getProperty(PROP_ITEST_VENDOR_REPORT_ENABLED).equalsIgnoreCase("false")) {
            configurations.put(PROP_ITEST_VENDOR_REPORT_ENABLED, Boolean.FALSE);
        }
        if (AQRPropertyReader.getProperty(PROP_DECRYPT_DB_PASSWORD) != null
                && AQRPropertyReader.getProperty(PROP_DECRYPT_DB_PASSWORD).equalsIgnoreCase("false")) {
            configurations.put(PROP_DECRYPT_DB_PASSWORD, Boolean.FALSE);
        }
        if (AQRPropertyReader.getProperty(PROP_PROPERTY_CHECK_ENANBLED) != null
                && AQRPropertyReader.getProperty(PROP_PROPERTY_CHECK_ENANBLED).equalsIgnoreCase("false")) {
            configurations.put(PROP_PROPERTY_CHECK_ENANBLED, Boolean.FALSE);
        }
        if (AQRPropertyReader.getProperty(PROP_PENDING_ACTIVE_PV_FLOOR_CHECK) != null
                && AQRPropertyReader.getProperty(PROP_PENDING_ACTIVE_PV_FLOOR_CHECK).equalsIgnoreCase("false")) {
            configurations.put(PROP_PENDING_ACTIVE_PV_FLOOR_CHECK, Boolean.FALSE);
        }
        if (AQRPropertyReader.getProperty(PROP_ELIGIBILITY_SRC_CHECK) != null
                && AQRPropertyReader.getProperty(PROP_ELIGIBILITY_SRC_CHECK).equalsIgnoreCase("true")) {
            configurations.put(PROP_ELIGIBILITY_SRC_CHECK, Boolean.TRUE);
        }
    }

    private static void loadDefaultValues() {
        String defaultValuesSql = "select NAME, VALUE from ITEST_DEFAULT_VALUES where NAME like 'MAIN_%'";
        DBConnection dbConnection = new DBConnection();
        Statement stmt = null;
        ResultSet rs = null;
        Connection con = null;
        try {
            con = dbConnection.getRMSConnection();
            if (con != null) {
                stmt = con.createStatement();
                logger.info("loadDefaultValues(): Executing load default values query...");
                rs = stmt.executeQuery(defaultValuesSql);
                logger.info("loadDefaultValues(): Load default values query done");
                while (rs.next()) {
                    defaultValues.put(rs.getString(1), rs.getString(2));
                }
            }
        } catch (Exception e) {
            logger.error("loadDefaultValues(): Exception in loadDefaultValues(). ", e);
            throw new RuntimeException("Exception in loadDefaultValues().");
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Map<String, String> getDefaultValues() {
        return defaultValues;
    }

    public String getDefaultValue(String defaultKey) {
        return defaultValues.get(defaultKey);
    }

    public String getTodDefaultWeekDayStartTime() {
        String value = getDefaultValue(TOD_DEFAULT_WD_START_TIME);
        if (value != null) {
            return value;
        }
        return "00:00:00";
    }

    public String getTodDefaultWeekDayStopTime() {
        String value = getDefaultValue(TOD_DEFAULT_WD_STOP_TIME);
        if (value != null) {
            return value;
        }
        return "23:59:59";
    }

    /**
     * Get TOD_WEIGHTED_AVERAGE_PER from default_values.
     * Default to 0% if TOD_WEIGHTED_AVERAGE_PER not defined.
     *
     * @return
     */
    public int getTodWeightedAvgPercentage() {
        int percentage = 0;
        String value = getDefaultValue(TOD_WEIGHTED_AVERAGE_PER);
        if (value != null && value.length() > 0) {
            try {
                percentage = Integer.parseInt(value);
            } catch (NumberFormatException e) {
                percentage = 0;
                logger.error("getTodWeightedAvgPercentage(): " + TOD_WEIGHTED_AVERAGE_PER + " is not a number. 0% will be used.");
            }
        } else {
            logger.error("getTodWeightedAvgPercentage(): " + TOD_WEIGHTED_AVERAGE_PER + " not defined in default_values. 0% will be used.");
        }
        return percentage;
    }

    /**
     *
     * @param ratePeriods Map<Integer, RatePeriod>
     */
    public void setRatePeriods(Object ratePeriods) {
        iTestConfigManager.ratePeriods = ratePeriods;
    }

    /**
     *
     * @return Map<Integer, RatePeriod>
     */
    public Object getRatePeriods() {
        return ratePeriods;
    }

    public boolean isDecryptDbPwd() {
        return configurations.get(PROP_DECRYPT_DB_PASSWORD);
    }

    public boolean isDoOutput() {
        return configurations.get(PROP_OUTPUT_ENABLED);
    }

    public boolean isPreProcessEnabled() {
        return configurations.get(PROP_PRE_PROCESS_ENABLED);
    }

    public boolean isMidProcessEnabled() {
        return configurations.get(PROP_MID_PROCESS_ENABLED);
    }

    public boolean isPostProcessEnabled() {
        return configurations.get(PROP_POST_PROCESS_ENABLED);
    }

    public boolean isITestVendorReportEnabled() {
        return configurations.get(PROP_ITEST_VENDOR_REPORT_ENABLED);
    }

    public boolean isPropertyCheckEnabled() {
        return configurations.get(PROP_PROPERTY_CHECK_ENANBLED);
    }

    public boolean isPendingActivePvFloorCheck() {
        return configurations.get(PROP_PENDING_ACTIVE_PV_FLOOR_CHECK);
    }

    public boolean isEligibilitySrcCheck() {
        return configurations.get(PROP_ELIGIBILITY_SRC_CHECK);
    }

    @Override
    public String toString() {
        StringBuffer buf = new StringBuffer("\n[iTest Configuration]");
        for (String parameter : configurations.keySet()) {
            buf.append("\n  ").append(parameter).append("=").append(configurations.get(parameter));
        }

        buf.append("\n[DEFAULT_VALUES]");
        for (String parameter : defaultValues.keySet()) {
            buf.append("\n  ").append(parameter).append("=").append(defaultValues.get(parameter));
        }
        return buf.toString();
    }

    public static Map<String, Boolean> getConfigurations() {
        return configurations;
    }

    public static void setConfigurations(Map<String, Boolean> configurations) {
        iTestConfigManager.configurations = configurations;
    }

    public long getConsoleTimeoutSeconds() {
        return consoleTimeoutSeconds;
    }

    /**
     * Return the number of test vendors allowed for GCS testing.
     *
     * @return
     *         Return 2 if MAIN_NUM_OF_TEST_VENDORS is not defined or is not a number, or it is < 0
     */
    public int getNumTestVendors() {
        int numTestVendors = DEFAULT_NUM_OF_TEST_VENDORS;
        String value = getDefaultValue(NUM_OF_TEST_VENDORS);
        if (value != null && value.length() > 0) {
            try {
                numTestVendors = Integer.parseInt(value);
                if (numTestVendors < 0) {
                    numTestVendors = DEFAULT_NUM_OF_TEST_VENDORS;
                }
            } catch (NumberFormatException e) {
                numTestVendors = DEFAULT_NUM_OF_TEST_VENDORS;
                logger.error("getNumTestVendors(): " + NUM_OF_TEST_VENDORS + " is not a number. Default to " + DEFAULT_NUM_OF_TEST_VENDORS);
            }
        } else {
            logger.error("getNumTestVendors(): " + NUM_OF_TEST_VENDORS + " not defined in itest_default_values. Default to " + DEFAULT_NUM_OF_TEST_VENDORS);
        }
        return numTestVendors;
    }

    /**
     * Return the test offers to be allocated to test vendor.
     *
     * @return
     *         Return 200 if MAIN_NUM_OF_TEST_OFFERS is not defined or is not a number, or it is < 0
     */
    public int getNumTestOffers() {
        int numTestOffers = DEFAULT_NUM_OF_TEST_OFFERS;
        String value = getDefaultValue(NUM_OF_TEST_OFFERS);
        if (value != null && value.length() > 0) {
            try {
                numTestOffers = Integer.parseInt(value);
                if (numTestOffers < 0) {
                    numTestOffers = DEFAULT_NUM_OF_TEST_OFFERS;
                }
            } catch (NumberFormatException e) {
                numTestOffers = DEFAULT_NUM_OF_TEST_OFFERS;
                logger.error("getNumTestOffers(): " + NUM_OF_TEST_OFFERS + " is not a number. Default to " + DEFAULT_NUM_OF_TEST_OFFERS);
            }
        } else {
            logger.error("getNumTestOffers(): " + NUM_OF_TEST_OFFERS + " not defined in itest_default_values. Default to " + DEFAULT_NUM_OF_TEST_OFFERS);
        }
        return numTestOffers;
    }

    public int getMinSlbr(TestProduct testProduct) {
        int minSlbr = (testProduct == TestProduct.PV ? DEFAULT_PV_TEST_MIN_SLBR : DEFAULT_CV_TEST_MIN_SLBR);
        String key = (testProduct == TestProduct.PV ? PV_TEST_MIN_SLBR : CV_TEST_MIN_SLBR);
        String value = getDefaultValue(key);
        if (value != null && value.length() > 0) {
            try {
                minSlbr = Integer.parseInt(value);
                if (minSlbr < 0) {
                    minSlbr = (testProduct == TestProduct.PV ? DEFAULT_PV_TEST_MIN_SLBR : DEFAULT_CV_TEST_MIN_SLBR);
                }
            } catch (NumberFormatException e) {
                minSlbr = (testProduct == TestProduct.PV ? DEFAULT_PV_TEST_MIN_SLBR : DEFAULT_CV_TEST_MIN_SLBR);
                logger.error("getMinSlbr(): " + key + " is not a number. Default to " + minSlbr);
            }
        } else {
            logger.error("getMinSlbr(): " + key + " not defined in itest_default_values. Default to " + minSlbr);
        }
        return minSlbr;
    }


    public int getPamTrafficGroup(TestProduct testProduct) {
        int pamTrafficGroup = (testProduct == TestProduct.PV ? DEFAULT_PV_TEST_PM_TRAFFIC_GROUP : DEFAULT_CV_TEST_PM_TRAFFIC_GROUP);
        String key = (testProduct == TestProduct.PV ? PV_TEST_PM_TRAFFIC_GROUP : CV_TEST_PM_TRAFFIC_GROUP);
        String value = getDefaultValue(key);
        if (value != null && value.length() > 0) {
            try {
                pamTrafficGroup = Integer.parseInt(value);
                if (pamTrafficGroup < 0) {
                    pamTrafficGroup = (testProduct == TestProduct.PV ? DEFAULT_PV_TEST_PM_TRAFFIC_GROUP : DEFAULT_CV_TEST_PM_TRAFFIC_GROUP);
                }
            } catch (NumberFormatException e) {
                pamTrafficGroup = (testProduct == TestProduct.PV ? DEFAULT_PV_TEST_PM_TRAFFIC_GROUP : DEFAULT_CV_TEST_PM_TRAFFIC_GROUP);
                logger.error("getPamTrafficGroup(): " + key + " is not a number. Default to " + pamTrafficGroup);
            }
        } else {
            logger.error("getPamTrafficGroup(): " + key + " not defined in itest_default_values. Default to " + pamTrafficGroup);
        }
        return pamTrafficGroup;
    }

}
