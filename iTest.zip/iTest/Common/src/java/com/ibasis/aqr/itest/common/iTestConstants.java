/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.common;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.util.AQRPropertyReader;

/**
 * @author schan
 *
 */
public final class iTestConstants {

    private static final Log logger = LogFactory.getLog(iTestConstants.class);
    public static final String PROPERTY_FILE = "itest.property";
    public static final String DATA_SOURCE = "data_source_config";
    public static final String RMS_DATA_SOURCE = "java:/rmsDS";
    public static final int ITEST_RUN_FAIL = -9;
    public static final int ITEST_RUN_SUCCESS = 0;
    public static final int PRE_PROCESS_SUCCESS = 0;
    public static final int RMS_RESULT_SUCCESS = 0;
    public static final int MID_PROCESS_SUCCESS = 0;
    public static final String VERSION_FILE = "version";

    //Sort Type
    public static final int NET_COST = 1;
    public static final int COST = 2;
    public static final int COLO = 3;
    public static final int lineup = 4;
    public static int RMS_QRY_TIMEOUT_MIN = -1; //Minutes
    public static int RATE_ROLLOVER_HOURS = -1;
    public static long PRODUCT_ID_CV = 3; //Certified Voice
    public static long PRODUCT_ID_PV = 301; //Premium Voice

    public static final int REG_WRITER = 1;
    public static final int ZIP_WRITER = 2;
    public static int WRITER_TYPE = REG_WRITER; //DIRECTS

    public static final String endl = System.getProperty("line.separator");

    public static int MID_PROCESS_TIMEOUT_MIN = -1; //Minutes

    public static String RULE_PV_TEST = "PV TEST";
    public static String RULE_CV_TEST = "CV TEST";
    public static String RULE_NEW_PATTERN = "NEW PATTERN";
    public static String RULE_TG_OOS = "TG OOS";
    public static String RULE_NON_ROUTABLE = "NON ROUTABLE";
    public static String RULE_NEW_PREFROUTE = "NON PREFROUTE";

    static {
        try {
            String strProp = AQRPropertyReader.getProperty("RMS_QRY_TIMEOUT_MIN");
            RMS_QRY_TIMEOUT_MIN = strProp != null ? Integer.parseInt(strProp) : RMS_QRY_TIMEOUT_MIN;
            strProp = AQRPropertyReader.getProperty("RATE_ROLLOVER_HOURS");
            RATE_ROLLOVER_HOURS = strProp != null ? Integer.parseInt(strProp) : RATE_ROLLOVER_HOURS;
            strProp = AQRPropertyReader.getProperty("WRITER_TYPE");
            WRITER_TYPE = strProp != null && strProp.equals("ZIP") ? ZIP_WRITER : WRITER_TYPE;
            strProp = AQRPropertyReader.getProperty("MID_PROCESS_TIMEOUT_MIN");
            MID_PROCESS_TIMEOUT_MIN = strProp != null ? Integer.parseInt(strProp) : MID_PROCESS_TIMEOUT_MIN;

        } catch (Exception ex) {
            logger.error("Exception in static block", ex);
        }
    }

    public enum TestProduct {
        // CV_CUSTOMER_PRODUCT_IDS, ALL_CUSTOMER_PRODUCT_IDS are itest.property
        CV(false, "CV_CUSTOMER_PRODUCT_IDS"), PV(true, "ALL_CUSTOMER_PRODUCT_IDS");

        private boolean isPremium;
        private String itestPropertyName;

        TestProduct(boolean isPremium, String itestPropertyName) {
            this.isPremium = isPremium;
            this.itestPropertyName = itestPropertyName;
        }

        public boolean isPremium() {
            return isPremium;
        }

        public String getiTestPropertyName() {
            return itestPropertyName;
        }
    }

    public enum GcsRule {
        B("B", "BLOCK"), T("T", "TEST");

        private String rule;
        private String description;

        GcsRule(String rule, String description) {
            this.rule = rule;
            this.description = description;
        }

        public String getRule() {
            return rule;
        }

        public String getDescription() {
            return description;
        }
    }

}
