alter table routes add (
is_blocked char(1) default 'N' 
constraint nn_is_blocked NOT NULL,
constraint ch_is_blocked check (is_blocked in ('Y','N'))
);

CREATE TABLE IROUTE_VERSION (
	VERSION			VARCHAR2(64)	CONSTRAINT NN_VERSION NOT NULL
) ;

CREATE TABLE COUNTRY_EXCLUSION (
	COUNTRY_ID			NUMBER(10)
) ;