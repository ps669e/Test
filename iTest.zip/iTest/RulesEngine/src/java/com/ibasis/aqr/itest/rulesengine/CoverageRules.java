/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.rulesengine;

import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.datamanager.iTestDataManager;
import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.domain.PreferredRoute;

/**
 * @author schan
 *
 */
public class CoverageRules implements iTestRules {
    private static final Log log = LogFactory.getLog(CoverageRules.class);

    private PRCMerger rcMerger;

    public CoverageRules(iTestDataManager dataMgr) throws Exception {
        this.rcMerger = new PRCMerger(dataMgr);
    }

    @Override
    public void applyRulesOnCountry(Collection<Country> countries) throws Exception {
        try {
            if (countries != null) {
                for (Country country : countries) {
                    if (!country.isExcluded()) {
                        applyRulesOnCountry(country);
                    } else {
                        log.info("applyRulesOnCountry(): Country " + country.getName() + " excluded");
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception in applyRulesOnCountry(Collection): " + e.toString());
            throw e;
        }
    }

    @Override
    public void applyRulesOnCountry(Country country) throws Exception {
        if (country != null) {
            rcMerger.setCountry(country);
            country.navigateCountry(rcMerger);
        } else {
            log.error("applyRulesOnCountry(Country): Null input!");
        }
    }

    @Override
    public void applyRulesOnPreferredRoute(Collection<PreferredRoute> prefRoutes) throws Exception {
    }

    @Override
    public void applyRulesOnPreferredRoute(PreferredRoute preferredRoute) throws Exception {
    }

}
