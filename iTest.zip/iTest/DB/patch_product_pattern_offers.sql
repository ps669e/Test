rem Filename: patch_product_pattern_offers
rem Author: Madhavi Kanugo
rem Date: 06/05/05
rem Description: Add the following fields to the Inbound table and VW_Load_Inbound view.
--		 TECH_PREFIX  as varchar(10)  NULL (use NVL in view)
--		 IS_USE_AQR_TECH_PREFIX as char(1) default 'N' as per Vitaly's Request.

create table aqrvw_product_pattern_offers (
				PRODUCT_ID number(6)
				,COUNTRY_ID number(6)
				,PREFERRED_ROUTE_ID number(6)
				,ROUTE_ID number(6)
				,PATTERN varchar2(64)
				,OFFERS varchar2(10)
      	,COST number(8)
      	,MINUTES varchar2(20) );
