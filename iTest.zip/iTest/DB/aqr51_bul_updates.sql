
create or replace type IROUTE_STRING_ARRAY as TABLE OF VARCHAR2(64) ;
/
create or replace type IROUTE_INTEGER_ARRAY as TABLE OF NUMBER(10) ;
/
create or replace type IROUTE_FLOAT_ARRAY as TABLE OF NUMBER(8,4) ;
/
create or replace type IROUTE_CHAR_ARRAY as TABLE OF CHAR(1) ;
/


create or replace package aqr51_routes_bulk_updates as

	procedure start_update ;
	procedure finish_update ;

	procedure insert_aqr51_routes(KEYS OUT IROUTE_INTEGER_ARRAY, P_NAMES IROUTE_STRING_ARRAY, 
	RT_KEYS IROUTE_INTEGER_ARRAY, IROUTE_LNP_KEYS IROUTE_INTEGER_ARRAY, PERCENT_TYPE IROUTE_INTEGER_ARRAY) ;
	
	procedure update_aqr51_routes(KEYS IN IROUTE_INTEGER_ARRAY, P_NAMES IROUTE_STRING_ARRAY,  
	RT_KEYS IROUTE_INTEGER_ARRAY, IROUTE_LNP_KEYS IROUTE_INTEGER_ARRAY, PERCENT_TYPE IROUTE_INTEGER_ARRAY) ;
	
	procedure delete_aqr51_routes(KEYS IN IROUTE_INTEGER_ARRAY) ;
	
	
	procedure insert_aqr51_patterns (KEYS OUT IROUTE_INTEGER_ARRAY, P IROUTE_STRING_ARRAY, R_KEYS IN IROUTE_INTEGER_ARRAY) ;
	
	procedure update_aqr51_patterns (KEYS IN IROUTE_INTEGER_ARRAY, P IROUTE_STRING_ARRAY, R_KEYS IN IROUTE_INTEGER_ARRAY) ;
	
	procedure delete_aqr51_patterns (KEYS IN IROUTE_INTEGER_ARRAY) ;
	
	
	procedure insert_aqr51_choices (KEYS OUT IROUTE_INTEGER_ARRAY, P_ROUTE_KEY IN IROUTE_INTEGER_ARRAY, 
	 				COS_KEY IN IROUTE_INTEGER_ARRAY, P_IS_IN_SERVICE IN IROUTE_CHAR_ARRAY, P_IN_TESTING IN IROUTE_CHAR_ARRAY,
					P_PRIORITY IN IROUTE_INTEGER_ARRAY, PERCENTAGE IN IROUTE_INTEGER_ARRAY, TT_KEY IROUTE_INTEGER_ARRAY,
					V_POSITION IROUTE_INTEGER_ARRAY) ;
	
	
	procedure update_aqr51_choices (KEYS IN IROUTE_INTEGER_ARRAY, P_ROUTE_KEY IN IROUTE_INTEGER_ARRAY, 
	 				COS_KEY IN IROUTE_INTEGER_ARRAY, P_IS_IN_SERVICE IN IROUTE_CHAR_ARRAY, P_IN_TESTING IN IROUTE_CHAR_ARRAY,
					P_PRIORITY IN IROUTE_INTEGER_ARRAY, PERCENTAGE IN IROUTE_INTEGER_ARRAY, TT_KEY IROUTE_INTEGER_ARRAY,
					V_POSITION IROUTE_INTEGER_ARRAY) ;
					
	procedure delete_aqr51_choices (KEYS IN IROUTE_INTEGER_ARRAY) ;					
	

	
	procedure update_route_names(KEYS IROUTE_INTEGER_ARRAY, NAMES IROUTE_STRING_ARRAY) ;
	
	procedure lock_tables ;
	
	
end aqr51_routes_bulk_updates ;
/

set echo on

create or replace package body aqr51_routes_bulk_updates as

	V_UPDATE_ID NUMBER := NULL ;
	
	
	
	

	procedure insert_aqr51_routes(KEYS OUT IROUTE_INTEGER_ARRAY, P_NAMES IROUTE_STRING_ARRAY, 
	RT_KEYS IROUTE_INTEGER_ARRAY, IROUTE_LNP_KEYS IROUTE_INTEGER_ARRAY, PERCENT_TYPE IROUTE_INTEGER_ARRAY) is
	begin

		
		KEYS := IROUTE_INTEGER_ARRAY() ; 
		KEYS.EXTEND(P_NAMES.COUNT) ;
		FORALL i in p_names.first .. p_names.last 
			insert into routes (name, routingtable_key, iroute_lineup_key, is_auto_routed,LAST_CHANGED_BY, LAST_CHANGED_AT, UPDATE_ID, PERCENT_ROUTING_TYPE ) 
			values (p_names(i), rt_keys(i), iroute_lnp_keys(i), 'Y', 'iRoute',SYSDATE, V_UPDATE_ID, PERCENT_TYPE(i)) 
			returning route_key bulk collect into keys;

	end insert_aqr51_routes;
	
	procedure update_aqr51_routes(KEYS IN IROUTE_INTEGER_ARRAY, P_NAMES IROUTE_STRING_ARRAY,  
	RT_KEYS IROUTE_INTEGER_ARRAY, IROUTE_LNP_KEYS IROUTE_INTEGER_ARRAY, PERCENT_TYPE IROUTE_INTEGER_ARRAY) is
	begin
		FORALL i in keys.first .. keys.last 
		update routes set
		name = p_names(i),
		iroute_lineup_key = IROUTE_LNP_KEYS(i),
		routingtable_key = RT_KEYS(i),
		LAST_CHANGED_BY = 'iRoute',
		LAST_CHANGED_AT = SYSDATE,
		UPDATE_ID = V_UPDATE_ID,
		PERCENT_ROUTING_TYPE = PERCENT_TYPE(i)
		where route_key = keys(i) ;
	end ;
	
	procedure delete_aqr51_routes(KEYS IN IROUTE_INTEGER_ARRAY) is
	begin
		FORALL i in keys.first .. keys.last 
		delete from routes
		where route_key = keys(i) ;
	end ;
	
	
	procedure insert_aqr51_patterns (KEYS OUT IROUTE_INTEGER_ARRAY, P IROUTE_STRING_ARRAY, R_KEYS IN IROUTE_INTEGER_ARRAY) is 
	begin
		KEYS := IROUTE_INTEGER_ARRAY() ; 
		KEYS.EXTEND(P.COUNT) ;
		forall i in p.first .. p.last
		insert into matchpatterns (pattern, route_key)
		values (p(i), r_keys(i)) 
		returning pattern_key bulk collect into keys;
	end ;
	
	procedure update_aqr51_patterns (KEYS IN IROUTE_INTEGER_ARRAY, P IROUTE_STRING_ARRAY, R_KEYS IN IROUTE_INTEGER_ARRAY) is 
	begin
		forall i in keys.first .. keys.last 
		update matchpatterns set
		pattern = p(i),
		route_key = r_keys(i) 
		where pattern_key = keys(i);
	end ;
	
	procedure delete_aqr51_patterns (KEYS IN IROUTE_INTEGER_ARRAY) is 
	begin
	
	
		
		forall i in keys.first .. keys.last
		delete from matchpatterns 
		where pattern_key = keys(i) ;
	end ;
	
	
	procedure insert_aqr51_choices (KEYS OUT IROUTE_INTEGER_ARRAY, P_ROUTE_KEY IN IROUTE_INTEGER_ARRAY, 
	 				COS_KEY IN IROUTE_INTEGER_ARRAY, P_IS_IN_SERVICE IN IROUTE_CHAR_ARRAY, P_IN_TESTING IN IROUTE_CHAR_ARRAY,
					P_PRIORITY IN IROUTE_INTEGER_ARRAY, PERCENTAGE IN IROUTE_INTEGER_ARRAY,TT_KEY IROUTE_INTEGER_ARRAY,
					V_POSITION IROUTE_INTEGER_ARRAY) is 
	begin
	
		KEYS := IROUTE_INTEGER_ARRAY() ; 
		KEYS.EXTEND(cos_key.COUNT) ;	
		
		
		forall i in cos_key.first .. cos_key.last 
		insert into routing_choice (carrier_site_key, route_key, priority, 
		is_in_service, in_testing, traffic_percentage,ALLOCATED_PERCENTAGE, trouble_ticket_key, position)
		values (cos_key(i), p_route_key(i), 
		p_priority(i), P_IS_IN_SERVICE(i), P_IN_TESTING(i), PERCENTAGE(i), PERCENTAGE(i),tt_key(i),
		V_POSITION(i))
		returning routing_choice_key bulk collect into keys;
		
	end ;					
	
	
	procedure update_aqr51_choices (KEYS IN IROUTE_INTEGER_ARRAY, P_ROUTE_KEY IN IROUTE_INTEGER_ARRAY, 
	 				COS_KEY IN IROUTE_INTEGER_ARRAY, P_IS_IN_SERVICE IN IROUTE_CHAR_ARRAY, P_IN_TESTING IN IROUTE_CHAR_ARRAY,
					P_PRIORITY IN IROUTE_INTEGER_ARRAY, PERCENTAGE IN IROUTE_INTEGER_ARRAY,TT_KEY IROUTE_INTEGER_ARRAY,
					V_POSITION IROUTE_INTEGER_ARRAY) is
	begin
		forall i in cos_key.first .. cos_key.last
		update routing_choice set
		carrier_site_key = cos_key(i),
		route_key = p_route_key(i),
		priority = p_priority(i),
		is_in_service = p_is_in_service(i),
		in_testing = p_in_testing(i),
		traffic_percentage = PERCENTAGE(i),
		ALLOCATED_PERCENTAGE = PERCENTAGE(i),
		TROUBLE_TICKET_KEY = TT_KEY(i),
		POSITION = V_POSITION(i)
		where
		routing_choice_key = keys(i) ;
	end ;					
					
	procedure delete_aqr51_choices (KEYS IN IROUTE_INTEGER_ARRAY) is 
	begin
	   forall i in keys.first .. keys.last
	   delete from routing_choice 
	   where routing_choice_key = keys(i) ;
	end ;
	
	procedure start_update as
	begin
		SELECT SEQ_ROUTE_TRANSACTIONS.NEXTVAL INTO V_UPDATE_ID FROM DUAL ;
		
		
		
		--pattern_check_support.disable_pattern_check ;
		
		
	end ;
	procedure finish_update AS
	BEGIN
	 	
	 	
	 	/*delete from EXPANDED_DIAL_PATTERN 
	 	where routingtable_key in 
	 	(select routingtable_key from routingtable rt 
	 	where rt.update_by_iroute = 'Y' ) and
	 	route_key not in (select r.route_key from routes r, routingtable rt
	 	where rt.routingtable_key = r.routingtable_key and RT.UPDATE_BY_IROUTE = 'Y' AND R.IS_AUTO_ROUTED = 'N');
	 	
	 	insert into EXPANDED_DIAL_PATTERN ( PATTERN_KEY,
 						    PATTERN,
 						    ROUTINGTABLE_KEY,
 						    ROUTE_KEY,
 						    PATTERN_WITH_RANGES)
 		select P.PATTERN_KEY, P.PATTERN, R.ROUTINGTABLE_KEY, R.ROUTE_KEY, P.PATTERN
 		from
 		ROUTES R, ROUTINGTABLE RT, MATCHPATTERNS P
 		WHERE P.ROUTE_KEY = R.ROUTE_KEY AND R.ROUTINGTABLE_KEY = RT.ROUTINGTABLE_KEY
 		AND RT.UPDATE_BY_IROUTE = 'Y' AND R.IS_AUTO_ROUTED = 'Y' ;
	 	
	 	pattern_check_support.enable_pattern_check ;
		commit ;*/
		null ;
	END ;
	
	procedure update_route_names(KEYS IROUTE_INTEGER_ARRAY, NAMES IROUTE_STRING_ARRAY) AS 
	BEGIN
		FORALL i in KEYS.FIRST .. KEYS.LAST
		update routes set 
		name = names(i)
		where 
		ROUTE_KEY = KEYS(i) ;
	END ;
	
	procedure lock_tables as
	begin
		LOCK TABLE MATCHPATTERNS IN EXCLUSIVE MODE ;
		LOCK TABLE ROUTING_CHOICE IN EXCLUSIVE MODE ;
		LOCK TABLE ROUTES IN EXCLUSIVE MODE ;
	end ;
	
end aqr51_routes_bulk_updates ;
/
show errors
