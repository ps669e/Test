/*
 * Created on Aug 16, 2004
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.ibasis.aqr.itest.tree;

/**
 *
 * @author csib
 */
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class TenaryTreeNode {
    private static final Log logger = LogFactory.getLog(TenaryTreeNode.class);

    private int digit = -1;

    private TenaryTreeNode parent = null;

    private TenaryTreeNode[] children = new TenaryTreeNode[TenaryTreeMgr.TOTAL_CHILDREN];

    private Object nodeObject = null;

    private int childObjCount = 0;

    public TenaryTreeNode(int digit) {
        this.digit = digit;
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof TenaryTreeNode)) {
            return false;
        }
        TenaryTreeNode castOther = (TenaryTreeNode) other;
        if (this.getDigit() == castOther.getDigit()) {
            if (this.isRoot() && castOther.isRoot()) {
                return true;
            }

            if (this.getNodeObject() != null && castOther.getNodeObject() != null) {
                return this.getNodeObject().equals(castOther.getNodeObject());
            }

            Object thisParObj = this.getParentNodeObject();
            Object otherParObj = castOther.getParentNodeObject();
            if (thisParObj != null && otherParObj != null && thisParObj.equals(otherParObj)) {
                return true;
            }
        }
        return false;
    }

    public int getDigit() {
        return this.digit;
    }

    public TenaryTreeNode getParent() {
        return this.parent;
    }

    public Object getParentNodeObject() {
        Object parNodeObject = null;
        TenaryTreeNode parentNode = this.getParent();

        while (parentNode != null) {
            parNodeObject = parentNode.getNodeObject();
            if (parNodeObject != null) {
                break;
            }
            parentNode = parentNode.getParent();
        }

        return parNodeObject;
    }

    public void setParent(TenaryTreeNode parent) {
        this.parent = parent;
    }

    public TenaryTreeNode insertPattern(int pos, String pattern, Object nodeObj) throws Exception {
        TenaryTreeNode node = null;
        if (pos == pattern.length()) {
            if (this.nodeObject == null) {
                this.nodeObject = nodeObj;
                if (this.getParent() != null) {
                    this.getParent().addChildObjount();
                }
                node = this;
            } else {
                throw new Exception("pattern already exists");
            }
        } else {
            int no = Character.digit(pattern.charAt(pos++), 10);
            if (no >= 0) {
                if (children[no] == null) {
                    children[no] = new TenaryTreeNode(no);
                }
                children[no].setParent(this);
                node = children[no].insertPattern(pos, pattern, nodeObj);
            } else {
                String err = "Pattern " + pattern + " has invalid chars.";
                logger.error("insertPattern(): " + err);
                throw new Exception(err);
            }
        }

        return node;
    }

    public TenaryTreeNode findNode(int pos, String pattern) throws Exception {
        TenaryTreeNode node = null;
        if (pos == pattern.length()) {
            if (this.nodeObject != null) {
                node = this;
            }
        } else {
            int no = Character.digit(pattern.charAt(pos++), 10);
            if (no >= 0) {
                if (children[no] != null) {
                    node = children[no].findNode(pos, pattern);
                }
            } else {
                String err = "Pattern " + pattern + " has invalid chars.";
                logger.error("findNode(): " + err);
                throw new Exception(err);
            }
        }

        return node;
    }

    public Object getNodeObject() {
        return this.nodeObject;
    }

    /*
     * walks the node tree and gets all dial patterns under it in the order of
     * parent->children dialpatterns
     */
    public void navigateNode(NodeNavigator navigator) {
        boolean doNavigate = true;
        if (this.nodeObject != null) {
            doNavigate = navigator.processNodeObject(nodeObject);
        }
        if (doNavigate) {
            for (int i = 0; i < TenaryTreeMgr.TOTAL_CHILDREN; i++) {
                TenaryTreeNode treeNode = this.children[i];
                if (treeNode != null) {
                    treeNode.navigateNode(navigator);
                }
            }
        }
    }

    public boolean isRoot() {
        return (this.getParent() == null);
    }

    public boolean isLeaf() {
        for (int i = 0; i < TenaryTreeMgr.TOTAL_CHILDREN; i++) {
            if (children[i] != null) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param object
     */
    public void setNodeObject(Object object) {
        this.nodeObject = object;
    }

    public TenaryTreeNode getRootNode() {
        TenaryTreeNode node = this;
        while (node != null) {
            if (node.isRoot()) {
                break;
            } else {
                node = node.getParent();
            }
        }
        return node;
    }

    public Object getFurthestNodeObject(int pos, String pattern) throws Exception {
        Object furthestNodeObject = this.getNodeObject();
        int patLength = pattern.length();
        if (pattern != null) {
            if (pos != pattern.length()) {
                int no = Character.digit(pattern.charAt(pos), 10);
                if (no >= 0) {
                    TenaryTreeNode childNode = this.children[no];
                    while (childNode != null) {
                        Object o1 = childNode.getNodeObject();
                        if (o1 != null) {
                            furthestNodeObject = o1;
                        }
                        if (++pos >= patLength) {
                            break;
                        }
                        childNode = childNode.children[Character.digit(pattern.charAt(pos), 10)];
                    }
                } else {
                    String err = "Pattern " + pattern + " has invalid chars.";
                    logger.error("getFurthestNodeObject(): " + err);
                    throw new Exception(err);
                }
            }
        }

        return furthestNodeObject;
    }

    /**
     * @return increments objCount.
     */
    public int addChildObjount() {
        return childObjCount++;
    }

    /**
     * @return Returns the objCount.
     */
    public int getChildObjCount() {
        return childObjCount;
    }

    public boolean hasAllChildren() {
        return getChildObjCount() == TenaryTreeMgr.TOTAL_CHILDREN;
    }
}