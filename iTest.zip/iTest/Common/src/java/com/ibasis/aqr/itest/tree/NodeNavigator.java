/*
 * Created on Sep 22, 2004
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.ibasis.aqr.itest.tree;

/**
 * @author csib
 *
 */
public interface NodeNavigator {
    boolean processNodeObject(Object object);
}
