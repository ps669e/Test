package com.ibasis.aqr.util;

public class MutableBool implements Comparable, Cloneable {
    boolean val;

    public MutableBool(boolean val) {
        this.val = val;
    }

    public MutableBool(String val) {
        setVal(Boolean.valueOf(val));
    }

    public boolean getVal() {
        return val;
    }

    public void setVal(boolean val) {
        this.val = val;
    }

    public boolean booleanValue() {
        return val;
    }

    @Override
    public int compareTo(Object obj) throws ClassCastException {
        return compareTo(((MutableBool) obj).val);
    }

    public int compareTo(boolean bool) {
        return (val == bool) ? 0 : (val) ? 1 : -1;
    }

    /**
     * Convert to a string.
     *
     * @return String value
     */
    @Override
    public String toString() {
        return String.valueOf(val);
    }

    /**
     * Test the equality of another object.
     *
     * @param obj
     *            Object to test equality with.
     * @return True if object is equal to this.
     */
    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }

        if (obj != null && obj.getClass() == getClass()) {
            MutableBool bool = (MutableBool) obj;
            return val == bool.val;
        }

        return false;
    }

    /**
     * Clone this mutable boolean.
     *
     * @return Cloned mutable boolean.
     */
    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            throw new InternalError();
        }
    }

}
