/*
	--Author: Madhavi Kanugo
	--Description: Table holds the testing venodrs proportionate to route volume in D/DP.
	--Below rules appy.
*/
PROMPT "<300 offers per day = 1 venodr"
PROMPT ">= 300 offers per day = 2 vendors"
PROMPT ">=750 offers per day = 3 vendors"
PROMPT ">=1000 offers per day = 4 vendors"


DROP TABLE VENDORS_ROUTE_VOLUME_TEST;

CREATE TABLE VENDORS_ROUTE_VOLUME_TEST (VENDORS_ROUTE_VOLUME_KEY NUMBER(5) CONSTRAINT NN_ROUTE_VOLUME_KEY NOT NULL
																															CONSTRAINT PK_VRV_TEST_KEY PRIMARY KEY
																,MIN_OFFERS NUMBER
																 ,MAX_OFFERS NUMBER
																 ,VENDORS NUMBER
																 )
																 TABLESPACE &table_tablespace;
DROP SEQUENCE SEQ_VENDORS_ROUTE_VOLUME_KEY;

CREATE SEQUENCE SEQ_VENDORS_ROUTE_VOLUME_KEY
  START WITH 1
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 20
  NOORDER;