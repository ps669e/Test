/*
 * Created on Oct 18, 2004
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.ibasis.aqr.itest.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Collection;

import com.ibasis.aqr.itest.iTest;

import junit.framework.TestCase;

/**
 * @author Administrator
 *
 *         To change the template for this generated type comment go to Window -
 *         Preferences - Java - Code Generation - Code and Comments
 */
public class iRouteJUnitTest extends TestCase {

    /*
     * @see TestCase#setUp()
     */
    private iTest route;

    private Collection countries;

    public static final String GEN_REPORT_PARAM_NAME = "GEN_REPORT";
    public static final String GEN_FEED_PARAM_NAME = "GEN_FEED";
    public static final String SAVE_IROUTES_PARAM_NAME = "SAVE_IROUTES";
    public static final String DO_CONVERSION_PARAM_NAME = "DO_CONVERSION";
    public static final String GEN_RESULT_PARAM_NAME = "GEN_RESULT";

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        route = new iTest();
    }

    File outFile = null;

    File compareToFile = null;

    public void testOutput() {
        compareToFile = new File("output/iRoute.exp.out");
        outFile = new File("output/iRoute.out");
        assertFilesEqual(outFile, compareToFile);
    }

    public void assertFilesEqual(File fileOne, File fileTwo) {
        //assertEquals(readFile(fileOne), readFile(fileTwo));
        StringBuffer fileContents = new StringBuffer("");
        try {
            BufferedReader in1 = new BufferedReader(new FileReader(fileOne));
            BufferedReader in2 = new BufferedReader(new FileReader(fileTwo));
            String line1 = "", line2 = "";
            while (line1 != null && line2 != null) {
                assertEquals(line1, line2);
                line2 = in2.readLine();
                line1 = in1.readLine();
            }
            in1.close();
            in2.close();
            assertTrue(line1 == null && line2 == null);
            System.out.println("File compare Test case succeeded");
        } catch (Exception e) {
            System.err.println(e.toString());
        }
    }

    private static String readFile(File fileToRead) {
        StringBuffer fileContents = new StringBuffer("");
        try {
            BufferedReader in = new BufferedReader(new FileReader(fileToRead));
            String line;
            while ((line = in.readLine()) != null) {
                fileContents.append(line + "\n");
            }
            in.close();
        } catch (Exception e) {
            System.err.println(e.toString());
            return "";
        }
        return new String(fileContents);
    }

}