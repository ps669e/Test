drop table routes_reg;
drop table routing_choice_reg;
drop table matchpatterns_reg;
drop table expanded_dial_pattern_reg;
drop table routing_choice_oos_reg; 

create table routes_reg as select * from routes where routingtable_key in (select routingtable_key from routingtable where update_by_iroute = 'Y');

create table routing_choice_reg as select * from routing_choice where route_key in (select r.route_key from routes r, routingtable rt where r.routingtable_key = rt.routingtable_key and rt.update_by_iroute = 'Y');

create table matchpatterns_reg as select * from matchpatterns where route_key in (select r.route_key from routes r, routingtable rt where r.routingtable_key = rt.routingtable_key and rt.update_by_iroute = 'Y');

create table expanded_dial_pattern_reg as select * from expanded_dial_pattern where route_key in (select r.route_key from routes r, routingtable rt where r.routingtable_key = rt.routingtable_key and rt.update_by_iroute = 'Y');

create table routing_choice_oos_reg as select * from routing_choice_oos where route_key in (select r.route_key from routes r, routingtable rt where r.routingtable_key = rt.routingtable_key and rt.update_by_iroute = 'Y');

