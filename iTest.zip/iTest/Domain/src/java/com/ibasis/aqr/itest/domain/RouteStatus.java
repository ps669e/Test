package com.ibasis.aqr.itest.domain;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class RouteStatus {
    private static Log logger = LogFactory.getLog(RouteStatus.class);

    private long statusId;

    private long statusCode;

    private int categoryCode;

    private String categoryCodeDesc;

    private long rank;

    private String desc = "";

    private boolean isPV = false; // is it a PV status code

    public RouteStatus(long id, long code, long rank, String catCodeDesc) {
        this.statusId = id;
        this.statusCode = code;
        this.rank = rank;
        this.categoryCodeDesc = catCodeDesc;
        this.categoryCode = getCategoryCode(catCodeDesc);
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof RouteStatus)) {
            return false;
        }
        return equals((RouteStatus) o);
    }

    public boolean equals(RouteStatus r) {
        return this.statusId == r.statusId;
    }

    @Override
    public int hashCode() {
        return Long.valueOf(statusId).hashCode();
    }

    public int getCategoryCode(String code) {
        if (code == null) {
            logger.error("getCategoryCode(): Unknown CATEGORY_CODE " + code + " found against status code!");
            return -1;
        }

        if (code.equals("ROUTABLE")) {
            return DomainConstants.ROUTABLE;
        } else if (code.equals("NON-ROUTABLE")) {
            return DomainConstants.NON_ROUTABLE;
        } else if (code.equals("TEST")) {
            return DomainConstants.TEST;
        } else if (code.equals("ONNET_TESTING")) {
            return DomainConstants.ONNET_TEST;
        } else if (code.equals("FORCED_TEST")) {
            return DomainConstants.REQUIRED_TEST;
        } else {
            logger.error("getCategoryCode(): Unknown CATEGORY_CODE " + code + " found against status code!");
            return -1;
        }
    }

    public int getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(int categoryCode) {
        this.categoryCode = categoryCode;
    }

    public String getCategoryCodeDesc() {
        return categoryCodeDesc;
    }

    public void setCategoryCodeDesc(String categoryCodeDesc) {
        this.categoryCodeDesc = categoryCodeDesc;
    }

    public long getCode() {
        return statusCode;
    }

    public void setCode(long code) {
        this.statusCode = code;
    }

    public long getId() {
        return statusId;
    }

    public void setId(long id) {
        this.statusId = id;
    }

    public long getRank() {
        return rank;
    }

    public void setRank(long rank) {
        this.rank = rank;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public boolean isPV() {
        return isPV;
    }

    public void setPV(boolean isPV) {
        this.isPV = isPV;
    }

    @Override
    public String toString() {
        return "{code:" + getCode() + ",id:" + getId() + ",cat:" + getCategoryCodeDesc() + ",rank:" + getRank() + (isPV() ? ",PV}" : "}");
    }
}
