package com.ibasis.aqr.itest;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ConsoleInput {
    private static final Log logger = LogFactory.getLog(ConsoleInput.class);
    private final long timeout;
    private final TimeUnit unit;

    public ConsoleInput(long timeout, TimeUnit unit) {
        this.timeout = timeout;
        this.unit = unit;
    }

    public String readLine() throws InterruptedException {
        ExecutorService ex = Executors.newSingleThreadExecutor();
        String input = null;
        try {
            Future<String> result = ex.submit(new ConsoleInputReadTask());
            try {
                input = result.get(timeout, unit);
            } catch (ExecutionException e) {
                e.getCause().printStackTrace();
            } catch (TimeoutException e) {
                result.cancel(true);
                logger.info("Time out reading user's input since " + timeout + " seconds are up.");
            }

        } finally {
            ex.shutdownNow();
        }
        return input;
    }
}
