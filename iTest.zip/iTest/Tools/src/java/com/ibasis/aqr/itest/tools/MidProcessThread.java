package com.ibasis.aqr.itest.tools;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.datamanager.iTestDataManager;

/**
 *
 * @authors
 *
 */
public class MidProcessThread extends Thread {
    private static Log logger = LogFactory.getLog(MidProcessThread.class);

    private iTestDataManager dataMgr = null;

    public MidProcessThread(iTestDataManager iRouteDataManager) {
        this.dataMgr = iRouteDataManager;
    }

    @Override
    public void run() {
        try {
            MidProcess midprocess = new MidProcess();
            midprocess.runMidProcess();
        } catch (Exception e) {
            logger.error("Exception in MidProcessThread ", e);
        }
    }
}
