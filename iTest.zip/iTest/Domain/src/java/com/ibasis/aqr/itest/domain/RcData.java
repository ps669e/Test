package com.ibasis.aqr.itest.domain;

public class RcData {
    private double rcCost = DomainConstants.LARGE_DOUBLE_VALUE;
    private double rcMaxNetCost = DomainConstants.LARGE_DOUBLE_VALUE;

    public RcData() {
    }

    public RcData(double rcCost, double rcMaxNetCost) {
        this.rcCost = rcCost;
        this.rcMaxNetCost = rcMaxNetCost;
    }

    public double getRcCost() {
        return rcCost;
    }

    public void setRcCost(double rcCost) {
        this.rcCost = rcCost;
    }

    public double getRcMaxNetCost() {
        return rcMaxNetCost;
    }

    public void setRcMaxNetCost(double rcMaxNetCost) {
        this.rcMaxNetCost = rcMaxNetCost;
    }
}
