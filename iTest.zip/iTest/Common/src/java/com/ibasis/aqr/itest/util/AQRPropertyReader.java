/*
 * AQRPropertyReader.java
 * Created on January 6, 2003, 2:41 PM
 */

/**
 *
 * @author csib
 */
package com.ibasis.aqr.itest.util;

import java.io.File;
import java.net.URL;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.SystemConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.common.iTestConstants;

public class AQRPropertyReader {
    private static final Log log = LogFactory.getLog(AQRPropertyReader.class);
    private static CompositeConfiguration config;

    static {
        try {
            URL resource = Thread.currentThread().getContextClassLoader().getResource(iTestConstants.PROPERTY_FILE);
            // Create a composite configuration, to allow overriding of properties
            config = new CompositeConfiguration();
            // Look for system parameters first
            config.addConfiguration(new SystemConfiguration());
            // todo decide whether to add an override properties file, developer-specific
            // Next look in the properties file (system parameters will override the
            // properties file)
            PropertiesConfiguration propertiesConfiguration = new PropertiesConfiguration();
            // Don't split comma-delimitted parameters into an array
            propertiesConfiguration.setDelimiterParsingDisabled(true);
            propertiesConfiguration.setListDelimiter((char) 0);
            // Reload the file if it changes
            FileChangedReloadingStrategy fileChangedReloadingStrategy = new FileChangedReloadingStrategy();
            fileChangedReloadingStrategy.setRefreshDelay(10000);
            fileChangedReloadingStrategy.setConfiguration(propertiesConfiguration);
            propertiesConfiguration.setReloadingStrategy(fileChangedReloadingStrategy);
            // Load the properties
            propertiesConfiguration.setFile(new File(resource.getFile()));
            config.addConfiguration(propertiesConfiguration);
            log.info("Property file : " + iTestConstants.PROPERTY_FILE + " successfully loaded.");
        } catch (Exception e) {
            log.error("AQRPropertyReader: failed to load property file: " + iTestConstants.PROPERTY_FILE);
        }
    }

    public static String getPropertyNoTrim(String propertyName) {
        String val = "";
        try {
            val = config.getString(propertyName);
        } catch (Exception ex) {
            log.error("getProperty() - error fetching property - " + propertyName + ".\n" + ex);
        }
        return val;
    }

    public static String getProperty(String propertyName) {
        String val = "";
        try {
            val = config.getString(propertyName);
            if (val != null) {
                val = val.trim();
            }
        } catch (Exception ex) {
            log.error("getProperty() - error fetching property - " + propertyName + ".\n" + ex);
        }

        return val;
    }
}
