package com.ibasis.aqr.itest.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.domain.DomainConstants;
import com.ibasis.aqr.itest.domain.FloorRate;
import com.ibasis.aqr.itest.domain.Provider;
import com.ibasis.aqr.itest.domain.ProviderCoverage;
import com.ibasis.aqr.itest.domain.ProviderRate;
import com.ibasis.aqr.itest.domain.RcData;
import com.ibasis.aqr.itest.domain.TimeOfDay;
import com.ibasis.aqr.itest.rulesengine.OverlappingPeriodRules;

public class EmbeddedTodTest extends iRouteTestBase {
    private Log logger = LogFactory.getLog(EmbeddedTodTest.class);

    private OverlappingPeriodRules overlapRules = null;
    private TimeOfDay lineupTod = null;
    private FloorRate floor = new FloorRate(0.1);
    private Map<Integer, TestRate> todRates = new HashMap<Integer, TestRate>();
    private ProviderCoverage choice = null;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
        todRates.clear();
        lineupTod = null;
    }

    /**
     * L1 and L2 are in hours
     *
     * @param currentPeriodLength L1
     * @param overlapPeriodLength L2
     */
    private double computeWeightedAvg(int percent, int periodLength, int overlapPeriodLength, double periodCost, double overlapPeriodCost) {
        double percentage = percent / 100d;
        double wavg = ((periodLength * (1 + percentage) * periodCost) / (periodLength * (1 + percentage) + overlapPeriodLength))
                + ((overlapPeriodLength * overlapPeriodCost) / (periodLength * (1 + percentage) + overlapPeriodLength));
        logger.info("calculated wavg " + wavg);
        return wavg;
    }

    private ProviderCoverage setupChoice(Map<Integer, TestRate> todRates) {
        Map<Integer, ProviderRate> rates = new HashMap<Integer, ProviderRate>();
        Map<Integer, RcData> rcDataMap = new HashMap<Integer, RcData>();
        Iterator<Integer> it = todRates.keySet().iterator();
        while (it.hasNext()) {
            int periodId = it.next();
            TestRate rate = todRates.get(periodId);
            ProviderRate providerRate = new ProviderRate();
            providerRate.setTimeOfDay(new TimeOfDay(rate.getPeriodId(), rate.getStartTime(), rate.getEndTime(), rate.getStartWeekDay(), rate.getEndWeekDay()));
            providerRate.setCost(rate.getCost());
            providerRate.setMaxNetCost(rate.getMaxNetCost());
            rates.put(rate.getPeriodId(), providerRate);

            RcData rcData = new RcData(rate.getCost(), rate.getMaxNetCost());
            rcDataMap.put(rate.getPeriodId(), rcData);
            if (rate.getPeriodId() == W) {
                // create an additional weekday using peak
                TestRate peakRate = todRates.get(P);
                rcData = new RcData(peakRate.getCost(), peakRate.getMaxNetCost());
                rcDataMap.put(D, rcData);
            }
        }

        Provider provider = new Provider();
        provider.setName("UnitTest Vendor");
        ProviderCoverage pcvg = new ProviderCoverage(provider);
        pcvg.setProviderRates(rates);
        pcvg.setUnitTestRcDataMap(rcDataMap);
        return pcvg;
    }

    private void printOverlapRulesResults(OverlappingPeriodRules overlapRules) {
        String overlapStatusMsg = null;
        int overlapStatus = overlapRules.getOverlappingStatus();
        if (overlapStatus == OverlappingPeriodRules.FULLY_OVERLAP) {
            overlapStatusMsg = "Fully Overlap";
        } else if (overlapStatus == OverlappingPeriodRules.NO_OVERLAP) {
            overlapStatusMsg = "No Overlap";
        } else if (overlapStatus == OverlappingPeriodRules.PARTIAL_OVERLAP) {
            overlapStatusMsg = "Partial Overlap";
        }
        String msg = overlapStatusMsg + ", rcEmbeddedTime: " + overlapRules.getRcEmbeddedTimeOfDay() + ", todCost: " + overlapRules.getWAvgCost()
                + ", todNetCost: " + overlapRules.getWAvgMaxNetCost();
        logger.info(msg);
    }

    //lineupTod = new TimeOfDay(P,"09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
    //lineupTod = new TimeOfDay(P,"20:00:00", "09:00:00", NULL_VALUE, NULL_VALUE);
    //lineupTod = new TimeOfDay(P,"00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE);
    //lineupTod = new TimeOfDay(P,"00:00:00", "09:00:00", NULL_VALUE, NULL_VALUE);
    //lineupTod = new TimeOfDay(P,"01:00:00", "09:00:00", NULL_VALUE, NULL_VALUE);
    //lineupTod = new TimeOfDay(P,"09:00:00", "23:59:59", NULL_VALUE, NULL_VALUE);
    //lineupTod = new TimeOfDay(P,"23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE); // expect nothing
    //lineupTod = new TimeOfDay(P,"00:00:00", "00:00:00", NULL_VALUE, NULL_VALUE); // expect nothing

    public void testIdentical() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.155, 0.173));
        todRates.put(O, new TestRate(O, "20:00:00", "09:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.155, overlapRules.getWAvgCost());
        assertEquals(0.173, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb01() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "10:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "18:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "10:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "10:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 8, 3, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 8, 3, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb02() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "09:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "18:00:00", "09:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "09:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "09:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 9, 2, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 9, 2, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb03() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "10:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "10:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "10:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 10, 1, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 10, 1, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb04() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "08:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "18:00:00", "08:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "09:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "09:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "08:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 9, 2, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 9, 2, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb05() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "10:00:00", "22:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "22:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "10:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "10:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "22:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 10, 1, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 10, 1, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb06() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "08:00:00", "22:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "22:00:00", "08:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "22:00:00", "08:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb07() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "08:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "08:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "08:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb08() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "09:00:00", "22:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "22:00:00", "09:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "22:00:00", "09:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb09() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "09:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "09:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "09:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb10() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "08:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "08:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "08:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb11() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "23:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "23:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "23:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb12() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "21:00:00", "23:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "23:00:00", "21:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "23:00:00", "21:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb13() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "00:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb14() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "09:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "09:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.119));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "09:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.119));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 2, 9, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 2, 9, 0.145, 0.119), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb15() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "10:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertEquals(new TimeOfDay(P, "09:00:00", "10:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "10:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "10:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 3, 8, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 3, 8, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb16() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "09:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb17() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "10:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "09:00:00", "10:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "09:00:00", "10:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "10:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 1, 10, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 1, 10, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb18() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.119));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 2, 9, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 2, 9, 0.145, 0.119), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb19() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "21:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "21:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb20() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "23:59:59", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "23:59:59", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.119));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 2, 9, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 2, 9, 0.145, 0.119), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb21() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "09:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "09:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "02:00:00", "09:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb22() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "10:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "10:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "10:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "02:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 10, 1, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 10, 1, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb23() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "21:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "10:00:00", "21:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "09:00:00", "10:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "09:00:00", "10:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "10:00:00", "21:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 1, 10, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 1, 10, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test090000_to_200000_emb24() {
        lineupTod = new TimeOfDay(P, "09:00:00", "20:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "10:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "10:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "10:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "10:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 10, 1, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 10, 1, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb01() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb02() {
        lineupTod = new TimeOfDay(O, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(O, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(O, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(P, new TestRate(P, "02:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb03() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "02:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb04() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "23:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "23:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "20:00:00", "23:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "20:00:00", "23:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "23:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.085, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 3, 5, 0.094, 0.085), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 3, 5, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb05() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "20:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "20:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 4, 4, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 4, 4, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb06() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "20:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "20:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "01:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.116));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 5, 3, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 5, 3, 0.145, 0.116), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb07() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "06:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "06:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb08() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 2, 6, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 2, 6, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb09() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb10() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "01:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 7, 1, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 7, 1, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb11() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "06:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "06:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb12() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "15:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb13() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "15:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb14() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "15:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 2, 6, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 2, 6, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb15() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "15:00:00", "06:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "06:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb16() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "00:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "00:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "00:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "02:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 2, 6, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 2, 6, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb17() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "00:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "00:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "00:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "01:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 1, 7, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 1, 7, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb18() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "18:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb19() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "13:00:00", "17:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "17:00:00", "13:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "17:00:00", "13:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb20() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "06:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "06:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb21() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "06:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "06:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb22() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "00:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb23() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb24() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "15:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "15:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb25() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 2, 6, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 2, 6, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb26() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb27() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "01:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 7, 1, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 7, 1, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb28() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb29() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "18:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb30() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "15:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "15:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb31() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 2, 6, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 2, 6, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb32() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 6, 2, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb33() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "01:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 7, 1, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 7, 1, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb34() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "01:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "01:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertEquals(new TimeOfDay(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "01:00:00", "20:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.085, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 3, 5, 0.094, 0.085), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 3, 5, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb35() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "01:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "01:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertEquals(new TimeOfDay(P, "18:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "01:00:00", "00:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.085, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 7, 1, 0.094, 0.085), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 7, 1, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb36() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "01:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "01:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "01:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.086, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 1, 7, 0.094, 0.086), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 1, 7, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test180000_to_020000_emb37() {
        lineupTod = new TimeOfDay(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "01:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "15:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "01:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "01:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "15:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.086, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 1, 7, 0.094, 0.086), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 1, 7, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb01() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb02() {
        lineupTod = new TimeOfDay(O, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(P, new TestRate(P, "02:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb03() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "02:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb04() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "23:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "23:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "23:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb05() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb06() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "01:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb07() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "20:00:00", "06:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "06:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "02:00:00", "06:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "02:00:00", "06:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 4, 12, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 4, 12, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb08() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb09() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb10() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "01:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb11() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "06:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "06:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "02:00:00", "06:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "02:00:00", "06:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 4, 12, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 4, 12, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb12() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "15:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 3, 13, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 3, 13, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb13() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "15:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 3, 13, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 3, 13, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb14() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "15:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 3, 13, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 3, 13, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb15() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "15:00:00", "06:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "06:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertEquals(new TimeOfDay(P, "02:00:00", "06:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "15:00:00", "06:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 7, 9, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 7, 9, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb16() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "00:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "02:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb17() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "00:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "01:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb18() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "18:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 3, 13, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 3, 13, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb19() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "13:00:00", "17:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "17:00:00", "13:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "13:00:00", "17:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "13:00:00", "17:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "17:00:00", "13:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 4, 12, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 4, 12, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb20() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "06:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "06:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "02:00:00", "06:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "02:00:00", "06:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 4, 12, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 4, 12, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb21() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "06:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "06:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "03:00:00", "06:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "03:00:00", "06:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 3, 13, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 3, 13, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb22() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "00:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "06:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb23() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb24() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "15:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "15:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.116));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 13, 3, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 13, 3, 0.145, 0.116), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb25() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb26() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb27() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "02:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "01:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb28() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "15:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.116));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 13, 3, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 13, 3, 0.145, 0.116), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb29() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "18:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "03:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "03:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 15, 1, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 15, 1, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb30() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "15:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "03:00:00", "15:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "03:00:00", "15:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "15:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 12, 4, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 12, 4, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb31() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "03:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "03:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 15, 1, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 15, 1, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb32() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "03:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "03:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 15, 1, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 15, 1, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb33() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "03:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "03:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "03:00:00", "18:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "01:00:00", "03:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 15, 1, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 15, 1, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb34() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "01:00:00", "20:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "20:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.085, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb35() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "01:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "00:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "00:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.085, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb36() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "01:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.086, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test020000_to_180000_emb37() {
        lineupTod = new TimeOfDay(P, "02:00:00", "18:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "01:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "15:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "02:00:00", "15:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "15:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.086, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 13, 3, 0.094, 0.086), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 13, 3, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    //////////////////////////////////////
    /////////////////////////////////////
    public void test200000_to_090000_emb01() {
        lineupTod = new TimeOfDay(P, "20:00:00", "09:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "08:00:00", "21:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "21:00:00", "08:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "08:00:00", "09:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertEquals(new TimeOfDay(P, "20:00:00", "21:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "08:00:00", "21:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "21:00:00", "08:00:00", NULL_VALUE, NULL_VALUE, 0.086, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 2, 11, 0.094, 0.086), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 2, 11, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test200000_to_090000_emb02() {
        lineupTod = new TimeOfDay(P, "20:00:00", "09:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "08:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "02:00:00", "08:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "08:00:00", "09:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertEquals(new TimeOfDay(P, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "08:00:00", "02:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "20:00:00", "02:00:00", NULL_VALUE, NULL_VALUE, 0.086, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 7, 6, 0.094, 0.086), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 7, 6, 0.145, 0.118), overlapRules.getWAvgMaxNetCost());
    }

    public void test000000_to_150000_emb01() {
        lineupTod = new TimeOfDay(P, "00:00:00", "15:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "00:00:00", "15:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "15:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "15:00:00", "00:00:00", NULL_VALUE, NULL_VALUE, 0.086, 0.118));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void test000000_to_150000_emb02() {
        lineupTod = new TimeOfDay(P, "00:00:00", "15:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "18:00:00", "01:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "01:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "00:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "00:00:00", "01:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "01:00:00", "18:00:00", NULL_VALUE, NULL_VALUE, 0.084, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 1, 14, 0.094, 0.084), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 1, 14, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    public void test000000_to_150000_emb03() {
        lineupTod = new TimeOfDay(P, "00:00:00", "15:00:00", NULL_VALUE, NULL_VALUE);
        todRates.put(P, new TestRate(P, "16:00:00", "08:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "08:00:00", "16:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(P, "00:00:00", "08:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(P, "00:00:00", "08:00:00", NULL_VALUE, NULL_VALUE), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());

        // test weighted avg, also set overlap cost below floor
        todRates.put(O, new TestRate(O, "08:00:00", "16:00:00", NULL_VALUE, NULL_VALUE, 0.086, 0.115));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(computeWeightedAvg(0, 8, 7, 0.094, 0.086), overlapRules.getWAvgCost());
        assertEquals(computeWeightedAvg(0, 8, 7, 0.145, 0.115), overlapRules.getWAvgMaxNetCost());
    }

    /////////////////////
    //Weekend Scenarios//
    /////////////////////
    public void testSu000000_to_M235959_emb01() {
        lineupTod = new TimeOfDay(W, "00:00:00", "23:59:59", 0, 1);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "18:00:00", "07:00:00", 5, 1, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "00:00:00", "07:00:00", 0, 1), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "00:00:00", "07:00:00", 0, 1), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testSu000000_to_M235959_emb02() {
        lineupTod = new TimeOfDay(W, "00:00:00", "23:59:59", 0, 1);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "20:00:00", "07:00:00", 6, 1, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "00:00:00", "07:00:00", 0, 1), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "00:00:00", "07:00:00", 0, 1), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testSa000000_to_Su235959_emb01() {
        lineupTod = new TimeOfDay(W, "00:00:00", "23:59:59", 6, 0);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "20:00:00", "07:00:00", 6, 1, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "20:00:00", "23:59:59", 6, 0), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "20:00:00", "23:59:59", 6, 0), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testSa000000_to_Su235959_emb02() {
        //weekday
        lineupTod = new TimeOfDay(D, "00:00:00", "23:59:59", 6, 0);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.094, 0.145));
        todRates.put(W, new TestRate(W, "20:00:00", "07:00:00", 6, 1, 0.2, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(D, "00:00:00", "20:00:00", 6, 6), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(D, "00:00:00", "20:00:00", 6, 6), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testSa000000_to_Su235959_emb03() {
        lineupTod = new TimeOfDay(W, "00:00:00", "23:59:59", 6, 0);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "18:00:00", "18:00:00", 5, 0, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "00:00:00", "18:00:00", 6, 0), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "00:00:00", "18:00:00", 6, 0), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testSa000000_to_Su235959_emb04() {
        lineupTod = new TimeOfDay(W, "00:00:00", "23:59:59", 6, 0);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "00:00:00", "23:59:59", 5, 5, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testSa000000_to_Su235959_emb05() {
        lineupTod = new TimeOfDay(W, "00:00:00", "23:59:59", 6, 0);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "23:59:59", "00:00:00", 0, 6, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testSa000000_to_Su235959_emb06() {
        lineupTod = new TimeOfDay(W, "00:00:00", "23:59:59", 6, 0);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "22:59:59", "00:00:00", 0, 6, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "22:59:59", "23:59:59", 0, 0), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "22:59:59", "23:59:59", 0, 0), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testSu000000_to_F000000_emb01() {
        lineupTod = new TimeOfDay(W, "00:00:00", "00:00:00", 0, 5);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "00:00:00", "00:00:00", 2, 1, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "00:00:00", "00:00:00", 2, 5), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertEquals(new TimeOfDay(W, "00:00:00", "00:00:00", 0, 1), overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "00:00:00", "00:00:00", 2, 1), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testM000000_to_F000000_emb01() {
        lineupTod = new TimeOfDay(W, "00:00:00", "00:00:00", 1, 5);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "00:00:00", "00:00:00", 4, 4, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testM000000_to_F000000_emb02() {
        lineupTod = new TimeOfDay(W, "00:00:00", "00:00:00", 1, 5);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "00:00:00", "20:00:00", 4, 4, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "00:00:00", "20:00:00", 4, 4), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "00:00:00", "20:00:00", 4, 4), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testF115959_to_M000000_emb01() {
        lineupTod = new TimeOfDay(W, "11:59:59", "00:00:00", 5, 1);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "00:00:00", "12:59:59", 5, 5, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "11:59:59", "12:59:59", 5, 5), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "11:59:59", "12:59:59", 5, 5), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testF180000_to_M090000_emb01() {
        lineupTod = new TimeOfDay(W, "18:00:00", "09:00:00", 5, 1);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "09:00:00", "18:00:00", 1, 5, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testF180000_to_M090000_emb02() {
        lineupTod = new TimeOfDay(W, "18:00:00", "09:00:00", 5, 1);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "09:00:00", "20:00:00", 1, 5, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "18:00:00", "20:00:00", 5, 5), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "18:00:00", "20:00:00", 5, 5), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testF180000_to_M090000_emb03() {
        lineupTod = new TimeOfDay(W, "18:00:00", "09:00:00", 5, 1);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "07:00:00", "18:00:00", 1, 5, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "07:00:00", "09:00:00", 1, 1), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "07:00:00", "09:00:00", 1, 1), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testF180000_to_M090000_emb04() {
        lineupTod = new TimeOfDay(W, "18:00:00", "09:00:00", 5, 1);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "07:00:00", "20:00:00", 1, 5, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "07:00:00", "09:00:00", 1, 1), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertEquals(new TimeOfDay(W, "18:00:00", "20:00:00", 5, 5), overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "07:00:00", "20:00:00", 1, 5), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testF180000_to_M020000_emb01() {
        lineupTod = new TimeOfDay(W, "18:00:00", "02:00:00", 5, 1);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "18:00:00", "04:00:00", 5, 1, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.FULLY_OVERLAP);
        assertNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

    public void testF180000_to_M020000_emb02() {
        lineupTod = new TimeOfDay(W, "18:00:00", "02:00:00", 5, 1);
        todRates.put(P, new TestRate(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(O, new TestRate(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE, 0.139, 0.115));
        todRates.put(W, new TestRate(W, "18:00:00", "01:00:00", 5, 1, 0.094, 0.145));
        choice = setupChoice(todRates);
        overlapRules = new OverlappingPeriodRules(lineupTod, floor, choice, false);
        printOverlapRulesResults(overlapRules);
        assertTrue(overlapRules.getOverlappingStatus() == OverlappingPeriodRules.PARTIAL_OVERLAP);
        assertEquals(new TimeOfDay(W, "18:00:00", "01:00:00", 5, 1), overlapRules.getEmbeddedTimeForUnitTest()[0]);
        assertNull(overlapRules.getEmbeddedTimeForUnitTest()[1]);
        assertNotNull(overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(new TimeOfDay(W, "18:00:00", "01:00:00", 5, 1), overlapRules.getRcEmbeddedTimeOfDay());
        assertEquals(0.094, overlapRules.getWAvgCost());
        assertEquals(0.145, overlapRules.getWAvgMaxNetCost());
    }

}

class TestRate {
    private int periodId;
    private String startTime;
    private String endTime;
    private int startWeekDay = DomainConstants.NULL_VALUE;
    private int endWeekDay = DomainConstants.NULL_VALUE;
    private double cost = DomainConstants.LARGE_DOUBLE_VALUE;
    private double maxNetCost = DomainConstants.LARGE_DOUBLE_VALUE;

    public TestRate(int periodId, String startTime, String endTime, int startWeekDay, int endWeekDay, double cost, double maxNetCost) {
        this.periodId = periodId;
        this.startTime = startTime;
        this.endTime = endTime;
        this.startWeekDay = startWeekDay;
        this.endWeekDay = endWeekDay;
        this.cost = cost;
        this.maxNetCost = maxNetCost;
    }

    public int getPeriodId() {
        return periodId;
    }

    public void setPeriodId(int periodId) {
        this.periodId = periodId;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public int getStartWeekDay() {
        return startWeekDay;
    }

    public void setStartWeekDay(int startWeekDay) {
        this.startWeekDay = startWeekDay;
    }

    public int getEndWeekDay() {
        return endWeekDay;
    }

    public void setEndWeekDay(int endWeekDay) {
        this.endWeekDay = endWeekDay;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public double getMaxNetCost() {
        return maxNetCost;
    }

    public void setMaxNetCost(double maxNetCost) {
        this.maxNetCost = maxNetCost;
    }

}