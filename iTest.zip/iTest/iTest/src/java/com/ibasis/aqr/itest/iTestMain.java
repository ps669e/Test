/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest;

import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.common.iTestConstants;
import com.ibasis.aqr.itest.config.iTestConfigManager;

/**
 * @author schan
 *
 */
public class iTestMain {
    private static final Log logger = LogFactory.getLog(iTestMain.class);
    private static iTestConfigManager configMgr = iTestConfigManager.getInstance();
    private static final String TEST_DB = "testdb";

    public static void main(String[] args) {
        try {
            iTest itest = new iTest();
            if (args.length == 0) {
                logger.info(configMgr);
                if (configMgr.isPropertyCheckEnabled()) {
                    checkProperties();
                }
                itest.execute();
            } else if (args.length == 1 && args[0].equals(TEST_DB)) {
                itest.testDbConnections();
            } else {
                printUsage();
            }

            System.out.println("Main: Exited.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void printUsage() {
        System.out.println("Usage: " + iTestMain.class.getName() + " [" + TEST_DB + "]");
    }

    private static void checkProperties() {
        if (hasAnyPropertyDisabled()) {
            if (System.console() != null) {
                //Allow user to proceed iTest run by entering YES in console when one or more important iTest properties in itest.properties are turned off
                ConsoleInput con = new ConsoleInput(configMgr.getConsoleTimeoutSeconds(), TimeUnit.SECONDS);
                String input = null;
                try {
                    input = con.readLine();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    logger.error("InterruptedException in iTest Main checkProperties()!");
                }
                if (input == null || (input != null && !input.equalsIgnoreCase("Yes"))) {
                    logger.error("iTeste Main Existed due to your input is " + input);
                    System.out.println("Main: Exited.");
                    System.exit(0);
                }
            } else {
                //Exit iTest if any important iTest property in itest.properties is turned off
                logger.info("One or more important iTest properties are off. Please check " + iTestConstants.PROPERTY_FILE + ".\nYou can set "
                        + iTestConfigManager.PROP_PROPERTY_CHECK_ENANBLED + "=true to skip important iTest properties check.");
                System.out.println("Main: Exited.");
                System.exit(0);
            }
        }

    }

    /**
     * Check important iTest properties. Exit if any of them is turn off.
     *
     * @return
     */
    private static boolean hasAnyPropertyDisabled() {
        logger.warn("Check important iTest properties...");

        boolean disabledFlag = false;
        if (!configMgr.isPreProcessEnabled()) {
            logger.warn(iTestConfigManager.PROP_PRE_PROCESS_ENABLED + " is disabled! ");
            disabledFlag = true;
        }
        if (!configMgr.isPostProcessEnabled()) {
            logger.warn(iTestConfigManager.PROP_POST_PROCESS_ENABLED + " is disabled! ");
            disabledFlag = true;
        }
        if (!configMgr.isMidProcessEnabled()) {
            logger.warn(iTestConfigManager.PROP_MID_PROCESS_ENABLED + " is disabled! ");
            disabledFlag = true;
        }
        if (!configMgr.isITestVendorReportEnabled()) {
            logger.warn(iTestConfigManager.PROP_ITEST_VENDOR_REPORT_ENABLED + " is disabled! ");
            disabledFlag = true;
        }
        if (!configMgr.isDecryptDbPwd()) {
            logger.warn(iTestConfigManager.PROP_DECRYPT_DB_PASSWORD + " is disabled! ");
            disabledFlag = true;
        }
        if (!configMgr.isDoOutput()) {
            logger.warn(iTestConfigManager.PROP_OUTPUT_ENABLED + " is disabled! ");
            disabledFlag = true;
        }
        return disabledFlag;
    }

}