package com.ibasis.aqr.itest.domain;

import java.util.Set;

public class TestRule {
    private String testRule;
    private String pvStatusCategory;
    private String cvStatusCategory;
    private Set<VoiceCarrierGroup> blockGroups;
    private Set<VoiceCarrierGroup> testGroups;

    public String getTestRule() {
        return testRule;
    }

    public void setTestRule(String testRule) {
        this.testRule = testRule;
    }

    public String getPvStatusCategory() {
        return pvStatusCategory;
    }

    public void setPvStatusCategory(String pvStatusCategory) {
        this.pvStatusCategory = pvStatusCategory;
    }

    public String getCvStatusCategory() {
        return cvStatusCategory;
    }

    public void setCvStatusCategory(String cvStatusCategory) {
        this.cvStatusCategory = cvStatusCategory;
    }

    public Set<VoiceCarrierGroup> getBlockGroups() {
        return blockGroups;
    }

    public void setBlockGroups(Set<VoiceCarrierGroup> blockGroups) {
        this.blockGroups = blockGroups;
    }

    public boolean hasBlockGroups() {
        return this.blockGroups != null && !this.blockGroups.isEmpty();
    }

    public Set<VoiceCarrierGroup> getTestGroups() {
        return testGroups;
    }

    public void setTestGroups(Set<VoiceCarrierGroup> testGroups) {
        this.testGroups = testGroups;
    }

    public boolean hasTestGroups() {
        return this.testGroups != null && !this.testGroups.isEmpty();
    }

    @Override
    public String toString() {
        return "GcsRule [itestRule=" + testRule + ", pvStatusCategory=" + pvStatusCategory + ", cvStatusCategory=" + cvStatusCategory + ", blockGroups="
                + blockGroups + ", testGroups=" + testGroups + "]";
    }

}
