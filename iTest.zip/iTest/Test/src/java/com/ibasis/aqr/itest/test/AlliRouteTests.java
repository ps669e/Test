package com.ibasis.aqr.itest.test;


import junit.framework.Test;
import junit.framework.TestSuite;

public class AlliRouteTests {

	public static Test suite() {
		TestSuite suite = new TestSuite("iRoute JUnit Test Suite");
		suite.addTestSuite(PreferredRouteTest.class);
		suite.addTestSuite(EmbeddedTodTest.class);
		return suite;
	}

}
