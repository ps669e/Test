package com.ibasis.aqr.itest.domain;

import com.ibasis.aqr.itest.common.iTestConstants.TestProduct;

public class iTestVendor {

    private PreferredRoute prefRoute;
    private Provider provider;
    private double maxCost;
    private double maxNetCost;
    private FloorRate maxFloorRate;
    private int testOffers= -1;
    private boolean hasNewPattern; // if there are any new patterns
    private boolean passedEligibilityTest = false;
    private int priority = -1;
    private TestProduct testProduct;
    private TestRule testRule;

    @Override
    public String toString() {
        RouteStatus pvRouteStatus = getRouteStatusPv();
        RouteStatus ipRouteStatus = getRouteStatusCv();
        RouteClassification src = getSrc();

        StringBuffer buf = new StringBuffer();
        buf = buf.append("{iTestVendor:{")
        .append("pr:").append(prefRoute.getPreferredRouteId())
        .append(",vendor:").append(provider.getVendorId())
        .append(",pvRouteStatus:").append((pvRouteStatus != null ? pvRouteStatus.getCode() : ""))
        .append(",ipRouteStatus:").append((ipRouteStatus != null ? ipRouteStatus.getCode() : ""))
        .append(",maxCost:").append(maxCost)
        .append(",maxNetCost:").append(maxNetCost)
        .append(",src:" + src)
        .append(",slbr:").append(getSlbr())
        .append("}}");

        return buf.toString();
    }

    public iTestVendor(PreferredRoute prefRoute, Provider provider) {
        this.prefRoute = prefRoute;
        this.provider = provider;
    }

    public RouteClassification getSrc() {
        return prefRoute.getProviderSrc(provider);
    }

    public Integer getSlbr() {
        return prefRoute.getProviderSlbr(provider);
    }

    public PreferredRoute getPrefRoute() {
        return prefRoute;
    }

    public Provider getProvider() {
        return provider;
    }

    public double getMaxCost() {
        return maxCost;
    }

    public void setMaxCost(double maxCost) {
        this.maxCost = maxCost;
    }

    public double getMaxNetCost() {
        return maxNetCost;
    }

    public void setMaxNetCost(double maxNetCost) {
        this.maxNetCost = maxNetCost;
    }

    public FloorRate getMaxFloorRate() {
        return maxFloorRate;
    }

    public void setMaxFloorRate(FloorRate maxFloorRate) {
        this.maxFloorRate = maxFloorRate;
    }

    public RouteStatus getRouteStatusPv() {
        return prefRoute.getVendorRouteStatusPv(provider);
    }

    public RouteStatus getRouteStatusCv() {
        return prefRoute.getVendorRouteStatusCv(provider);
    }

    /**
     * Has vendor requested PV testing / re-test at PR level
     * @return
     */
    public boolean hasRequestedPvTesting() {
        return prefRoute.hasVendorRequestedPvTesting(provider);
    }

    /**
     * Has vendor requested CV testing / re-test at PR level
     * @return
     */
    public boolean hasRequestedCvTesting() {
        return prefRoute.hasVendorRequestedCvTesting(provider);
    }


    public boolean isTgInService() {
        return provider.isTgInService();
    }

    /**
     * Return true if PV status is not null and category is 'ROUTABLE'
     * @return
     */
    public boolean isRoutablePv() {
        RouteStatus rs = getRouteStatusPv();
        if (rs == null) {
            return false;
        }
        return DomainConstants.ROUTABLE == rs.getCategoryCode();
    }

    /**
     * Return true if PV status is null or category is NON-ROUTABLE
     * Use hasPvStatus method to check whether PV status is null
     * @return
     */
    public boolean isNonRoutablePv() {
        RouteStatus rs = getRouteStatusPv();
        if (rs == null) {
            return true;
        }
        return DomainConstants.NON_ROUTABLE == rs.getCategoryCode();
    }

    /**
     * Return true if CV status is not null and category is 'ROUTABLE'
     * @return
     */
    public boolean isRoutableCv() {
        RouteStatus rs = getRouteStatusCv();
        if (rs == null) {
            return false;
        }
        return DomainConstants.ROUTABLE == rs.getCategoryCode();
    }

    /**
     * Return true if CV status is null or category is NON-ROUTABLE
     * Use hasCvStatus method to check whether CV status is null
     * @return
     */
    public boolean isNonRoutableCv() {
        RouteStatus rs = getRouteStatusCv();
        if (rs == null) {
            return true;
        }
        return DomainConstants.NON_ROUTABLE == rs.getCategoryCode();
    }

    /**
     * Return true if PV status exist (not null)
     * @return
     */
    public boolean hasPvStatus() {
        return getRouteStatusPv() != null;
    }

    /**
     * Return true if CV status exist (not null)
     * @return
     */
    public boolean hasCvStatus() {
        return getRouteStatusCv() != null;
    }

    public int getTestOffers() {
        return testOffers;
    }

    public void setTestOffers(int testOffers) {
        this.testOffers = testOffers;
    }

    public boolean isPremium() {
        return testProduct != null ? testProduct.isPremium() : false;
    }

    /**
     * Return true if the vendor has new patterns added to the current preferred route
     *
     * @return
     */
    public boolean hasNewPattern() {
        return hasNewPattern;
    }

    /**
     * Set needTesting to true if the vendor has new patterns added to the current preferred route
     *
     * @param needTesting
     */
    public void setHasNewPattern(boolean hasNewPattern) {
        this.hasNewPattern = hasNewPattern;
    }

    public TestProduct getTestProduct() {
        return testProduct;
    }

    public void setTestProduct(TestProduct testProduct) {
        this.testProduct = testProduct;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public boolean isPassedEligibilityTest() {
        return passedEligibilityTest;
    }

    public void setPassedEligibilityTest(boolean passedEligibilityTest) {
        this.passedEligibilityTest = passedEligibilityTest;
    }

    public TestRule getTestRule() {
        return testRule;
    }

    public void setTestRule(TestRule testRule) {
        this.testRule = testRule;
    }

}
