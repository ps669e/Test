/*
 * GloabLCRReport.java
 * Created on April, 2018
 */

package net.ibasis.aqr.itest.reporter;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.common.iTestConstants.GcsRule;
import com.ibasis.aqr.itest.datamanager.iTestDataManager;
import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.domain.PreferredRoute;
import com.ibasis.aqr.itest.domain.TestRule;
import com.ibasis.aqr.itest.domain.VoiceCarrierGroup;
import com.ibasis.aqr.itest.domain.iTestVendor;
import com.ibasis.aqr.itest.util.AQRPropertyReader;

import net.ibasis.aqr.iroute.db.DBManager;
import net.ibasis.aqr.iroute.db.DatumStream;
import net.ibasis.aqr.iroute.db.DirectLoadProxy;
import net.ibasis.aqr.iroute.db.FileOutputProxy;
import net.ibasis.aqr.iroute.db.directload.NativeConnection;
import net.ibasis.aqr.itest.reporter.db.iTestVendorReportDBDataInitiator;

public class iTestVendorReport {

    private static Log logger = LogFactory.getLog(iTestVendorReport.class);

    /** Creates a new instance of TestVendorReport */

    private static final String DIRECT_PATH_BUFFER_SIZE_PARAM = "DIRECT_PATH_BUFFER_SIZE";
    private static final int DEFAULT_DIRPATH_BUFFER_SIZE = 16 * 1024 * 1024;
    private static final String SCHEMA_NAME_PARAM = "REPORT_SCHEMA_NAME";
    private static final String REPORT_USER_NAME_PARAM = "IROUTE_USERNAME";
    public static final int DEFAULT_THREAD_COUNT = 2;

    static String getReportSchemaName() {

        String schemaName = AQRPropertyReader.getProperty(SCHEMA_NAME_PARAM);
        if (schemaName == null) {
            schemaName = AQRPropertyReader.getProperty(REPORT_USER_NAME_PARAM);
        }
        return schemaName;
    }

    static int getDirectPathBufferSize() {
        String strBufSize = AQRPropertyReader.getProperty(DIRECT_PATH_BUFFER_SIZE_PARAM);
        if (strBufSize == null) {
            return DEFAULT_DIRPATH_BUFFER_SIZE;
        } else {
            try {
                int bsz = Integer.parseInt(strBufSize);
                return bsz;
            } catch (NumberFormatException e) {
                logger.error("Failed to parse direct path buffer size. String value: " + strBufSize + ". Default value will be used: "
                        + String.valueOf(DEFAULT_DIRPATH_BUFFER_SIZE));
            }
        }
        return DEFAULT_DIRPATH_BUFFER_SIZE;
    }

    public iTestVendorReport() {
    }

    public void saveReport(Connection c) throws SQLException {
        DBManager mgr = new DBManager();
        Statement stm = c.createStatement();
        try {
            stm.execute("TRUNCATE TABLE AQR_GLOBAL_ROUTING_REPORT");
        } finally {
            stm.close();
        }
    }

    private DatumStream stream = null;
    private DirectLoadProxy directload = null;

    public void init(NativeConnection ntvConnection) {
        int bufSize = 0;
        if (ReporterCommon.getITestVendorReportSaving() == ReporterCommon.DIRECT) {
            directload = new DirectLoadProxy(ntvConnection);
            directload.setSchemaName(getReportSchemaName());
            bufSize = getDirectPathBufferSize();
            logger.info("Direct load buffer size: " + String.valueOf(bufSize));
            stream = directload;
        } else {
            stream = new FileOutputProxy(ReporterCommon.getReportSavingDirectory());
        }
        //DirectLoadProxy or FileOutputProxy is preparing for report save,
        //it passes iTestVendorReportDBDataInitiator to set up table columns for insert,
        //referring to iTestVendorReportDBDataInitiator.initDatabaseData()
        stream.initStreamOperation(new iTestVendorReportDBDataInitiator(), bufSize);
    }

    private List<ReportVendor> createReportVendors(Collection<iTestVendor> testVendors) {
        if (testVendors != null && !testVendors.isEmpty()) {
            List<ReportVendor> reportVendors = new ArrayList<>(testVendors.size());
            for (iTestVendor testVendor : testVendors) {
                Set<VoiceCarrierGroup> blockGroups = null;
                Set<VoiceCarrierGroup> testGroups = null;

                TestRule testRule = testVendor.getTestRule();
                if (testRule != null) {
                    blockGroups = testRule.getBlockGroups();
                    testGroups = testRule.getTestGroups();
                }

                // If block groups or test groups exist, create 1 ReportVendor for each block group and test group,
                // otherwise just create 1 ReportVendor
                ReportVendor rptVendor = null;
                if ((blockGroups == null || blockGroups.isEmpty()) && (testGroups == null || testGroups.isEmpty())) {
                    rptVendor = new ReportVendor(testVendor);
                    reportVendors.add(rptVendor);
                } else {
                    if (blockGroups != null && !blockGroups.isEmpty()) {
                        for (VoiceCarrierGroup g : blockGroups) {
                            rptVendor = new ReportVendor(testVendor);
                            rptVendor.setOriginationId(g.getGroupId());
                            rptVendor.setGcsRule(GcsRule.B);
                            reportVendors.add(rptVendor);
                        }
                    }
                    if (testVendor.getPriority() > -1) {
                        // only writes vendors that have priority set (ie. can be tested in GCS with 200 offers)
                        if (testGroups != null && !testGroups.isEmpty()) {
                            for (VoiceCarrierGroup g : testGroups) {
                                rptVendor = new ReportVendor(testVendor);
                                rptVendor.setOriginationId(g.getGroupId());
                                rptVendor.setGcsRule(GcsRule.T);
                                reportVendors.add(rptVendor);
                            }
                        }
                    }
                }
            }
            return reportVendors;
        }

        return new ArrayList<>(0);
    }

    public void report(NativeConnection ntvConnection, iTestDataManager dataMgr) throws Exception {

        logger.info("Generating Test Vendor Report...");

        init(ntvConnection);

        int totalReportEntries = 0;

        Collection<Country> countries = dataMgr.getCountries();
        if (countries == null || countries.isEmpty()) {
            logger.warn("report() There are no countries avalible for report.");
            return;
        }

        try {
            for (Country country : countries) {
                Collection<PreferredRoute> prefRoutes = country.getPreferredRoutes();
                if (prefRoutes == null) {
                    logger.warn("report() skipping country that has no preferred routes " + country.getName());
                    continue;
                }

                for (PreferredRoute prefRt : country.getPreferredRoutes()) {
                    logger.info("Generating Test Vendor Report for preferred route: " + prefRt.getName());

                    Collection<iTestVendor> testVendors = prefRt.getiTestVendors();

                    List<ReportVendor> reportVendors = createReportVendors(testVendors);

                    totalReportEntries += reportVendors.size();

                    //Write the report to database or a file depending on stream (DirectLoadProxy or FileOutputProxy)
                    //choices are a vector of FinalRoutingChoice (implementing DatabaseDataDatum) objects
                    //if stream is DirectLoadProxy, it will setup FinalRoutingChoices objects as rows of insert data
                    //and save them to database table by calling native methods implemented in c++ (javadirectload library).
                    //If stream is FileOutputProxy, it will setup FinalRoutingChoices objects as rows of output data
                    //and print them out to a file.
                    for (ReportVendor vendor : reportVendors) {
                        stream.writeDatum(vendor);
                    }

                    reportVendors.clear();

                    logger.info("Report entries generated: " + String.valueOf(totalReportEntries));

                    long freeMemory = Runtime.getRuntime().freeMemory();

                    logger.info("Free memory " + String.valueOf(freeMemory));

                }
            }
        } catch (OutOfMemoryError e) {
            //            int choicesCount = choices.size();
            //            choices.clear();
            System.gc();
            logger.error("Out of memory error!!!!!!!!!!!!!!!!!!!!!!!!!");
            //            logger.error("choices count: " + String.valueOf(choicesCount));
            long freeMemory = Runtime.getRuntime().freeMemory();
            logger.error("Free memory " + String.valueOf(freeMemory));
        }

        finalizeReport();

    }

    public void finalizeReport() {
        stream.finishStreamOperation();
        if (directload != null) {
            directload.free();
        }
    }

}
