/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.rulesengine;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.datamanager.iTestDataManager;
import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.domain.DialPattern;
import com.ibasis.aqr.itest.domain.DomainConstants;
import com.ibasis.aqr.itest.domain.ProviderCoverage;
import com.ibasis.aqr.itest.domain.ProviderRate;
import com.ibasis.aqr.itest.domain.comparator.PatternRCComparator;
import com.ibasis.aqr.itest.tree.NodeNavigator;
import com.ibasis.aqr.itest.util.ListUtils;

/**
 * @author schan
 *
 */
public class PRCMerger implements NodeNavigator {

    private Log log = LogFactory.getLog(PRCMerger.class);

    private Country country;

    private MergeEqualOperator equalOperator;

    private MergeParentOperator parentOperator;

    private PatternRCComparator rcComparator;

    private iTestDataManager dataManager;

    public PRCMerger(iTestDataManager dmgr) throws Exception {
        equalOperator = new MergeEqualOperator();
        parentOperator = new MergeParentOperator();
        rcComparator = new PatternRCComparator();
        dataManager = dmgr;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @Override
    public boolean processNodeObject(Object object) {
        try {
            if (object instanceof DialPattern) {
                DialPattern pattern = (DialPattern) object;
                Country ctry = pattern.getCountry();
                if (ctry == this.country || ctry.isOverlapping()) { //Overlapping countries need to be processed
                    determineCoverage(pattern);
                    inheritPendingActiveFloors(pattern);
                    return true;
                }
            } else {
                log.error("processNodeObject() : Invalid Object Type!");
            }
        } catch (Exception e) {
            log.error("processNodeObject(): Exception", e);
        }
        return true;
    }

    /**
     * For each current dp's providerCoverages,
     * If it has no status, set it to parent's status.
     * Then add all providerCoverages that has status(would be inherited) and rate (would be inherited) to patternRtChoices.
     * Then merged patternRtChoices with parent dp's patternRoutingChoices, save the merged list to current dp.patternRoutingChoices.
     *
     * @param dialPattern
     * @throws Exception
     */
    private void determineCoverage(DialPattern dialPattern) throws Exception {
        try {
            Collection<ProviderCoverage> currentDpProvCvgs = dialPattern.getProviderCoverages();
            List<ProviderCoverage> patternRtChoices = null;
            //for each prov cvg, create patttern routing choices
            if (currentDpProvCvgs != null) {
                if (log.isDebugEnabled()) {
                    log.debug("determineCoverage(): Creating pattern routing choices for dial pattern " + dialPattern.getPattern());
                }
                patternRtChoices = new ArrayList<>();
                for (ProviderCoverage currProvCvg : currentDpProvCvgs) {

                    // don't need to do status code inheritance as vendor status is defined at pref. route level
//                    if (currProvCvg.getRouteStatusCode() == null /* && !currProvCvg.isPartialCoverageInd() */) {
//                        inheritStatusCode(currProvCvg);
//                    }

                    //if (currProvCvg.getRouteStatusCode() != null) {
                        //                        Collection obs = currProvCvg.getProvider().getOutbounds();
                        //                        if (obs != null && !obs.isEmpty()) { //NO Outbounds
                        createPatternRoutingChoices(currProvCvg, patternRtChoices);
                        //                        } else {
                        //                            if (iTestConstants.OUT_CVG_LOG && log.isWarnEnabled()) {
                        //                                log.warn("determineCoverage(): Will not process VendorId " + currProvCvg.getProvider().getVendorId() + ", pattern "
                        //                                        + currProvCvg.getDialPattern().getPattern() + " coverage due to no carrier site key or outbound found in AQR.");
                        //                            }
                        //                        }
                    //} else {
                    //    if (log.isDebugEnabled()) {
                    //        log.debug("determineCoverage(): Will not process VendorId " + currProvCvg.getProvider().getVendorId() + ", pattern "
                    //                + currProvCvg.getDialPattern().getPattern() + " coverage due to no route status code.");
                    //    }
                    //}
                }
            }

            if (patternRtChoices != null && patternRtChoices.size() > 1) {
                Collections.sort(patternRtChoices, rcComparator); // sort by vendor id
            }
            Country ctry = dialPattern.getCountry();
            DialPattern parentDp = dialPattern.getParent(dialPattern.getCountry());
            while (parentDp != null) { //This is a russia - kazakhstan cluge !
                Country parCtry = parentDp.getCountry();
                List<ProviderCoverage> parentRtChoices = parentDp.getPatternRoutingChoices();
                if (parentRtChoices != null && !parentRtChoices.isEmpty()) {
                    // Inherit parent coverage - mergedList combines parent dp's patternRoutingChoices and current dp's patternRoutingChoices
                    equalOperator.setDialPattern(dialPattern);
                    parentOperator.setDialPattern(dialPattern);
                    List<ProviderCoverage> mergedList = new ArrayList<>();
                    ListUtils.mergeSort(parentRtChoices, patternRtChoices, rcComparator, mergedList, equalOperator, parentOperator, null);
                    patternRtChoices = mergedList;
                    mergedList = null;
                }
                if (ctry != parCtry && !ctry.isOverlapping() && parCtry.isOverlapping()) { //e.g., Russia is not overlapping - Kazakhstan is
                    //So for a Russia pattern merging in Kaz,
                    //we need to keep jumping to merge in Russia above Kaz
                    //as Kaz will not have merged parent Russia onto it.
                    //Talk about a cluge!
                    while (parentDp != null && parentDp.getCountry() != ctry) { //The Russia - Kazakhstan Cluge
                        parentDp = parentDp.getParent(ctry);
                    }
                } else {
                    parentDp = null;
                }
            }

            if (patternRtChoices != null && !patternRtChoices.isEmpty()) {
                dialPattern.setPatternRoutingChoices(patternRtChoices);
            }

        } catch (Exception e) {
            log.error("Exception in determineCoverage(dialPatterns): ", e);
            throw e;
        }
    }

    private void createPatternRoutingChoices(ProviderCoverage currProvCvg, List<ProviderCoverage> patternRtChoices) throws Exception {
        Map<Integer, ProviderRate> todProvRates = currProvCvg.getProviderRates(); // will get parent pattern's rates if current pattern has no rates
        //TOD - add cvg to patternRtChoices if it has peak rate
        if (todProvRates != null && todProvRates.get(DomainConstants.RMS_PEAK_PERIOD_ID) != null) {
            patternRtChoices.add(currProvCvg);
        } else {
            if (log.isDebugEnabled()) {
                log.debug("createPatternRoutingChoices(): Missing peak rate for provider: " + currProvCvg.getProvider().getName() + " VendorId: "
                        + currProvCvg.getProvider().getVendorId() + " ..for dial pattern: " + currProvCvg.getDialPattern().getPattern()
                        + ". This provider coverage will not be processed.");
            }
        }
    }

    private void inheritPendingActiveFloors(DialPattern dp) throws Exception {
        if (!dp.getIsPRPattern()) {
            Country ctry = dp.getCountry();
            DialPattern parentDp = dp.getParent(ctry);
            while (parentDp != null) {
                Country parCtry = parentDp.getCountry();
                if (dp.getPreferredRoute().equals(parentDp.getPreferredRoute()) && parentDp.getPendingActiveFloorRates() != null
                        && dp.getPendingActiveFloorRates() == null) {
                    dp.setPendingActiveFloorRates(parentDp.getPendingActiveFloorRates());
                }

                if (ctry != parCtry && !ctry.isOverlapping() && parCtry.isOverlapping()) { //e.g., Russia is not overlapping - Kazakhstan is
                    //So for a Russia pattern merging in Kaz,
                    //we need to keep jumping to merge in Russia above Kaz
                    //as Kaz will not have merged parent Russia onto it.
                    //Talk about a cluge!
                    while (parentDp != null && parentDp.getCountry() != ctry) { //The Russia - Kazakhstan Cluge
                        parentDp = parentDp.getParent(ctry);
                    }
                } else {
                    parentDp = null;
                }
            }
        }
    }

}

class MergeEqualOperator implements ListUtils.Operator {
    private DialPattern dialPattern;

    MergeEqualOperator() {
    }

    public void setDialPattern(DialPattern dp) {
        dialPattern = dp;
    }

    @Override
    public Object operate(Object obj) throws Exception {
        return obj;
    }

    @Override
    public Object operate(Object parent, Object child) throws Exception {
        ProviderCoverage parentChoice = (ProviderCoverage) parent;
        ProviderCoverage childChoice = (ProviderCoverage) child;
        return child;
    }

}

class MergeParentOperator implements ListUtils.Operator {
    private DialPattern dialPattern;

    public void setDialPattern(DialPattern dp) {
        dialPattern = dp;
    }

    @Override
    public Object operate(Object parent) throws Exception {
        Object retObj = null;

        ProviderCoverage parentChoice = (ProviderCoverage) parent;

        retObj = parentChoice;

        return retObj;
    }

    @Override
    public Object operate(Object parent, Object child) throws Exception {
        return parent;
    }

}
