package com.ibasis.aqr.itest.util;

import com.ibasis.aqr.itest.config.iTestConfigManager;

/**
 * @author schan
 *
 */
public class TimeUtils {

    /**
     * Convert the given time (HH:MM:SS) to minutes
     * eg. time 07:00:00 = 25200
     *
     * If input time is "23:59:59", this method will first convert it to "00:00:00"
     *
     * @param time "HH:MM:SS"
     * @return seconds
     */
    public static final int time2Seconds(String time) {
        int seconds = 0;
        if (time != null && time.trim().length() > 0) {
            String defaultEndTime = iTestConfigManager.getInstance().getTodDefaultWeekDayStopTime();
            if (time.equals(defaultEndTime)) {
                time = "00:00:00";
            }
            String[] tokens = time.split(":");
            for (int i = 0; i < tokens.length; i++) {
                if (i == 0) {
                    //hour
                    seconds += Integer.parseInt(tokens[i]) * 60 * 60;
                } else if (i == 1) {
                    //minute
                    seconds += Integer.parseInt(tokens[i]) * 60;
                } else {
                    //second
                    seconds += Integer.parseInt(tokens[i]);
                }
            }
        }
        return seconds;
    }
}
