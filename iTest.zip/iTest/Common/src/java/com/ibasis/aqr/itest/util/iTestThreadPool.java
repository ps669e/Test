/*
 * Author Sib Chatterjee
 * Created on Nov 10, 2004
 * Copyright: 2004 Zovel, Inc
 * Last Modified on Nov 10, 2004
 * Last Modifed By Sib Chatterjee
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.ibasis.aqr.itest.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import EDU.oswego.cs.dl.util.concurrent.BoundedBuffer;
import EDU.oswego.cs.dl.util.concurrent.PooledExecutor;

/**
 * @author Sib Chatterjee
 *
 *         <a href="mailto:zovel@comcast.net">Sib Chatterjee </a>
 *
 *         To change the template for this generated type comment go to Window -
 *         Preferences - Java - Code Generation - Code and Comments
 */
public class iTestThreadPool {
    // initialize to use a maximum of 8 threads.
    private static Log logger = LogFactory.getLog(iTestThreadPool.class);
    private static int minPoolSize = 4;
    private static int maxPoolSize = 10;
    private static int boundedTasks = 6;
    private static int keepAliveMins = 240;
    private static int preStartThreads = 4;

    public static PooledExecutor pool;
    static {
        try {
            //Using a bounded buffer of boundedTasks tasks, at least minPoolSize threads (started only when needed
            //due to incoming requests), but allowing up to maxPoolSize threads if the buffer gets full.
            //pre-start configured threads, allowing them to die if they are not used for 10 minutes
            String strMinPoolSize = AQRPropertyReader.getProperty("THREAD_POOL_MIN_SIZE");
            if (strMinPoolSize != null && strMinPoolSize.length() > 0) {
                minPoolSize = Integer.parseInt(strMinPoolSize);
            }
            String strMaxPoolSize = AQRPropertyReader.getProperty("THREAD_POOL_MAX_SIZE");
            if (strMaxPoolSize != null && strMaxPoolSize.length() > 0) {
                maxPoolSize = Integer.parseInt(strMaxPoolSize);
            }
            String strBoundedTasks = AQRPropertyReader.getProperty("BOUNDED_TASKS");
            if (strBoundedTasks != null && strBoundedTasks.length() > 0) {
                boundedTasks = Integer.parseInt(strBoundedTasks);
            }
            String strKeepAliveMins = AQRPropertyReader.getProperty("THREAD_KEEP_ALIVE_MINS");
            if (strKeepAliveMins != null && strKeepAliveMins.length() > 0) {
                keepAliveMins = Integer.parseInt(strKeepAliveMins);
            }
            String strPreStartThreads = AQRPropertyReader.getProperty("THREAD_PRE_START");
            if (strPreStartThreads != null && strPreStartThreads.length() > 0) {
                preStartThreads = Integer.parseInt(strPreStartThreads);
            }

            pool = new PooledExecutor(new BoundedBuffer(boundedTasks), maxPoolSize);
            pool.setMinimumPoolSize(minPoolSize);
            pool.setKeepAliveTime(1000 * 60 * keepAliveMins);
            pool.createThreads(preStartThreads);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.error("Exception Initializing thread pool ", e);
        }
    }
}