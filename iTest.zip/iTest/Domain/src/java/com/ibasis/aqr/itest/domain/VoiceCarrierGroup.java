package com.ibasis.aqr.itest.domain;

public class VoiceCarrierGroup {

    private long groupId;
    private String groupName;
    private String direction;
    private Product product;
    private long customerTypeId = DomainConstants.NULL_LONG_VALUE;
    private long pamTrafficGroupId = DomainConstants.NULL_LONG_VALUE;

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public long getCustomerTypeId() {
        return customerTypeId;
    }

    public void setCustomerTypeId(long customerTypeId) {
        this.customerTypeId = customerTypeId;
    }

    public long getPamTrafficGroupId() {
        return pamTrafficGroupId;
    }

    public void setPamTrafficGroupId(long pamTrafficGroupId) {
        this.pamTrafficGroupId = pamTrafficGroupId;
    }

    @Override
    public String toString() {
        return "{id:" + getGroupId() + ",name:" + getGroupName() + ",prodId:"
                + (product == null ? DomainConstants.NULL_LONG_VALUE : getProduct().getProductId()) + ",custType:" + getCustomerTypeId() + ",pmTrafficGroup:"
                + getPamTrafficGroupId() + "}";
    }
}
