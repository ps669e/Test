/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.domain;

/**
 * @author schan
 *
 */
public class Product {

    private long productId; //product key in RMS

    private String description = ""; //product name

    private boolean exception = false; //is exception product

    /**
     * default constructor
     *
     */
    public Product() {
    }

    /**
     * constructor
     *
     * @param productId
     * @param name
     * @param exc
     */
    public Product(long productId, String name, boolean exc) {
        this.productId = productId;
        this.description = name;
        this.exception = exc;
    }

    public long getProductId() {
        return this.productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String name) {
        this.description = name;
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof Product)) {
            return false;
        }
        Product castOther = (Product) other;
        return this.getProductId() == castOther.getProductId();
    }

    public boolean equals(Product other) {
        return this.getProductId() == other.getProductId();
    }

    @Override
    public int hashCode() {
        return Long.valueOf(productId).hashCode();
    }

    @Override
    public String toString() {
        return "{id:" + getProductId() + ",name:" + getDescription() + ",ex:" + isException() + "}";
    }

    /**
     * @return Returns the exception.
     */
    public boolean isException() {
        return exception;
    }

    /**
     * @param exception The exception to set.
     */
    public void setException(boolean exception) {
        this.exception = exception;
    }

}
