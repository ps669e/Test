/*
 * Created on Aug 19, 2004
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ibasis.aqr.itest.domain;

/**
 *
 * Domain class representing Provider
 *
 * @author schan
 */
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Provider implements Comparable<Provider> {

    private long carrierKey; //carrier key

    private String name; //name in AQR

    private Collection<Outbound> outbounds = null; //outbounds defined in AQR for this carrier

    private String shortName; //carrier short name in AQR

    private String providerName = ""; //name in RMS

    private char autoRouted; //whether auto routed - RMS field to output in reporting

    private int vendorTypeId = 1; //RMS field to output in reporting

    private long vendorId; //vendor id in RMS

    private int sourceNetworkId;

    private boolean tgInService = false;

    /**
     *
     * Default constructor
     */
    public Provider() {
    }

    /**
     * @param vendorId
     * @param provName
     * @param autRouted
     * @param typeID
     * @param sourceNetworkID
     * @param tgInService
     */
    public Provider(long vendorId, String provName, String autRouted, int typeID, int sourceNetworkID, boolean tgInService) {
        this.setVendorId(vendorId);
        this.setProviderName(provName);
        this.setAutoRouted(autRouted);
        this.setVendorTypeId(typeID);
        this.setSourceNetworkId(sourceNetworkID);
        this.setTgInService(tgInService);
    }

    /**
     * constructor - Mid Server
     *
     * @param provName
     * @param autRouted
     * @param typeID
     * @param vID
     */
    public Provider(String provName, String autRouted, int typeID, long vID) {
        this.setProviderName(provName);
        this.setAutoRouted(autRouted);
        this.setVendorTypeId(typeID);
        this.setVendorId(vID);
    }

    public long getProviderKey() {
        return this.carrierKey;
    }

    public void setProviderKey(long inProviderKey) {
        this.carrierKey = inProviderKey;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String inName) {
        this.name = inName;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public long getCarrierKey() {
        return this.carrierKey;
    }

    public void setCarrierKey(long key) {
        this.carrierKey = key;
    }

    public Collection<Outbound> getOutbounds() {
        return this.outbounds;
    }

    public void addOutbound(Outbound ob) {
        if (this.outbounds == null) {
            this.outbounds = new ArrayList<>();
        }
        this.outbounds.add(ob);
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof Provider)) {
            return false;
        }
        Provider castOther = (Provider) other;
        return this.equals(castOther);
    }

    public boolean equals(Provider other) {
        return this.getVendorId() == other.getVendorId();
    }

    @Override
    public int hashCode() {
        return Long.valueOf(vendorId).hashCode();
    }

    //    @Override
    //    public int compareTo(Object other) {
    //        Provider castOther = (Provider) other;
    //        return compareTo(castOther);
    //    }

    @Override
    public int compareTo(Provider other) {
        long retVal = vendorId - other.vendorId;
        if (retVal > 0) {
            return 1;
        } else if (retVal < 0) {
            return -1;
        }
        return 0;
    }

    /**
     * @return Returns the isAutoRouted.
     */
    public char getAutoRouted() {
        return autoRouted;
    }

    /**
     * @param isAutoRouted
     *            The isAutoRouted to set.
     */
    public void setAutoRouted(String autoRouted) {
        this.autoRouted = autoRouted.charAt(0);
    }

    /**
     * @return Returns the providerName.
     */
    public String getProviderName() {
        return providerName;
    }

    /**
     * @param providerName
     *            The providerName to set.
     */
    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    /**
     * @return Returns the vendorTypeId.
     */
    public int getVendorTypeId() {
        return vendorTypeId;
    }

    /**
     * @param vendorTypeId
     */
    public void setVendorTypeId(int vendorTypeId) {
        this.vendorTypeId = vendorTypeId;
    }

    /**
     * @return Returns the vendorId.
     */
    public long getVendorId() {
        return vendorId;
    }

    /**
     * @param vendorId The vendorId to set.
     */
    public void setVendorId(long vendorId) {
        this.vendorId = vendorId;
    }

    public Outbound getOutbound(long csKey) {
        if (outbounds != null && !outbounds.isEmpty()) {
            Iterator obs = outbounds.iterator();
            while (obs.hasNext()) {
                Outbound ob = (Outbound) obs.next();
                if (ob.getCsKey().longValue() == csKey) {
                    return ob;
                }
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "{id:" + this.vendorId + ",name:" + this.providerName + "}";
    }

    public int getSourceNetworkId() {
        return sourceNetworkId;
    }

    public void setSourceNetworkId(int sourceNetworkId) {
        this.sourceNetworkId = sourceNetworkId;
    }

    public boolean isTDMVendor() {
        return sourceNetworkId == DomainConstants.SOURCE_NETWORK_ID_TDM;
    }

    public boolean isTgInService() {
        return tgInService;
    }

    public void setTgInService(boolean isTgInService) {
        this.tgInService = isTgInService;
    }

}
