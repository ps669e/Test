package net.ibasis.aqr.itest.reporter;

import com.ibasis.aqr.itest.common.iTestConstants.GcsRule;
import com.ibasis.aqr.itest.domain.RouteClassification;
import com.ibasis.aqr.itest.domain.RouteStatus;
import com.ibasis.aqr.itest.domain.iTestVendor;

import net.ibasis.aqr.iroute.db.DatabaseData;
import net.ibasis.aqr.iroute.db.DatabaseDataInterface;

public class ReportVendor implements net.ibasis.aqr.iroute.db.DatabaseDataDatum {

    private iTestVendor testVendor;

    private long originationId = -1L;
    private GcsRule gcsRule;

    public ReportVendor(iTestVendor testVendor) {
        this.testVendor = testVendor;
    }

    @Override
    public void retrieveKey(DatabaseData d, int row) {
    }

    public void setOriginationId(long originationId) {
        this.originationId = originationId;
    }

    public void setGcsRule(GcsRule gcsRule) {
        this.gcsRule = gcsRule;
    }

    @Override
    public void setValues(int operationType, DatabaseDataInterface d, int row) {

        switch (operationType) {

            case DatabaseData.INSERT:

                int idx = 0;
                d.setInt(idx++, row, (int) testVendor.getPrefRoute().getCountryId()); // COUNTRY_ID NUMBER(10,0)
                d.setChar(idx++, row, testVendor.getPrefRoute().getCountry().isGcsEnabled() ? 'Y' : 'N'); // GCS_ENABLED CHAR(1 BYTE)
                d.setInt(idx++, row, (int) testVendor.getPrefRoute().getPreferredRouteId()); //  PREFERRED_ROUTE_ID NUMBER(6,0)
                d.setInt(idx++, row, (int) testVendor.getProvider().getVendorId()); // VENDOR_ID NUMBER(6,0),
                d.setInt(idx++, row, (int) this.originationId); // GROUP_ID NUMBER(6),

                if (testVendor.getTestProduct() != null) {
                    d.setChar(idx++, row, testVendor.isPremium() ? 'Y' : 'N'); // IS_PREMIUM CHAR(1 BYTE),
                } else {
                    d.setChar(idx++, row, "X".charAt(0)); // IS_PREMIUM CHAR(1 BYTE)
                }

                d.setInt(idx++, row, 1); // RATE_PERIOD_ID NUMBER(10,0)
                d.setDouble(idx++, row, testVendor.getMaxFloorRate() != null ? testVendor.getMaxFloorRate().getFloorRate() : -1); // MAX_PROD_GROUP_FLOOR_RATE NUMBER(12,4)
                d.setDouble(idx++, row, testVendor.getMaxCost()); // MAX_COST NUMBER(12,4)
                d.setDouble(idx++, row, testVendor.getMaxNetCost()); // MAX_NET_COST NUMBER(12,4)

                //PV status
                RouteStatus routeStatus = testVendor.getRouteStatusPv();
                int statusId = -1;
                String statusCode = "-1";
                if (routeStatus != null) {
                    statusId = (int) routeStatus.getId();
                    statusCode = String.valueOf(routeStatus.getCode());
                }
                d.setInt(idx++, row, statusId); // ROUTE_STATUS_ID NUMBER(10,0)
                d.setString(idx++, row, statusCode); // ROUTE_STATUS_CODE VARCHAR2(4),

                //CV status
                routeStatus = testVendor.getRouteStatusCv();
                statusId = -1;
                statusCode = "-1";
                if (routeStatus != null) {
                    statusId = (int) routeStatus.getId();
                    statusCode = String.valueOf(routeStatus.getCode());
                }
                d.setInt(idx++, row, statusId); // ROUTE_STATUS_ID NUMBER(10,0)
                d.setString(idx++, row, statusCode); // ROUTE_STATUS_CODE VARCHAR2(4),

                d.setInt(idx++, row, testVendor.getPriority()); // PRIORITY NUMBER(10,0)
                d.setInt(idx++, row, testVendor.getTestOffers()); // NUM_OF_OFFERS NUMBER
                d.setChar(idx++, row, testVendor.isTgInService() ? 'Y' : 'N'); // TG_IN_SERVICE CHAR(1 BYTE)

                int srcId = -1;
                RouteClassification src = testVendor.getSrc();
                if (src != null) {
                    srcId = (int) src.getRouteClassificationId();
                }
                d.setInt(idx++, row, srcId); // ROUTE_CLASSIFICATION_ID NUMBER(6,0)

                Integer slbr = testVendor.getSlbr();
                if (slbr == null) {
                    slbr = -1;
                }
                d.setInt(idx++, row, slbr); // SLBR NUMBER(3)

                d.setChar(idx++, row, testVendor.isPassedEligibilityTest() ? 'Y' : 'N'); // PASSED_TEST_ELIGIBILITY CHAR(1 BYTE)

                if (this.gcsRule != null) {
                    d.setChar(idx++, row, this.gcsRule.getRule().charAt(0)); // GCS_RULE CHAR(1)
                } else {
                    d.setChar(idx++, row, "X".charAt(0)); // GCS_RULE CHAR(1)
                }
                d.setChar(idx++, row, testVendor.hasNewPattern() ? 'Y' : 'N'); // HAS_NEW_PATTERN CHAR(1)

                d.setChar(idx++, row, testVendor.getPrefRoute().getCountry().isItestEnabled() ? 'Y' : 'N'); // ITEST_ENABLED CHAR(1 BYTE)

                break;
            default:
                throw new net.ibasis.aqr.itest.reporter.ReporterException("Unsupported operation");
        }

    }

}
