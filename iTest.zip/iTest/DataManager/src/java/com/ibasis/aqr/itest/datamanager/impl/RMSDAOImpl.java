/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.datamanager.impl;

/**
 *
 * This class encapsulates the RMS datasource. All RMS related data access is limited to
 * this class.
 *
 * @author schan
 */

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.common.iTestConstants;
import com.ibasis.aqr.itest.datamanager.DataManagerConstants;
import com.ibasis.aqr.itest.datamanager.intf.RMSDAO;
import com.ibasis.aqr.itest.db.DBConnection;
import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.domain.DialPattern;
import com.ibasis.aqr.itest.domain.DomainConstants;
import com.ibasis.aqr.itest.domain.FloorRate;
import com.ibasis.aqr.itest.domain.PreferredRoute;
import com.ibasis.aqr.itest.domain.Product;
import com.ibasis.aqr.itest.domain.Provider;
import com.ibasis.aqr.itest.domain.RatePeriod;
import com.ibasis.aqr.itest.domain.RouteClassification;
import com.ibasis.aqr.itest.domain.RouteStatus;
import com.ibasis.aqr.itest.domain.TestRule;
import com.ibasis.aqr.itest.domain.TimeOfDay;
import com.ibasis.aqr.itest.domain.VoiceCarrierGroup;
import com.ibasis.aqr.itest.dpmanager.DialPatternMgr;
import com.ibasis.aqr.itest.util.AQRPropertyReader;

public class RMSDAOImpl implements RMSDAO {

    private static final Log logger = LogFactory.getLog(RMSDAOImpl.class);

    /**
     * Which version of iTest. This is used to make sure we're running the correct version of iTest.
     */
    private String verData = null;

    //Map to hold all Providers currently in RMS
    private Map<Long, Provider> providers = new HashMap<>();

    //Map to hold all IP Route Status Codes in RMS
    private Map<Long, RouteStatus> cvStatusCodes = new HashMap<>();

    //Map to hold all PV Route Status Codes in RMS
    private Map<Long, RouteStatus> pvStatusCodes = new HashMap<>();

    // Map to hold all Products currently in RMS
    private Map<Long, Product> products = new HashMap<>();

    // Map to hold all countries currently in RMS
    private Map<Long, Country> countries = new HashMap<>();

    // Map to hold all preferred routes currently in RMS
    private Map<Long, PreferredRoute> preferredRoutes = new HashMap<>(1000);

    private Map<Long, RouteClassification> routeClassifications = new HashMap<>();

    //Map to hold rate periods
    private Map<Integer, RatePeriod> ratePeriods = null;

    private Map<Long, VoiceCarrierGroup> voiceCarrierGroups = new HashMap<>();

    private Map<Integer, Set<Product>> slbrFloorProducts = new HashMap<>();

    /**
     * key format: ITVW_ITEST_GCS_RULES.ITEST_RULE + "." + ITVW_ITEST_GCS_RULES.PV_STATUS_CATEGORY + "." + ITVW_ITEST_GCS_RULES.CV_STATUS_CATEGORY
     */
    private Map<String, TestRule> gcsRules = new HashMap<>();

    private DBConnection dbConnection = null;

    //fetch sizes for jdbc
    private int fsCountry = 300;
    private int fsPreferredRoute = 1000;
    private int fsProduct = 1000;
    private int fsFloorRate = 1000;
    private int fsPrPattern = 1000;
    private int fsVendorStatus = 1000;
    private int fsVendorRate = 10000;
    private int fsVendorSrc = 10000;
    private int fsProvider = 1000;
    private int fsDp = 100;
    private int fsPendingFloor = 100;

    /**
     * Constructor
     *
     * @param connection DBConnection utility to obtain db connection
     */
    public RMSDAOImpl(DBConnection connection) {
        this.dbConnection = connection;
        init();
    }

    /**
     *
     * Initialization of run-time parameters
     */
    private void init() {
        try {
            String strCtrySz = AQRPropertyReader.getProperty("COUNTRY_FETCH_SIZE");
            fsCountry = strCtrySz == null ? fsCountry : Integer.parseInt(strCtrySz);
            String strPfrtSz = AQRPropertyReader.getProperty("PREFERRED_ROUTE_FETCH_SIZE");
            fsPreferredRoute = strPfrtSz == null ? fsPreferredRoute : Integer.parseInt(strPfrtSz);
            String strFlrtSz = AQRPropertyReader.getProperty("FLOOR_RATE_FETCH_SIZE");
            fsFloorRate = strFlrtSz == null ? fsFloorRate : Integer.parseInt(strFlrtSz);
            String strPendingActiveFlrtSz = AQRPropertyReader.getProperty("FLOOR_RATE_PENDING_ACTIVE_FETCH_SIZE");
            fsPendingFloor = strPendingActiveFlrtSz == null ? fsPendingFloor : Integer.parseInt(strPendingActiveFlrtSz);
            String strPrPatSz = AQRPropertyReader.getProperty("PR_PATTERNS_FETCH_SIZE");
            fsPrPattern = strPrPatSz == null ? fsPrPattern : Integer.parseInt(strPrPatSz);
            String strRateSz = AQRPropertyReader.getProperty("VENDOR_ROUTE_SUMMARY_FETCH_SIZE");
            fsVendorRate = strRateSz == null ? fsVendorRate : Integer.parseInt(strRateSz);
            String strClassiSz = AQRPropertyReader.getProperty("VENDOR_ROUTE_CLASSIFICATION_FETCH_SIZE");
            fsVendorSrc = strClassiSz == null ? fsVendorSrc : Integer.parseInt(strClassiSz);
            String strProvdrSz = AQRPropertyReader.getProperty("PROVIDER_FETCH_SIZE");
            fsProvider = strProvdrSz == null ? fsProvider : Integer.parseInt(strProvdrSz);
            String strDpSz = AQRPropertyReader.getProperty("DP_FETCH_SIZE");
            fsDp = strDpSz == null ? fsDp : Integer.parseInt(strDpSz);
        } catch (NumberFormatException e) {
            logger.error("init(): Generated exception. Default values will be used", e);
        }
    }

    /**
     * Get iTest version
     *
     * @return the iTest version
     * @throws Exception
     */
    @Override
    public String getVersion() throws Exception {
        if (verData == null) {
            Connection con = null;
            Statement stmt = null;
            ResultSet rs = null;
            try {
                con = dbConnection.getRMSConnection();
                String ver = null;
                if (con != null) {
                    stmt = con.createStatement();
                    rs = stmt.executeQuery(RMSQueries.VERSION);
                    if (rs.next()) {
                        ver = rs.getString(1/* "VERSION" */);
                    }
                } else {
                    logger.error("getVersion(): iTest connection is null!");
                }
                if (ver != null && ver.length() > 0) {
                    verData = ver;
                } else {
                    verData = "-999.999.999.999";
                    logger.error("getVersion(): iTest Version not set in data base");
                }
            } catch (Exception ex) {
                logger.error("getVersion() : Exception caught", ex);
                throw ex;
            } finally {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            }
        }
        return verData;
    }

    /**
     * Call to pre-process with an adjusted current time based on
     * what time iTest is running. If we are withtin the RATE_ROLLOVER_HOURS
     * of GMT mid-night then we roll over to next day, otherwise we run on current time.
     * E.g. if RATE_ROLL_OVER_HOURS is set to 12 hours, then if iTest is running
     * within 12 hours of GMT mid-night it will adjust curren time by adding the
     * roll over hours to curren time.
     */
    @Override
    public int genRmsFeed() throws Exception {
        int retVal = -1;
        Connection con = null;
        CallableStatement callst = null;
        try {
            con = dbConnection.getRMSConnection();
            if (con != null) {
                callst = con.prepareCall(DataManagerConstants.PRE_PROCESS_CALL);
                callst.registerOutParameter(1, Types.INTEGER);
                Calendar cal = Calendar.getInstance(TimeZone.getDefault());
                logger.info("genRmsFeed(): Current Time : " + cal.getTime());
                int today = cal.get(Calendar.DAY_OF_WEEK);
                if (iTestConstants.RATE_ROLLOVER_HOURS > 0) {
                    logger.info("genRmsFeed(): RATE_ROLLOVER_HOURS set to : " + iTestConstants.RATE_ROLLOVER_HOURS);
                    cal.add(Calendar.HOUR, iTestConstants.RATE_ROLLOVER_HOURS);
                    int adjtoday = cal.get(Calendar.DAY_OF_WEEK);
                    if (today != adjtoday) {
                        logger.info("genRmsFeed(): Rolling over to next day for rates.");
                    } else {
                        cal.add(Calendar.HOUR, -1 * iTestConstants.RATE_ROLLOVER_HOURS);
                    }
                } else {
                    logger.warn("genRmsFeed(): RATE_ROLLOVER_HOURS is not set!");
                }
                logger.info("genRmsFeed(): Executing oracle function " + DataManagerConstants.PRE_PROCESS_CALL + " Time : " + cal.getTime() + " ...");
                java.sql.Date jsqlDt = new java.sql.Date(cal.getTime().getTime());
                callst.setDate(2, jsqlDt);
                callst.execute();
                retVal = callst.getInt(1);
                if (retVal == 0) {
                    logger.info("genRmsFeed(): Successfully executed oracle function  " + DataManagerConstants.PRE_PROCESS_CALL);
                } else {
                    logger.info("genRmsFeed(): Failed executing oracle function " + DataManagerConstants.PRE_PROCESS_CALL + ". Error returned - " + retVal);
                }
            } else {
                logger.error("genRmsFeed(): Failed to get DB connection!");
            }
        } catch (Exception ex) {
            logger.error("genRmsFeed(): Generated exception", ex);
            throw ex;
        } finally {
            if (callst != null) {
                callst.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return retVal;
    }

    /**
     * Calls RMS post-process
     */
    @Override
    public int genRmsResult() throws Exception {
        int retVal = -1;
        Connection con = null;
        CallableStatement callst = null;
        try {
            con = dbConnection.getRMSConnection();
            if (con != null) {
                logger.info("genRmsResult(): Executing oracle function " + DataManagerConstants.POST_PROCESS_CALL + " ...");
                callst = con.prepareCall(DataManagerConstants.POST_PROCESS_CALL);
                callst.registerOutParameter(1, Types.INTEGER);
                Calendar cal = Calendar.getInstance(TimeZone.getDefault());
                java.sql.Date jsqlDt = new java.sql.Date(cal.getTime().getTime());
                //callst.setDate(2, jsqlDt);
                //Adding this timeout, as it has been observed often to never return.
                if (iTestConstants.RMS_QRY_TIMEOUT_MIN > 0) {
                    logger.info("genRmsResult(): Time out is set to " + iTestConstants.RMS_QRY_TIMEOUT_MIN + " minutes.");
                    callst.setQueryTimeout(iTestConstants.RMS_QRY_TIMEOUT_MIN * 60);
                } else {
                    logger.info("genRmsResult(): No time out is set");
                }
                callst.execute();
                retVal = callst.getInt(1);
                if (retVal == 0) {
                    logger.info("genRmsResult(): Successfully executed oracle function " + DataManagerConstants.POST_PROCESS_CALL);
                } else {
                    logger.info("genRmsResult(): Failed executing oracle function " + DataManagerConstants.POST_PROCESS_CALL + ". Error returned - " + retVal);
                }
            } else {
                logger.error("genRmsResult(): Failed to get DB connection!");
            }
        } catch (Exception ex) {
            logger.error("genRmsResult(): Generated exception", ex);
            throw ex;
        } finally {
            if (callst != null) {
                callst.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return retVal;
    }

    /**
     * Loads all current sys vars, providers, products, route status code defs,
     * blking incl codes, countires, & pref routes. This is loaded prior to
     * batch loading.
     *
     * @param dpMgr DialPatternMgr to find patterns in memory
     * @param systemvariables Map to store sys vars.
     */
    @Override
    public Collection<Country> loadInitData(DialPatternMgr dpMgr) throws Exception {
        Collection<Country> retData = null;
        Connection con = null;
        try {
            con = dbConnection.getRMSConnection();
            loadRatePeriods(con);
            loadProviders(con);
            loadRouteStatusCodes(con);
            loadRouteStatusCodesPV(con);
            loadProducts(con);
            loadVoiceCarrierGroups(con);
            loadRouteClassifications(con);
            //loadGcsRules(con);
            //loadGcsProductRuleGroups(con);
            loadGcsSlbrFloorProducts(con);
            loadCountries(con, dpMgr);
            if (countries != null && !countries.isEmpty()) {
                loadGcsCountryMap(con);
                loadItestCountries(con);
                loadPreferredRoutes(con);
                retData = countries.values();
            }
        } catch (Exception ex) {
            logger.error("loadInitData(): Exception " + ex);
            throw ex;
        } finally {
            if (con != null) {
                con.close();
            }
        }

        return retData;
    }

    /**
     * Loads all rates related information from RMS. These are loaded at the beginning
     * and is not per batch.
     */
    @Override
    public void loadRatesData(DialPatternMgr dpMgr) throws Exception {
        Connection con = null;
        try {
            con = dbConnection.getRMSConnection();
            if (!preferredRoutes.isEmpty()) {
                loadPRPeriod(con, preferredRoutes);
                loadFloorRates(con, preferredRoutes);
                loadPRPatterns(con, preferredRoutes);
                loadDPs(con, preferredRoutes);
                loadVendorRouteSummary(con, preferredRoutes);
                loadNewVendorRatePatterns(con, dpMgr);
            }
        } catch (Exception ex) {
            logger.error("loadRMSData(): Exception " + ex);
            throw ex;
        } finally {
            if (con != null) {
                con.close();
            }
        }
    }

    /**
     * Loads Vendor route status and vendor product attributes. Loading of
     * vendor route status is dependent on run-time settings and it runs different
     * implementations based on that.
     *
     * @param cat The category (batch) we are loading coverage for
     */
    @Override
    public void loadRMSCvgData(DialPatternMgr dpMgr) throws Exception {
        Connection con = null;
        try {
            con = dbConnection.getRMSConnection();
            //loadPendingActiveFloors(con, dpMgr);

            //IP and PV status code are now entered at Pref.Route level
            loadVendorRouteStatus(con, preferredRoutes);
            loadVendorRouteStatusTest(con, preferredRoutes);

        } catch (Exception ex) {
            logger.error("loadRMSCvgData(): Exception " + ex);
            throw ex;
        } finally {
            if (con != null) {
                con.close();
            }
        }
    }

    /**
     * Loads all countries in RMS
     *
     * @param con connection to RMS
     * @param dpMgr DialPatternMgr to find dial patterns in memory
     * @throws Exception
     */
    private void loadCountries(Connection con, DialPatternMgr dpMgr) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsCountry);
                logger.info("loadCountries(): " + RMSQueries.ITVW_COUNTRY + " Fetch size - " + this.fsCountry);
                rs = stmt.executeQuery(RMSQueries.ITVW_COUNTRY);
                logger.info("loadCountries(): Done executing query. Processing data...");

                while (rs.next()) {
                    long countryId = rs.getLong(1/* "COUNTRY_ID" */);
                    Country country = new Country(countryId, rs.getString(2/* "NAME" */), rs.getString(3/* "COUNTRY_CODE" */));
                    String overlap = rs.getString(4/* OVERLAPPING_COUNTRY */);
                    if (!rs.wasNull()) {
                        country.setOverlapping(overlap.charAt(0) == 'Y');
                    }
                    country.setDialPatternMgr(dpMgr);
                    countries.put(countryId, country);
                }
                logger.info("loadCountries(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadCountries(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    private void loadGcsSlbrFloorProducts(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                logger.info("loadGcsSlbrFloorProducts(): " + RMSQueries.ITVW_SLBR_FLOOR_PRODUCTS);
                rs = stmt.executeQuery(RMSQueries.ITVW_SLBR_FLOOR_PRODUCTS);
                logger.info("loadGcsSlbrFloorProducts(): Done executing query. Processing data...");

                while (rs.next()) {
                    int slbr = rs.getInt(1); // SLBR
                    long productId = rs.getLong(2); // PRODUCT_ID
                    Product product = products.get(productId);
                    if (product != null) {
                        addSlbrFloorProduct(slbr, product);
                    } else {
                        logger.warn("loadGcsSlbrFloorProducts(): ERROR: Product not found, PRODUCT_ID: " + productId);
                    }
                }
                logger.info("loadGcsSlbrFloorProducts(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadGcsRules(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    private void addSlbrFloorProduct(int slbr, Product product) {
        Set<Product> floorProduct = slbrFloorProducts.get(slbr);
        if (floorProduct == null) {
            floorProduct = new HashSet<>();
            slbrFloorProducts.put(slbr, floorProduct);
        }
        floorProduct.add(product);
    }

    @Override
    public Set<Product> getSlbrFloorProducts(Integer slbr) {
        return slbrFloorProducts.get(slbr);
    }

    private void loadGcsCountryMap(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsCountry);
                logger.info("loadGcsCountryMap(): " + RMSQueries.ITVW_GCS_COUNTRY_MAP + " Fetch size - " + this.fsCountry);
                rs = stmt.executeQuery(RMSQueries.ITVW_GCS_COUNTRY_MAP);
                logger.info("loadGcsCountryMap(): Done executing query. Processing data...");

                while (rs.next()) {
                    long countryId = rs.getLong(1); // COUNTRY_ID
                    Country country = countries.get(countryId);
                    if (country != null) {
                        country.setGcsEnabled(true);
                        int gcsInstance = rs.getInt(2); // GCS_INSTANCE
                        if (!rs.wasNull()) {
                            country.setGcsInstance(gcsInstance);
                        } else {
                            logger.warn("loadGcsCountryMap(): ERROR: Null GCS Instance");
                        }
                    } else {
                        logger.warn("loadGcsCountryMap(): ERROR: Country not found, COUNTRY_ID: " + countryId);
                    }
                }
                logger.info("loadGcsCountryMap(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadGcsCountryMap(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    private void loadItestCountries(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsCountry);
                logger.info("loadItestCountries(): " + RMSQueries.ITVW_ITEST_COUNTRY + " Fetch size - " + this.fsCountry);
                rs = stmt.executeQuery(RMSQueries.ITVW_ITEST_COUNTRY);
                logger.info("loadItestCountries(): Done executing query. Processing data...");

                while (rs.next()) {
                    long countryId = rs.getLong(1); // COUNTRY_ID
                    Country country = countries.get(countryId);
                    if (country != null) {
                        country.setItestEnabled(true);
                    } else {
                        logger.warn("loadItestCountries(): ERROR: Country not found, COUNTRY_ID: " + countryId);
                    }
                }
                logger.info("loadItestCountries(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadItestCountries(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Load all preferred routes in RMS
     *
     * @param con connection to RMS
     * @param countries All countries in RMS
     * @throws Exception
     */
    private void loadPreferredRoutes(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        Set<String> preferredRouteNames = new HashSet<>();
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsPreferredRoute);
                logger.info("loadPreferredRoutes(): " + RMSQueries.ITVW_PREFERRED_ROUTE + " Fetch size - " + this.fsPreferredRoute);
                rs = stmt.executeQuery(RMSQueries.ITVW_PREFERRED_ROUTE);
                logger.info("loadPreferredRoutes(): Done executing query. Processing data...");

                // PREFERRED_ROUTE_ID, DESCRIPTION, PATTERN_SUMMARY, COUNTRY_ID, PREMIUM_CERTIFIED
                Country country = null;
                while (rs.next()) {
                    long prId = rs.getInt("PREFERRED_ROUTE_ID");
                    long countryId = rs.getLong("COUNTRY_ID");
                    String desc = rs.getString("DESCRIPTION");
                    PreferredRoute preferredRoute = new PreferredRoute(prId, desc, countryId);
                    country = countries.get(countryId);
                    if (country == null) {
                        logger.warn("loadPreferredRoutes(): ERROR: Country being reported for preferred route not found, COUNTRY_ID: " + countryId);
                    } else {
                        preferredRoute.setCountry(country);
                        country.addPreferredRoute(preferredRoute);
                        if (!preferredRouteNames.contains(desc)) {
                            preferredRoutes.put(prId, preferredRoute);
                            preferredRouteNames.add(desc);
                        } else {
                            logger.info("Excluding country " + countryId + " (" + country.getName() + ") due to duplicated preferred route name: " + desc);
                            country.setExcluded(true);
                        }
                    }
                }
                logger.info("loadPreferredRoutes(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadPreferredRoutes()(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    @Override
    public Map<Integer, RatePeriod> getRatePeriods() throws Exception {
        if (ratePeriods == null) {
            Connection con = null;
            try {
                con = dbConnection.getRMSConnection();
                loadRatePeriods(con); // will populate ratePeriods map
            } catch (Exception ex) {
                logger.error("getRatePeriods(): Exception " + ex);
                throw ex;
            } finally {
                if (con != null) {
                    con.close();
                }
            }
        }
        return ratePeriods;
    }

    /**
     * Loads all rate periods defined in RMS.
     *
     * @param con connection to RMS schema
     * @throws Exception
     */
    private void loadRatePeriods(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                ratePeriods = new HashMap<>();
                stmt = con.createStatement();
                logger.info("loadRatePeriod(): " + RMSQueries.ITVW_RATE_PERIOD);
                rs = stmt.executeQuery(RMSQueries.ITVW_RATE_PERIOD);
                logger.info("loadRatePeriods(): Done executing query. Processing data...");

                //RATE_PERIOD_ID, PERIOD_CODE, DESCRIPTION
                while (rs.next()) {
                    int periodId = rs.getInt(1/* RATE_PERIOD_ID */);
                    String periodCode = rs.getString(2/* PERIOD_CODE */);
                    String desc = rs.getString(3/* DESCRIPTION */);
                    RatePeriod ratePeriod = new RatePeriod(periodId, periodCode, desc);
                    ratePeriods.put(periodId, ratePeriod);
                }
                logger.info("loadRatePeriods(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadRatePeriod(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Loads all voice carrier groups that are assigned to pm traffic group from RMS.
     *
     * @param con connection to RMS schema
     * @throws Exception
     */
    private void loadVoiceCarrierGroups(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                // GROUP_ID, GROUP_NAME, DIRECTION, PRODUCT_ID, CUSTOMER_TYPE_ID, PM_TRAFFIC_GROUP_ID
                logger.info("loadVoiceCarrierGroups(): " + RMSQueries.ITVW_VOICE_CARRIER_GROUP);
                rs = stmt.executeQuery(RMSQueries.ITVW_VOICE_CARRIER_GROUP);
                logger.info("loadVoiceCarrierGroups(): Done executing query. Processing data...");

                //RATE_PERIOD_ID, PERIOD_CODE, DESCRIPTION
                while (rs.next()) {
                    long groupId = rs.getLong(1); // GROUP_ID
                    String groupName = rs.getString(2); // GROUP_NAME
                    String direction = rs.getString(3); // DIRECTION
                    long productId = rs.getLong(4); // PRODUCT_ID
                    if (rs.wasNull()) {
                        productId = DomainConstants.NULL_LONG_VALUE;
                    }

                    long customerTypeId = rs.getLong(5); // CUSTOMER_TYPE_ID
                    if (rs.wasNull()) {
                        customerTypeId = DomainConstants.NULL_LONG_VALUE;
                    }

                    long pamTrafficGroupId = rs.getLong(6); // PM_TRAFFIC_GROUP_ID
                    if (rs.wasNull()) {
                        pamTrafficGroupId = DomainConstants.NULL_LONG_VALUE;
                    }

                    Product product = products.get(productId);
                    VoiceCarrierGroup voiceCarrierGroup = new VoiceCarrierGroup();
                    voiceCarrierGroup.setGroupId(groupId);
                    voiceCarrierGroup.setGroupName(groupName);
                    voiceCarrierGroup.setDirection(direction);
                    voiceCarrierGroup.setProduct(product);
                    voiceCarrierGroup.setCustomerTypeId(customerTypeId);
                    voiceCarrierGroup.setPamTrafficGroupId(pamTrafficGroupId);
                    voiceCarrierGroups.put(groupId, voiceCarrierGroup);
                }
                logger.info("loadVoiceCarrierGroups(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadVoiceCarrierGroups(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    @Override
    public Map<Long, VoiceCarrierGroup> getVoiceCarrierGroups() {
        return voiceCarrierGroups;
    }

    /**
     * Loads all preferred route level rate period in RMS.
     *
     * @param con connection to RMS schema
     * @param preferredRoutes preferred routes in RMS
     * @throws Exception
     */
    private void loadPRPeriod(Connection con, Map<Long, PreferredRoute> preferredRoutes) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsPreferredRoute);
                logger.info("loadPRPeriod(): " + RMSQueries.ITVW_PREFERRED_ROUTE_PERIOD + " Fetch size - " + this.fsPreferredRoute);
                rs = stmt.executeQuery(RMSQueries.ITVW_PREFERRED_ROUTE_PERIOD);
                logger.info("loadPRPeriod(): Done executing query. Processing data...");

                //select PREFERRED_ROUTE_ID, PERIOD_ID,
                //START_TIME, STOP_TIME, START_WEEK_DAY, STOP_WEEK_DAY
                //Query Has been sorted by pr_rt_id and period id
                long prevID = DataManagerConstants.NULL_ID;
                PreferredRoute preferredRoute = null;
                while (rs.next()) {
                    long preferredRouteId = rs.getInt(1/* "PREFERRED_ROUTE_ID" */);
                    if (prevID != preferredRouteId) {
                        preferredRoute = preferredRoutes.get(preferredRouteId);
                        prevID = preferredRouteId;
                        if (preferredRoute == null) {
                            logger.warn("loadPRPeriod(): Preferred route ID " + preferredRouteId + " being reported for rate period not found");
                        }
                    }

                    if (preferredRoute != null) {
                        TimeOfDay tod = null;
                        int periodId = rs.getInt(2 /* PERIOD_ID */);
                        if (rs.wasNull()) {
                            logger.warn("loadPRPeriod(): Rate period id is null. Row entry for preferred Route Id " + preferredRouteId + " is ignored!");
                        } else {
                            String startTime = rs.getString(3/* START_TIME */);
                            if (startTime == null) {
                                logger.warn("loadPRPeriod(): Start time of period " + periodId + " is null");
                            }

                            String endTime = rs.getString(4/* STOP_TIME */);
                            if (endTime == null) {
                                logger.warn("loadPRPeriod(): Stop time of period " + periodId + " is null");
                            }
                            //for weekend
                            int sWeekDay = rs.getInt(5/* START_WEEK_DAY */);
                            if (rs.wasNull()) {
                                sWeekDay = DomainConstants.NULL_VALUE;
                            }

                            int eWeekDay = rs.getInt(6/* STOP_WEEK_DAY */);
                            if (rs.wasNull()) {
                                eWeekDay = DomainConstants.NULL_VALUE;
                            }

                            tod = new TimeOfDay(periodId, startTime, endTime, sWeekDay, eWeekDay);
                            preferredRoute.addTimeofDayByPeriodId(periodId, tod);
                        }
                    }

                }
                logger.info("loadPRPeriod(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadPRPeriod(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Loads all floor rates defined in RMS. Floor rates are define ad preferred route
     * and product level.
     *
     * @param con connection to RMS schema
     * @param preferredRoutes preferred routes in RMS
     * @throws Exception
     */
    private void loadFloorRates(Connection con, Map<Long, PreferredRoute> preferredRoutes) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsFloorRate);
                logger.info("loadFloorRates(): " + RMSQueries.ITVW_FLOOR_RATE + " Fetch size - " + this.fsFloorRate);
                rs = stmt.executeQuery(RMSQueries.ITVW_FLOOR_RATE);
                logger.info("loadFloorRates(): Done executing query. Processing data...");

                //COUNTRY_ID, PREFERRED_ROUTE_ID, PRODUCT_ID, RATE, PERIOD_ID
                PreferredRoute preferredRoute = null;
                while (rs.next()) {
                    long preferredRouteId = rs.getInt(2/* "PREFERRED_ROUTE_ID" */);
                    preferredRoute = preferredRoutes.get(preferredRouteId);
                    if (preferredRoute == null) {
                        logger.warn("loadFloorRates(): ERROR: Preferred route ID " + preferredRouteId + " being reported for floor rate not found");
                    }
                    if (preferredRoute != null) {
                        long prodId = rs.getLong(3/* "PRODUCT_ID" */);
                        Product prod = products.get(prodId);
                        if (prod != null) {
                            double rate = rs.getDouble(4/* "RATE" */);
                            if (rs.wasNull()) {
                                logger.error("loadFloorRates(): ERROR: Missing floor rate for preferred route " + preferredRouteId + " on product " + prodId);
                            } else {
                                int periodId = rs.getInt(5 /* PERIOD_ID */);
                                if (!rs.wasNull()) {
                                    preferredRoute.getFloorRateByProduct(prod);
                                    FloorRate floorRate = new FloorRate(rate);
                                    floorRate.setProduct(prod);
                                    preferredRoute.addFloorRateByProductPeriodId(prod, periodId, floorRate);
                                } else {
                                    logger.warn("loadFloorRates(): ERROR: Missing period id for preferred route " + preferredRouteId + " on product " + prodId);
                                }
                            }

                        } else {
                            logger.warn("loadFloorRates(): ERROR: Product for ID " + prodId + " being reported for floor rate not found");
                        }
                    }
                }
                logger.info("loadFloorRates(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadFloorRates(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    private void loadPendingActiveFloors(Connection con, DialPatternMgr dpMgr) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsPendingFloor);
                logger.info("loadPendingActiveFloors(): " + RMSQueries.ITVW_FLOOR_RATE_PEND_ACTIVE + " Fetch size - " + this.fsPendingFloor);

                //PRODUCT_ID, ROUTE_ID, PATTERN, RATE, RATE_PERIOD_ID
                rs = stmt.executeQuery(RMSQueries.ITVW_FLOOR_RATE_PEND_ACTIVE);
                logger.info("loadPendingActiveFloors(): Done executing query. Processing data...");

                while (rs.next()) {
                    long prodId = rs.getLong(1); //PRODUCT_ID
                    Product product = products.get(prodId);
                    if (product == null) {
                        logger.warn("loadPendingActiveFloors(): ERROR: Product ID " + prodId + " being reported for pending active floor not found");
                    } else {
                        long routeId = rs.getLong(2); // ROUTE_ID
                        if (rs.wasNull()) {
                            logger.warn("loadPendingActiveFloors(): ERROR: NULL ROUTE_ID, record skipped.");
                        } else {
                            String pattern = rs.getString(3); // PATTERN
                            if (pattern == null || pattern.length() == 0) {
                                logger.warn("loadPendingActiveFloors(): ERROR: NULL PATTERN, record skipped.");
                            } else {
                                double rate = rs.getDouble(4); // RATE
                                int periodId = rs.getInt(5); // RATE_PERIOD_ID

                                DialPattern dp = dpMgr.findPattern(pattern);
                                if (dp != null) {
                                    FloorRate floorRate = new FloorRate(rate);
                                    floorRate.setProduct(product);
                                    dp.addFloorRateByProductPeriodId(product, periodId, floorRate);
                                } else {
                                    logger.warn("loadPendingActiveFloors(): ERROR: PATTERN not found: " + pattern + ", record skipped.");
                                }
                            }
                        }
                    }
                }
                logger.info("loadPendingActiveFloors(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadPendingActiveFloors(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Load all preferred route patterns defined in RMS.
     *
     * @param con Connection to RMS
     * @param preferredRoutes All preferred routes in RMS
     * @throws Exception
     */
    private void loadPRPatterns(Connection con, Map<Long, PreferredRoute> preferredRoutes) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsPrPattern);
                logger.info("loadPRPatterns(): " + RMSQueries.ITVW_PR_PATTERNS + " Fetch size - " + this.fsPrPattern);
                rs = stmt.executeQuery(RMSQueries.ITVW_PR_PATTERNS);
                logger.info("loadPRPatterns(): Done executing query. Processing data...");

                long prevID = DataManagerConstants.NULL_ID;
                PreferredRoute preferredRoute = null;
                while (rs.next()) {
                    long preferredRouteId = rs.getInt(2 /* "PREFERRED_ROUTE_ID" */);
                    long routeId = rs.getLong(4 /* "ROUTE_ID" */);
                    if (rs.wasNull()) {
                        throw new Exception("loadPRPatterns(): ERROR: NULL route ID encountered!");
                    }
                    String pattern = rs.getString(3 /* "PATTERN" */);
                    //Query Has been sorted by pr_rt_id. If sorting changed,
                    // take this logic out!
                    if (prevID != preferredRouteId) {
                        preferredRoute = preferredRoutes.get(preferredRouteId);
                        prevID = preferredRouteId;
                        if (preferredRoute == null) {
                            logger.warn("loadPRPatterns(): ERROR: Preferred route ID " + preferredRouteId + " being reported for preferred route pattern "
                                    + pattern + " not found");
                        }
                    }
                    if (preferredRoute != null) {
                        preferredRoute.recordPRPattern(pattern, routeId);
                    }
                }
                logger.info("loadPRPatterns(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadPRPatterns(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Load all rates information at pattern-provider level from RMS
     *
     * @param con connection to RMS
     * @param preferredRoutes preferred routes in RMS
     * @throws Exception
     */
    private void loadVendorRouteSummary(Connection con, Map<Long, PreferredRoute> preferredRoutes) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsVendorRate);
                logger.info("loadVendorRouteSummary(): " + RMSQueries.ITVW_VENDOR_ROUTE_SUMMARY + " Fetch size - " + this.fsVendorRate);
                rs = stmt.executeQuery(RMSQueries.ITVW_VENDOR_ROUTE_SUMMARY);
                logger.info("loadVendorRouteSummary(): Done executing query. Processing data...");

                long prevPRID = DataManagerConstants.NULL_ID;
                long prevDP = DataManagerConstants.NULL_ID;
                PreferredRoute preferredRoute = null;
                DialPattern dp = null;

                //1 COLO_CODE, 2 PREFERRED_ROUTE_ID, 3 COUNTRY_ID, 4 PATTERN, 5 MIN_RATE,
                //6 MAX_RATE, 7 COST, 8 MIN_NET_COST, 9 MAX_NET_COST, 10 MULTI_RATE_IND,
                //11 IS_PROPER_IND, 12 PARTIAL_COVERAGE_IND, 13 ROUTE_ID, 14 RATE_PERIOD_ID, 15 START_TIME, 16 STOP_TIME,
                //17 START_WEEK_DAY, 18 STOP_WEEK_DAY, 19 VENDOR_ID
                int rowCnt = 0;
                while (rs.next()) {
                    rowCnt++;
                    long preferredRouteId = rs.getLong(2/* PREFERRED_ROUTE_ID */);
                    //Query Has been sorted by pr_rt_id. If sorting changed, take this logic out!
                    if (prevPRID != preferredRouteId) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("loadVendorRouteSummary(): Looking up Preferred route  " + preferredRouteId);
                        }
                        preferredRoute = preferredRoutes.get(preferredRouteId);
                        prevPRID = preferredRouteId;
                        if (preferredRoute == null) {
                            if (logger.isDebugEnabled()) {
                                logger.debug("loadVendorRouteSummary: Preferred route reported not found for ID: " + preferredRouteId);
                            }
                        }
                    }
                    if (preferredRoute != null) {
                        long vendorId = rs.getLong(19 /* VENDOR_ID */);
                        Provider provider = providers.get(vendorId);
                        if (provider != null) {
                            long routeID = rs.getLong(13/* ROUTE_ID */);
                            if (rs.wasNull()) {
                                throw new Exception("loadVendorRouteSummary(): ERROR: NULL route ID encountered!");
                            }
                            String patternStr = rs.getString(4/* PATTERN */);
                            double minRate = rs.getDouble(5/* MIN_RATE */);
                            double maxRate = rs.getDouble(6/* MAX_RATE */);

                            boolean hasNullCost = false;
                            double cost = rs.getDouble(7/* COST */);
                            if (rs.wasNull()) {
                                hasNullCost = true;
                                logger.error("loadVendorRouteSummary(): missing cost for vendorId " + vendorId + " and pattern " + patternStr);
                            }
                            double minNetCost = rs.getDouble(8/* MIN_NET_COST */);
                            if (rs.wasNull()) {
                                hasNullCost = true;
                                logger.error("loadVendorRouteSummary(): missing minimum net cost for vendorId " + vendorId + " and pattern " + patternStr);
                            }
                            double maxNetCost = rs.getDouble(9/* MAX_NET_COST */);
                            if (rs.wasNull()) {
                                hasNullCost = true;
                                logger.error("loadVendorRouteSummary(): missing maximum net cost for vendorId " + vendorId + " and pattern " + patternStr);
                            }
                            String multiRateInd = rs.getString(10/* MULTI_RATE_IND */);
                            String isProperInd = rs.getString(11/* IS_PROPER_IND */);
                            String isPartialCoverageInd = rs.getString(12/* PARTIAL_COVERAGE_IND */);

                            //loading TOD info
                            TimeOfDay tod = null;
                            int periodId = rs.getInt(14 /* RATE_PERIOD_ID */);

                            String startTime = rs.getString(15/* START_TIME */);
                            if (periodId != DomainConstants.RMS_PEAK_PERIOD_ID && startTime == null) {
                                if (logger.isDebugEnabled()) {
                                    logger.debug("loadVendorRouteSummary(): Warning: Start time of period " + periodId + " is null");
                                }
                            }

                            String endTime = rs.getString(16/* STOP_TIME */);
                            if (periodId != DomainConstants.RMS_PEAK_PERIOD_ID && endTime == null) {
                                if (logger.isDebugEnabled()) {
                                    logger.debug("loadVendorRouteSummary(): Warning: Stop time of period " + periodId + " is null");
                                }
                            }

                            int sWeekDay = rs.getInt(17/* START_WEEK_DAY */);
                            if (rs.wasNull()) {
                                sWeekDay = DomainConstants.NULL_VALUE;
                            }

                            int eWeekDay = rs.getInt(18/* STOP_WEEK_DAY */);
                            if (rs.wasNull()) {
                                eWeekDay = DomainConstants.NULL_VALUE;
                            }

                            if (prevDP != routeID) { // Save on dial pattern lookup
                                if (logger.isDebugEnabled()) {
                                    logger.debug(
                                            "loadVendorRouteSummary(): Recording dial pattern  " + patternStr + " for preferred_route " + preferredRouteId);
                                }
                                dp = preferredRoute.recordDialPattern(patternStr, routeID);
                                prevDP = routeID;
                            }

                            if (hasNullCost) {
                                logger.warn("loadVendorRouteSummary(): entry is ingored. Check cost, minimum cost, or maximum cost for vendorId " + vendorId
                                        + " and pattern " + patternStr);
                            } else if (periodId != DomainConstants.RMS_PEAK_PERIOD_ID && (startTime == null || endTime == null)) {
                                //ingore the entry if the start time or end time are null,
                                //record peak rate only if the start time or end time are null
                                if (logger.isDebugEnabled()) {
                                    logger.debug("loadVendorRouteSummary(): missing period " + periodId + " for vendorId " + vendorId + " and pattern "
                                            + patternStr);
                                }
                            } else {
                                tod = new TimeOfDay(periodId, startTime, endTime, sWeekDay, eWeekDay);
                                preferredRoute.recordRatePattern(provider, dp, cost, maxNetCost, minNetCost, minRate, maxRate, multiRateInd, isProperInd, tod);
                            }
                        } else {
                            if (logger.isDebugEnabled()) {
                                logger.debug("loadVendorRouteSummary: Failed processing row due " + "to vendor not found for vendorId : " + vendorId);
                            }
                        }
                    }
                }
                logger.info("loadVendorRouteSummary(): Done processing data");
                if (rowCnt == 0) {
                    throw new Exception("ITVW_VENDOR_ROUTE_SUMMARY view contains no data!");
                }
            } else {
                throw new Exception("Null db connection!");
            }
        } catch (Exception e) {
            logger.error("Exception in loadVendorRouteSummary(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Load brand new vendor pattern rates.
     *
     * @param con
     * @param preferredRoutes
     * @throws Exception
     */
    private void loadNewVendorRatePatterns(Connection con, DialPatternMgr dpMgr) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsVendorRate);
                logger.info("loadNewVendorRatePatterns(): " + RMSQueries.ITVW_NEW_VENDOR_RATE_PATTERNS + " Fetch size - " + this.fsVendorRate);
                rs = stmt.executeQuery(RMSQueries.ITVW_NEW_VENDOR_RATE_PATTERNS);
                logger.info("loadNewVendorRatePatterns(): Done executing query. Processing data...");

                DialPattern dp = null;

                // VENDOR_ID, ROUTE_ID, PATTERN
                int rowCnt = 0;
                while (rs.next()) {
                    rowCnt++;
                    long vendorId = rs.getLong(1); // VENDOR_ID
                    Provider provider = providers.get(vendorId);
                    if (provider != null) {
                        long routeID = rs.getLong(2); // ROUTE_ID
                        if (rs.wasNull()) {
                            logger.error("loadNewVendorRatePatterns(): ERROR: NULL route ID encountered!");
                            continue;
                        }
                        String patternStr = rs.getString(3); // PATTERN
                        if (rs.wasNull()) {
                            logger.error("loadNewVendorRatePatterns(): ERROR: NULL pattern encountered!");
                            continue;
                        }
                        dp = dpMgr.findFit(patternStr, routeID);
                        dp.getPreferredRoute().recordNewVendorRatePattern(provider, dp);

                    } else {
                        if (logger.isDebugEnabled()) {
                            logger.debug("loadNewVendorRatePatterns: Failed processing row due " + "to vendor not found for vendorId : " + vendorId);
                        }
                    }

                }
                logger.info("loadNewVendorRatePatterns(): Done processing data");
                if (rowCnt == 0) {
                    logger.info("loadNewVendorRatePatterns(): No new vendor rate patterns found.");
                }
            } else {
                throw new Exception("Null db connection!");
            }
        } catch (Exception e) {
            logger.error("Exception in loadNewVendorRatePatterns(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Loads vendor IP and PV status code at preferred route level
     *
     * @param con connection to RMS
     * @param preferredRoutes all preferred routes in RMS
     * @param cat category of countries being loaded
     * @throws Exception
     */
    private void loadVendorRouteStatus(Connection con, Map<Long, PreferredRoute> preferredRoutes) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsVendorStatus);
                logger.info("loadVendorRouteStatus(): " + RMSQueries.ITVW_VENDOR_ROUTE_STATUS + " Fetch size - " + this.fsVendorStatus);
                rs = stmt.executeQuery(RMSQueries.ITVW_VENDOR_ROUTE_STATUS);
                logger.info("loadVendorRouteStatus(): Done executing query. Processing data...");

                long prevPRID = DataManagerConstants.NULL_ID;
                PreferredRoute pfRt = null;
                //PREFERRED_ROUTE_ID, VENDOR_ID, PV_STATUS_CODE, IP_STATUS_CODE
                while (rs.next()) {
                    long preferredRouteId = rs.getLong(1);
                    if (prevPRID != preferredRouteId) {
                        pfRt = preferredRoutes.get(Long.valueOf(preferredRouteId));
                        prevPRID = preferredRouteId;
                        if (pfRt == null) {
                            logger.info("loadVendorRouteStatus(): Preferred route reported not found for ID: " + preferredRouteId);
                        }
                    }
                    if (pfRt != null) {
                        Provider provider = null;
                        long vendorId = rs.getLong(2);
                        provider = providers.get(vendorId);
                        if (provider != null) {
                            long pvStatusCode = rs.getLong(3);
                            long cvStatusCode = rs.getLong(4);
                            RouteStatus pvRouteStatus = null;
                            RouteStatus cvRouteStatus = null;
                            if (pvStatusCode > 0) {
                                pvRouteStatus = getPvStatusCode(pvStatusCode);
                            }
                            if (cvStatusCode > 0) {
                                cvRouteStatus = getCvStatusCode(cvStatusCode);
                            }
                            if (pvRouteStatus != null || cvRouteStatus != null) {
                                pfRt.addVendorRouteStatus(provider, pvRouteStatus, cvRouteStatus);
                            } else {
                                logger.info("loadVendorRouteStatus(): Both IP and PV Status Code are undefined for preferred route id " + preferredRouteId
                                        + " and vendor id " + vendorId);
                            }

                        } else {
                            logger.info("loadVendorRouteStatus(): Failed processing row due to provider " + "not found for vendorId : " + vendorId);
                        }
                    }
                }
                logger.info("loadVendorRouteStatus(): Done processing data");
            } else {
                throw new Exception("Null db connection!");
            }
        } catch (Exception e) {
            logger.error("Exception in loadVendorRouteStatus(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Loads vendor IP and PV test status code at preferred route level
     *
     * @param con connection to RMS
     * @param preferredRoutes all preferred routes in RMS
     * @param cat category of countries being loaded
     * @throws Exception
     */
    private void loadVendorRouteStatusTest(Connection con, Map<Long, PreferredRoute> preferredRoutes) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsVendorStatus);
                logger.info("loadVendorRouteStatusTest(): " + RMSQueries.ITVW_VENDOR_ROUTE_STATUS_TEST + " Fetch size - " + this.fsVendorStatus);
                rs = stmt.executeQuery(RMSQueries.ITVW_VENDOR_ROUTE_STATUS_TEST);
                logger.info("loadVendorRouteStatusTest(): Done executing query. Processing data...");

                long prevPRID = DataManagerConstants.NULL_ID;
                PreferredRoute prRt = null;
                //PREFERRED_ROUTE_ID, VENDOR_ID, PV_STATUS_CODE, IP_STATUS_CODE
                while (rs.next()) {
                    long preferredRouteId = rs.getLong(1);
                    if (prevPRID != preferredRouteId) {
                        prRt = preferredRoutes.get(preferredRouteId);
                        prevPRID = preferredRouteId;
                        if (prRt == null) {
                            if (logger.isDebugEnabled()) {
                                logger.debug("loadVendorRouteStatusTest(): Preferred route reported not found for ID: " + preferredRouteId);
                            }
                        }
                    }
                    if (prRt != null) {
                        Provider provider = null;
                        long vendorId = rs.getLong(2);
                        provider = providers.get(vendorId);
                        if (provider != null) {
                            long pvStatusCode = rs.getLong(3);
                            long ipStatusCode = rs.getLong(4);
                            RouteStatus pvRouteStatus = null;
                            RouteStatus ipRouteStatus = null;
                            if (pvStatusCode > 0) {
                                pvRouteStatus = getPvStatusCode(pvStatusCode);
                            }
                            if (ipStatusCode > 0) {
                                ipRouteStatus = getCvStatusCode(ipStatusCode);
                            }
                            if (pvRouteStatus != null || ipRouteStatus != null) {
                                prRt.addVendorRouteStatus(provider, pvRouteStatus, ipRouteStatus);
                            } else {
                                logger.info("loadVendorRouteStatusTest(): Both IP and PV Status Code are undefined for preferred route id " + preferredRouteId
                                        + " and vendor id " + vendorId);
                            }

                        } else {
                            logger.info("loadVendorRouteStatusTest(): Failed processing row due to provider " + "not found for vendorId : " + vendorId);
                        }
                    }
                }
                logger.info("loadVendorRouteStatusTest(): Done processing data");
            } else {
                throw new Exception("Null db connection!");
            }
            logger.info("loadVendorRouteStatusTest(): Process vendor pv test done.");
        } catch (Exception e) {
            logger.error("Exception in loadVendorRouteStatusTest(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Load all providers in RMS
     *
     * @param con connection to RMS
     * @throws Exception
     */
    private void loadProviders(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsProvider);
                logger.info("loadProviders(): " + RMSQueries.ITVW_PROVIDER + " Fetch size " + this.fsProvider);
                rs = stmt.executeQuery(RMSQueries.ITVW_PROVIDER);
                logger.info("loadProviders(): Done executing query. Processing data...");

                // VENDOR_ID, PROVIDER_NAME, IS_AUTO_ROUTED, VENDOR_TYPE_ID, SOURCE_NETWORK_ID
                while (rs.next()) {
                    long vendorId = rs.getLong(1);
                    String name = rs.getString(2);
                    String autort = rs.getString(3);
                    if (rs.wasNull()) {
                        autort = "N";
                    }
                    int vendorTypeId = rs.getInt(4);
                    int sourceNetworkId = rs.getInt(5);
                    String isInService = rs.getString(6);
                    if (rs.wasNull()) {
                        isInService = "N";
                    }

                    Provider provider = new Provider(vendorId, name, autort, vendorTypeId, sourceNetworkId, isInService.charAt(0) == 'Y');
                    providers.put(vendorId, provider);
                }
                logger.info("loadProviders(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadProviders(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }

    }

    /**
     * Load all IP route status code definitions from RMS
     *
     * @param con connection to RMS
     * @throws Exception
     */
    private void loadRouteStatusCodes(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                logger.info("loadRouteStatusCodes(): " + RMSQueries.ITVW_ROUTE_STATUS_CODE);
                rs = stmt.executeQuery(RMSQueries.ITVW_ROUTE_STATUS_CODE);
                logger.info("loadRouteStatusCodes(): Done executing query. Processing data...");

                //ROUTE_STATUS_ID, ROUTE_STATUS_CODE, STATUS_RANK, CATEGORY_CODE
                while (rs.next()) {
                    long code = rs.getLong(2/* "ROUTE_STATUS_CODE" */);
                    RouteStatus routeStatus = new RouteStatus(rs.getLong(1/* "ROUTE_STATUS_ID" */), code, rs.getLong(3/* "STATUS_RANK" */),
                            rs.getString(4/* "CATEGORY_CODE" */));
                    cvStatusCodes.put(code, routeStatus);
                }
                logger.info("loadRouteStatusCodes(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadRouteStatusCodes(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Load all PV route status code definitions from RMS
     *
     * @param con connection to RMS
     * @throws Exception
     */
    private void loadRouteStatusCodesPV(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                logger.info("loadRouteStatusCodesPV(): " + RMSQueries.ITVW_ROUTE_STATUS_CODE_PV);
                rs = stmt.executeQuery(RMSQueries.ITVW_ROUTE_STATUS_CODE_PV);
                logger.info("loadRouteStatusCodesPV(): Done executing query. Processing data...");

                //ROUTE_STATUS_ID, ROUTE_STATUS_CODE, STATUS_RANK, CATEGORY_CODE
                while (rs.next()) {
                    long code = rs.getLong(2/* "ROUTE_STATUS_CODE" */);
                    RouteStatus routeStatus = new RouteStatus(rs.getLong(1/* "ROUTE_STATUS_ID" */), code, rs.getLong(3/* "STATUS_RANK" */),
                            rs.getString(4/* "CATEGORY_CODE" */));
                    routeStatus.setPV(true);
                    pvStatusCodes.put(code, routeStatus);
                }
                logger.info("loadRouteStatusCodesPV(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadRouteStatusCodesPV(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Load all products in RMS
     *
     * @param con connection to RMS
     * @throws Exception
     */
    private void loadProducts(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsProduct);
                logger.info("loadProducts(): " + RMSQueries.ITVW_PRODUCT + " Fetch size " + this.fsProduct);
                rs = stmt.executeQuery(RMSQueries.ITVW_PRODUCT);
                logger.info("loadProducts(): Done executing query. Processing data...");

                while (rs.next()) {
                    long productId = rs.getLong(1/* "PRODUCT_ID" */);
                    String excStr = rs.getString(3);
                    if (rs.wasNull()) {
                        excStr = "N";
                    }
                    Product product = new Product(productId, rs.getString(2/* "PRODUCT_DESC" */), excStr.charAt(0) == 'Y');
                    products.put(productId, product);
                }
                logger.info("loadProducts(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadProducts(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }

    }

    /**
     * Load all dial patterns in RMS
     *
     * @param con connection to RMS
     * @param preferredRoutes preferred routes in RMS
     * @throws Exception
     */
    private void loadDPs(Connection con, Map<Long, PreferredRoute> preferredRoutes) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsDp);
                logger.info("loadDPs(): " + RMSQueries.ITVW_ROUTE + " Fetch size - " + this.fsDp);
                rs = stmt.executeQuery(RMSQueries.ITVW_ROUTE);
                logger.info("loadDPs(): Done executing query. Processing data...");

                PreferredRoute preferredRoute = null;
                DialPattern dp = null;
                //PREFERRED_ROUTE_ID, ROUTE_ID, PATTERN, BLOCKED_FLAG, INHERIT_FLAG, IS_NEW
                while (rs.next()) {
                    long preferredRouteId = rs.getLong(1/* PREFERRED_ROUTE_ID */);
                    preferredRoute = preferredRoutes.get(preferredRouteId);
                    if (preferredRoute == null) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("loadDPs: Preferred route reported not found for ID: " + preferredRouteId);
                        }
                    }
                    if (preferredRoute != null) {
                        long routeId = rs.getLong(2/* ROUTE_ID */);
                        if (rs.wasNull()) {
                            throw new Exception("loadDPs(): ERROR: NULL route ID encountered!");
                        }
                        String patternStr = rs.getString(3/* PATTERN */);
                        String isBlocked = rs.getString(4/* BLOCKED_FLAG */);
                        if (rs.wasNull()) {
                            isBlocked = "N";
                        }
                        String doInherit = rs.getString(5/* INHERIT_FLAG */);
                        if (rs.wasNull()) {
                            doInherit = "N";
                        }
                        String isNew = rs.getString(6/* ITEST_NEW */);
                        if (rs.wasNull()) {
                            isNew = "N";
                        }

                        //We record against preferred route as all dial patterns
                        //are required to be under a preferred route.
                        dp = preferredRoute.recordDialPattern(patternStr, routeId);
                        if (dp != null) {
                            dp.setNewInRMS(isNew.charAt(0) == 'Y');
                        } else {
                            logger.error("loadDPs(): Failed to add pattern : " + patternStr);
                        }
                    }
                }
                logger.info("loadDPs(): Done processing data");

            } else {
                throw new Exception("Null db connection!");
            }
        } catch (Exception e) {
            logger.error("Exception in loadDPs(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }

    }

    private RouteStatus getCvStatusCode(long code) {
        return cvStatusCodes.get(code);
    }

    private RouteStatus getPvStatusCode(long code) {
        return pvStatusCodes.get(code);
    }

    @Override
    public Map<Long, Provider> getProviders() {
        return this.providers;
    }

    @Override
    public Map<Long, Product> getProducts() {
        return this.products;
    }

    @Override
    public Product getProduct(long productId) {
        return products.get(productId);
    }

    @Override
    public Map<Long, PreferredRoute> getPreferredRoutes() {
        return this.preferredRoutes;
    }

    @Override
    public void clearData() {
        this.preferredRoutes = null;
        this.countries = null;
        this.products = null;
        this.cvStatusCodes = null;
        this.pvStatusCodes = null;
    }

    @Override
    public Country getCountry(long countryId) {
        return countries.get(countryId);
    }

    /**
     * @return Returns the countries.
     */
    @Override
    public Map<Long, Country> getCountries() {
        return countries;
    }

    //returns a provider object given the colo code
    @Override
    public Provider getProvider(String coloStr) throws Exception {

        return this.providers.get(coloStr);

    }

    @Override
    public RouteClassification getRouteClassification(long routeClassificationId) throws Exception {
        if (routeClassifications == null) {
            throw new Exception("getRouteClassification(): route classification not loaded.");
        }
        return routeClassifications.get(routeClassificationId);
    }

    private void loadRouteClassifications(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                logger.info("loadRouteClassifications(): " + RMSQueries.ITVW_ROUTE_CLASSIFICATION);
                rs = stmt.executeQuery(RMSQueries.ITVW_ROUTE_CLASSIFICATION);
                logger.info("loadRouteClassifications(): Done executing query. Processing data...");

                while (rs.next()) {
                    long id = rs.getLong(1); // route_classification_id
                    String desc = rs.getString(2); // classification_desc
                    long slbr = rs.getLong(3); // slbr
                    RouteClassification routeClassification = new RouteClassification(id, desc, slbr);
                    routeClassifications.put(id, routeClassification);
                }
                logger.info("loadRouteClassifications(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadRouteClassifications(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    private void loadSrcTestInclusion(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                logger.info("loadSrcTestInclusion(): " + RMSQueries.ITVW_SRC_GCS_CONFIG);
                rs = stmt.executeQuery(RMSQueries.ITVW_SRC_GCS_CONFIG);
                logger.info("loadSrcTestInclusion(): Done executing query. Processing data...");

                while (rs.next()) {
                    long id = rs.getLong(1); // route_classification_id
                    String pvTesting = rs.getString(2); // pv_test_eligible
                    String cvTesting = rs.getString(3); // cv_test_eligible
                    String pvBlock = rs.getString(4); // pv_block
                    String cvBlock = rs.getString(5); // cv_block
                    RouteClassification routeClassification = routeClassifications.get(id);
                    if (routeClassification == null) {
                        logger.warn("loadSrcTestInclusion(): ERROR: Route Classification ID " + id + " not found");
                        continue;
                    } else {
                        routeClassification.setAllowPvTesting(pvTesting.charAt(0) == 'Y');
                        routeClassification.setAllowCvTesting(cvTesting.charAt(0) == 'Y');
                        routeClassification.setRequirePvBlock(pvBlock.charAt(0) == 'Y');
                        routeClassification.setRequireCvBlock(cvBlock.charAt(0) == 'Y');
                    }
                }
                logger.info("loadSrcTestInclusion(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadRouteClassifications(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    private void loadVendorRouteSlbr(Connection con) throws Exception {
        Set<Long> badVendorIds = new HashSet<>(); // for error reporting
        Set<Long> badPreferredRouteIds = new HashSet<>(); // for error reporting
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsVendorSrc);
                logger.info("loadVendorRouteSlbr(): " + RMSQueries.ITVW_VENDOR_ROUTE_SLBR + " Fetch size - " + this.fsVendorSrc);
                rs = stmt.executeQuery(RMSQueries.ITVW_VENDOR_ROUTE_SLBR);
                logger.info("loadVendorRouteSlbr(): Done executing query. Processing data...");

                Provider provider = null;
                PreferredRoute prefRt = null;
                while (rs.next()) {
                    long vendorId = rs.getLong(1);
                    provider = providers.get(vendorId);
                    if (provider == null) {
                        if (!badVendorIds.contains(vendorId)) {
                            badVendorIds.add(vendorId);
                            logger.warn("loadVendorRouteSlbr(): ERROR: vendorId " + vendorId + " being reported for vendor route slbr not found. Skip record");
                        }
                        continue;
                    }

                    long preferredRouteId = rs.getLong(2);
                    prefRt = preferredRoutes.get(preferredRouteId);
                    if (prefRt == null) {
                        if (!badPreferredRouteIds.contains(preferredRouteId)) {
                            badPreferredRouteIds.add(preferredRouteId);
                            logger.warn("loadVendorRouteSlbr(): ERROR: Preferred Route ID " + preferredRouteId
                                    + " being reported for vendor route slbr not found. Skip record.");
                        }
                        continue;
                    }

                    int slbr = rs.getInt(3);
                    if (rs.wasNull()) {
                        logger.warn("loadVendorRouteSlbr(): ERROR: vendor route slbr is null, skip record. preferred_route_id " + preferredRouteId
                                + " vendor_id " + vendorId);
                        continue;
                    }

                    prefRt.setProviderSlbr(provider, slbr);
                }
                logger.info("loadVendorRouteSlbr(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadVendorRouteSlbr(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    private void loadVendorRouteSrc(Connection con) throws Exception {
        Set<Long> badVendorIds = new HashSet<>(); // for error reporting
        Set<Long> badPreferredRouteIds = new HashSet<>(); // for error reporting
        Set<Long> badRouteClassificationIds = new HashSet<>(); // for error reporting
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                stmt.setFetchSize(this.fsVendorSrc);
                logger.info("loadVendorRouteSrc(): " + RMSQueries.ITVW_VENDOR_ROUTE_CLASSIFIC + " Fetch size - " + this.fsVendorSrc);
                rs = stmt.executeQuery(RMSQueries.ITVW_VENDOR_ROUTE_CLASSIFIC);
                logger.info("loadVendorRouteSrc(): Done executing query. Processing data...");

                Provider provider = null;
                PreferredRoute prefRt = null;
                RouteClassification routeClassification = null;
                while (rs.next()) {
                    long vendorId = rs.getLong(1/* vendor_id */);
                    long preferredRouteID = rs.getLong(2/* "preferred_route_id" */);
                    long routeClassificationID = rs.getLong(3/* "route_classification_id" */);
                    provider = providers.get(vendorId);
                    if (provider == null) {
                        if (!badVendorIds.contains(vendorId)) {
                            badVendorIds.add(vendorId);
                            logger.warn("loadVendorRouteSrc(): ERROR: vendorId " + vendorId + " being reported for vendor route classification not found");
                        }
                        continue;
                    }

                    prefRt = preferredRoutes.get(preferredRouteID);
                    if (prefRt == null) {
                        if (!badPreferredRouteIds.contains(preferredRouteID)) {
                            badPreferredRouteIds.add(preferredRouteID);
                            logger.warn("loadVendorRouteSrc(): ERROR: Preferred Route ID " + preferredRouteID
                                    + " being reported for vendor route classification not found");
                        }
                        continue;
                    }

                    routeClassification = routeClassifications.get(routeClassificationID);
                    if (routeClassification == null) {
                        if (!badRouteClassificationIds.contains(routeClassificationID)) {
                            badRouteClassificationIds.add(routeClassificationID);
                            logger.warn("loadVendorRouteSrc(): ERROR: Route Classification ID " + routeClassificationID
                                    + " being reported for vendor route classification not found");
                        }
                        continue;
                    }

                    prefRt.setProviderClassification(provider, routeClassification);
                }
                logger.info("loadVendorRouteSrc(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadVendorRouteSrc(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    @Override
    public void loadSRCSettings() throws Exception {
        Connection con = null;
        try {
            con = dbConnection.getRMSConnection();
            loadSrcTestInclusion(con);
            loadVendorRouteSrc(con);
            loadVendorRouteSlbr(con);
        } catch (Exception ex) {
            logger.error("loadSRCSettings(): Exception " + ex);
            throw ex;
        } finally {
            if (con != null) {
                con.close();
            }
        }
    }

    /**
     * This method is used for Mid process Generation.
     *
     * @return
     * @throws Exception
     */
    @Override
    public int genMidProcess() throws Exception {
        int retVal = -1;
        Connection con = null;
        CallableStatement callst = null;
        try {
            con = dbConnection.getRMSConnection();
            if (con != null) {
                callst = con.prepareCall(DataManagerConstants.MID_PROCESS_CALL);
                callst.registerOutParameter(1, Types.INTEGER);
                Calendar cal = Calendar.getInstance(TimeZone.getDefault());

                logger.info("genMidProcess(): Executing oracle function " + DataManagerConstants.MID_PROCESS_CALL + " Time : " + cal.getTime() + " ...");
                java.sql.Date jsqlDt = new java.sql.Date(cal.getTime().getTime());
                callst.setDate(2, jsqlDt);

                if (iTestConstants.MID_PROCESS_TIMEOUT_MIN > 0) {
                    logger.info("genMidProcess(): Time out is set to " + iTestConstants.MID_PROCESS_TIMEOUT_MIN + " minutes.");
                    callst.setQueryTimeout(iTestConstants.MID_PROCESS_TIMEOUT_MIN * 60);

                } else {
                    logger.info("genMidProcess(): No time out is set");
                }
                callst.execute();
                retVal = callst.getInt(1);
                if (retVal == 0) {
                    logger.info("genMidProcess(): Successfully executed oracle function  " + DataManagerConstants.MID_PROCESS_CALL);
                } else {
                    logger.info("genMidProcess(): Failed executing oracle function " + DataManagerConstants.MID_PROCESS_CALL + ". Error returned - " + retVal);
                }
            } else {
                logger.error("genMidProcess(): Failed to get DB connection!");
            }
        } catch (Exception ex) {
            logger.error("genMidProcess(): Generated exception", ex);
            throw ex;
        } finally {
            if (callst != null) {
                callst.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return retVal;
    }

    @Override
    public void loadiTestConfiguration() throws Exception {
        Connection con = null;
        try {
            con = dbConnection.getRMSConnection();
            loadGcsRules(con);
        } catch (Exception ex) {
            logger.error("loadiTestConfiguration(): Exception " + ex);
            throw ex;
        } finally {
            if (con != null) {
                con.close();
            }
        }
    }

    private boolean isValidTestRule(String rule) {
        return rule.equals("PV TEST") ||
               rule.equals("CV TEST") ||
               rule.equals("NEW PATTERN") ||
               rule.equals("TG OOS") ||
               rule.equals("NON ROUTABLE");
    }

    private boolean isValidStatusCategory(String category) {
        return category == null ||
               category.equals("TEST") ||
               category.equals("ROUTABLE") ||
               category.equals("NON-ROUTABLE");
    }

    /**
     * groupId is voice_carrier_group.group_id; the value can also be multiple group IDs (comma separated)
     * @param groupId
     * @return
     */
    private Set<VoiceCarrierGroup> getVoiceCarrierGroups(String groupId) {
        Set<VoiceCarrierGroup> groups = new HashSet<>();
        if (groupId != null) {
            String[] groupIds = StringUtils.split(groupId, ",");
            for (String gid: groupIds) {
                VoiceCarrierGroup vcg = voiceCarrierGroups.get(Long.parseLong(gid.trim()));
                if (vcg != null) {
                    groups.add(vcg);
                }
            }
        }
        return groups;
    }

    /**
     *
     * itest_rule can be one of the following:
     *   PV TEST
     *   CV TEST
     *   NEW PATTERN
     *   TG OOS
     *   NON ROUTABLE
     *
     * pv_status_category and cv_status_category can be one of the following:
     *   TEST
     *   ROUTABLE
     *   NON-ROUTABLE
     *   null value
     *
     * gcs_block_group_id and gcs_test_group_id are from voice_carrier_group table; can have multiple group_id (comma separated)
     *
     * @param con
     * @throws Exception
     */
    private void loadGcsRules(Connection con) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (con != null) {
                stmt = con.createStatement();
                logger.info("loadGcsRules(): " + RMSQueries.ITVW_ITEST_GCS_RULES);
                rs = stmt.executeQuery(RMSQueries.ITVW_ITEST_GCS_RULES);
                logger.info("loadGcsRules(): Done executing query. Processing data...");

                while (rs.next()) {
                    TestRule gcsRule = new TestRule();

                    //itest_rule can be one of the following: "PV TEST", "CV TEST", "NEW PATTERN", "TG OOS", "NON ROUTABLE"
                    String itestRule = rs.getString(1); // itest_rule

                    //pv_status_category and cv_status_category can be one of the following: "TEST", "ROUTABLE", "NON-ROUTABLE", null
                    String pvStatusCategory = rs.getString(2); // pv_status_category
                    String cvStatusCategory = rs.getString(3); // cv_status_category

                    //gcs_block_group_id and gcs_test_group_id are from voice_carrier_group table; can have multiple group_id (comma separated)
                    String blockGroupId = rs.getString(4); // gcs_block_group_id
                    String testGroupId = rs.getString(5); // gcs_test_group_id

                    if (!isValidTestRule(itestRule)) {
                        throw new Exception("Invalid itest_rule: " + itestRule + ". It should be one of the following values: \"PV TEST\", \"CV TEST\", \"NEW PATTERN\", \"TG OOS\", or \"NON ROUTABLE\"");
                    }
                    if (!isValidStatusCategory(pvStatusCategory)) {
                        throw new Exception("Invalid pv_status_category: " + pvStatusCategory + ". It should be one of the following values: TEST, ROUTABLE, NON-ROUTABLE, or null.");
                    }
                    if (!isValidStatusCategory(cvStatusCategory)) {
                        throw new Exception("Invalid cv_status_category: " + cvStatusCategory + ". It should be one of the following values: TEST, ROUTABLE, NON-ROUTABLE, or null.");
                    }

                    gcsRule.setTestRule(itestRule);
                    gcsRule.setPvStatusCategory(pvStatusCategory);
                    gcsRule.setCvStatusCategory(cvStatusCategory);
                    gcsRule.setBlockGroups(getVoiceCarrierGroups(blockGroupId));
                    gcsRule.setTestGroups(getVoiceCarrierGroups(testGroupId));

                    String key = gcsRule.getTestRule() + "." + (gcsRule.getPvStatusCategory()==null?"":gcsRule.getPvStatusCategory()) + "." + (gcsRule.getCvStatusCategory()==null?"":gcsRule.getCvStatusCategory());
                    gcsRules.put(key, gcsRule);

                }
                logger.info("loadGcsRules(): Done processing data");
            }
        } catch (Exception e) {
            logger.error("Exception in loadGcsRules(). ", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    @Override
    public Map<String, TestRule> getTestRules() {
        return gcsRules;
    }

}
