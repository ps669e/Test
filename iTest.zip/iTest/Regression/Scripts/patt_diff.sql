connect &1

set timing off
set pagesize 0
set feedback off
set termout off

spool patt_diff.txt

select distinct sum(dbms_utility.get_hash_value(pattern,0,1000000)) as hashsum from matchpatterns_reg group by route_key
MINUS 
select distinct sum(dbms_utility.get_hash_value(p.pattern,0,1000000)) as hashsum from matchpatterns p, routes r, routingtable rt where r.route_key = p.route_key and r.routingtable_key = rt.routingtable_key and rt.update_by_iroute = 'Y' group by p.route_key 
order by hashsum;

spool off
exit;
