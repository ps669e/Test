/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.domain;

/**
 * @author schan
 *
 */
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.config.iTestConfigManager;

public class PreferredRoute {

    private static final Log logger = LogFactory.getLog(PreferredRoute.class);

    //Prevents continuous error output of missing floor on same preferred route
    private boolean missingFloorReported = false;

    private long preferredRouteId; //preferred route id in RMS

    private String name; //preferred route name

    private long countryId; //country_id

    private List<DialPattern> dialPatterns = new ArrayList<>(); //dial patterns in it

    private Country country; //country it belongs to

    private Map<Product, Map<Integer, FloorRate>> floorRates = new HashMap<>(); //all floor rates defined on it

    private Map<Provider, RouteClassification> providerRouteClassifications = new HashMap<>();

    private Map<Provider, Integer> providerRouteSlbr = new HashMap<>();

    private boolean isTodEnabled = true; // is tod enabled for this preferred route?
    private Map<Integer, TimeOfDay> timeofDayMap = new HashMap<>();
    private byte isTod = -1;
    private Collection<TimeOfDay> tods = null;
    private Collection<TimeOfDay> lineupTods = null; // this is for lineup

    private boolean isPeakOffpeakNot24HrReported = false;

    private Map<Provider, RouteStatus> vendorRouteStatusPvMap = null;

    private Map<Provider, RouteStatus> vendorRouteStatusCvMap = null;

    private Set<Provider> multiMtrVendors = new HashSet<>();

    private Map<Provider, iTestVendor> itestVendors = new HashMap<>();


    /**
     * Default constructor
     *
     */
    public PreferredRoute() {
    }

    /**
     * Constructor
     *
     * @param preferredRouteId
     * @param name
     * @param countryId
     *
     */
    public PreferredRoute(long preferredRouteId, String name, long countryId) {
        this.preferredRouteId = preferredRouteId;
        this.name = name;
        this.countryId = countryId;
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof PreferredRoute)) {
            return false;
        }
        PreferredRoute castOther = (PreferredRoute) other;
        return this.equals(castOther);
    }

    public boolean equals(PreferredRoute other) {
        return (this.getPreferredRouteId() == other.getPreferredRouteId());
    }

    @Override
    public int hashCode() {
        return Long.valueOf(preferredRouteId).hashCode();
    }

    public long getPreferredRouteId() {
        return this.preferredRouteId;
    }

    public void setPreferredRouteId(long preferredRouteId) {
        this.preferredRouteId = preferredRouteId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String inName) {
        this.name = inName;
    }

    public List<DialPattern> getDialPatterns() {
        return dialPatterns;
    }

    public long getCountryId() {
        return this.countryId;
    }

    public void setCountryId(long inCountryId) {
        this.countryId = inCountryId;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    /**
     * Given a pattern string firs checks if a DialPattern is already recorded.
     * Ifd so returns the DialPattern, otherwise creates a new DialPattern and
     * returns it.
     *
     * @param patternStr
     * @param routeID unique key in RMS for pattern
     * @return DialPattern found or added
     * @throws Exception
     */
    public DialPattern recordDialPattern(String patternStr, long routeID) throws Exception {
        DialPattern dp = country.findPattern(patternStr);
        if (dp == null) {
            dp = addDialPattern(patternStr, routeID);
        }
        return dp;
    }

    /**
     * Adds a new dial pattern to the system and returns the created instance
     *
     * @param patternStr
     * @param routeID
     * @return
     * @throws Exception
     */
    public DialPattern addDialPattern(String patternStr, long routeID) throws Exception {
        DialPattern dp = country.recordDialPattern(patternStr);
        if (dp != null) {
            dp.setRouteID(routeID);
            dialPatterns.add(dp);
            dp.setPreferredRoute(this);
        } else {
            logger.error("recordDialPattern(): Failed to add dial pattern due to null pattern : " + patternStr);
        }

        return dp;
    }

    /**
     * Records a preferred route pattern. Tries to find the dial pattern in memory first.
     * If not found adds it. Either case returns the instance.
     *
     * @param patternStr
     * @param routeID
     * @throws Exception
     */
    public void recordPRPattern(String patternStr, long routeID) throws Exception {
        DialPattern dp = country.findPattern(patternStr);
        if (dp == null) {
            dp = addDialPattern(patternStr, routeID);
            if (dp != null) {
                dp.setIsPRPattern(true);
                dp.setRouteID(routeID);
            } else {
                logger.error("recordPRPattern(): failed to add PR pattern due to null pattern: \n" + "Preferred Route ID " + this.getPreferredRouteId() + "\n"
                        + "Pattern " + patternStr + "\n" + "routeID " + routeID + "\n");
            }
        } else {
            logger.error("recordPRPattern(): failed to add PR pattern due to duplicate pattern: \n" + "Preferred Route ID " + this.getPreferredRouteId() + "\n"
                    + "Pattern " + patternStr + "\n" + "routeID " + routeID + "\n");
        }
    }

    /**
     * Records rates for given pattern and provider
     *
     * @param provider
     * @param dp
     * @param cost
     * @param maxNetCost
     * @param minNetCost
     * @param minRate
     * @param maxRate
     * @param multiRateInd
     * @param isProperInd
     * @param isPartialCovgInd
     */
    public void recordRatePattern(Provider provider, DialPattern dp, double cost, double maxNetCost, double minNetCost, double minRate, double maxRate,
            String multiRateInd, String isProperInd, TimeOfDay tod) throws Exception {
        if (dp != null) {
            //Look for already recorded provider coverage to prevent duplicate rate information
            ProviderCoverage coverage = dp.getCoverageByProvider(provider);
            if (coverage == null) { // No duplicate rate coverage found
                dp.setIsProper(isProperInd.toUpperCase().equals("Y"));
                ProviderRate rate = new ProviderRate(provider, cost, minNetCost, maxNetCost, minRate, maxRate, multiRateInd, dp.getIsProper(), dp, tod);
                dp.addProviderRate(rate);
                coverage = new ProviderCoverage(provider);
                coverage.setProvPattern(true);
                coverage.setDialPattern(dp);
                dp.addProviderCoverage(coverage);
                rate.setProviderCoverage(coverage);
            } else {
                try {
                    Map<Integer, ProviderRate> rates = coverage.getProviderRates();
                    if (rates.get(tod.getPeriodId()) != null) {
                        logger.error("recordRatePattern(): Duplicate rate coverage. Rate entry ignored: \n" + "Preferred Route ID " + this.getPreferredRouteId()
                                + "\n" + "Pattern " + dp.getPattern() + "\n" + "VendorId " + provider.getVendorId() + "\n" + "cost " + cost + "\n"
                                + "maxNetCost " + maxNetCost + "\n" + "minNetCost " + minNetCost + "\n" + "minRate " + minRate + "\n" + "maxRate " + maxRate
                                + "\n" + "multiRateInd " + multiRateInd + "\n" + "period id " + tod.getPeriodId() + "start time " + tod.getStartTime()
                                + "end time " + tod.getEndTime() + "start week day " + tod.getStartWeekDay() + "end week day " + tod.getEndWeekDay());
                    } else {
                        ProviderRate rate = new ProviderRate(provider, cost, minNetCost, maxNetCost, minRate, maxRate, multiRateInd, dp.getIsProper(), dp, tod);
                        dp.addProviderRate(rate);
                        rate.setProviderCoverage(coverage);
                    }
                } catch (Exception e) {
                    throw e;
                }

            }
        } else {
            logger.error("recordRatePattern(): Failed to add rate pattern due to null pattern: \n" + "Preferred Route ID " + this.getPreferredRouteId() + "\n"
                    + "cost " + cost + "\n" + "maxNetCost " + maxNetCost + "\n" + "minNetCost " + minNetCost + "\n" + "minRate " + minRate + "\n" + "maxRate "
                    + maxRate + "\n" + "multiRateInd " + multiRateInd + "\n" + "period id " + tod.getPeriodId() + "start time " + tod.getStartTime()
                    + "end time " + tod.getEndTime() + "start week day " + tod.getStartWeekDay() + "end week day " + tod.getEndWeekDay());
        }
    }

    /**
     * Records status code for given pattern provider combination.
     * Optimizes coverage by ignoring status codes that are same as
     * nearest parent pattern for same provider.
     *
     * @param provider
     * @param dp
     * @param routeStatus
     * @param inTest
     * @param premTest
     */
    public void recordStatus(Provider provider, DialPattern dp, RouteStatus routeStatus, boolean inTest) {

        if (dp != null) {
            ProviderCoverage coverage = dp.getCoverageByProvider(provider);
            if (coverage == null) {
                coverage = dp.findCoverageByProvider(provider);
                if (coverage != null) { // We have coverage
                    // If we need to report on status inheritance this logic has to be undone
                    // and we have to create coverage for all status entries.
                    // This is being done for memory optimization.
                    // Coverage is same if parent is not partial coverage and status is same and if in testing both are in testing
                    if (coverage.getRouteStatusID() != routeStatus.getId()
                            || (coverage.getRouteStatusID() == routeStatus.getId())) {
                        //Status is different than parent- cannot optimize
                        coverage = coverage.statusClone();
                        coverage.setDialPattern(dp);
                        dp.addProviderCoverage(coverage);
                    } else {
                        // Status is same as some parent, coverage will be
                        // inherited during coverage inheritance. So we can ignore.
                        return;
                    }
                } else {
                    // Creating coverage anyway to inherit status code down hierarchy
                    coverage = new ProviderCoverage(provider);
                    coverage.setDialPattern(dp);
                    dp.addProviderCoverage(coverage);
                }
            }
            if (coverage != null) {
                coverage.setRouteStatus(routeStatus);
                coverage.setInTesting(inTest);
            }
        } else {
            logger.error("recordStatus(): Failed to add status pattern due to null pattern: \n" + "Preferred Route ID " + this.getPreferredRouteId() + "\n"
                    + "routeStatusID " + routeStatus.getId() + "\n" + "routeStatusCode " + routeStatus.getCode() + "\n" + "rank " + routeStatus.getRank());
        }
    }

    /**
     * Records status code for given pattern provider combination. There is no optimization performed.
     *
     * @param provider
     * @param dp
     * @param routeStatus
     * @param inTest
     * @param premTest
     */
    public void recordStatusNoOptimize(Provider provider, DialPattern dp, RouteStatus routeStatus, boolean inTest) {

        if (dp != null) {
            //Need check for cvg existence as we may have created
            //cvg if there were rates against this pattern-provider
            ProviderCoverage coverage = dp.getCoverageByProvider(provider);
            if (coverage == null) {
                //no cvg exists - need to create
                coverage = new ProviderCoverage(provider);
                coverage.setDialPattern(dp);
                dp.addProviderCoverage(coverage);
            }
            if (coverage != null) {
                //record status
                coverage.setRouteStatus(routeStatus);
                coverage.setInTesting(inTest);
            }
        } else {
            logger.error("recordStatusNoOptimize(): Failed to add status pattern due to null pattern: \n" + "Preferred Route ID " + this.getPreferredRouteId()
                    + "\n" + "routeStatusID " + routeStatus.getId() + "\n" + "routeStatusCode " + routeStatus.getCode() + "\n" + "rank "
                    + routeStatus.getRank());
        }
    }

    public void recordNewVendorRatePattern(Provider provider, DialPattern dp) {
        if (dp != null) {
            //Need check for cvg existence as we may have created cvg if there were rates against this pattern-provider
            ProviderCoverage coverage = dp.getCoverageByProvider(provider);
            if (coverage == null) {
                //no cvg exists - need to create
                coverage = new ProviderCoverage(provider);
                coverage.setDialPattern(dp);
                dp.addProviderCoverage(coverage);
            }
            if (coverage != null) {
                coverage.setNewPattern(true);
            }
        } else {
            logger.error("recordNewVendorPattern(): Failed to add new vendor rate pattern due to null pattern: \n" + "Preferred Route ID " + this.getPreferredRouteId());
        }
    }

    //without TOD, assuming peak
    public void addFloorRate(Product product, FloorRate floorRate) {
        addFloorRateByProductPeriodId(product, DomainConstants.RMS_PEAK_PERIOD_ID, floorRate);
    }

    public void addFloorRateByProductPeriodId(Product product, int pid, FloorRate floorRate) {
        Map<Integer, FloorRate> pidRates = this.floorRates.get(product);
        if (pidRates != null) {
            FloorRate fr = pidRates.get(pid);
            if (fr != null) {
                logger.error("Duplicate Floor Rate of period " + pid + " for product " + product.getDescription());
            } else {
                pidRates.put(pid, floorRate);
            }
        } else {
            pidRates = new HashMap<>();
            pidRates.put(pid, floorRate);
            floorRates.put(product, pidRates);
        }
    }

    //without TOD, assuming peak
    public FloorRate getFloorRateByProduct(Product product) {
        if (product != null) {
            return getFloorRateByProductPeriodId(product, DomainConstants.RMS_PEAK_PERIOD_ID);
        }
        return null;
    }

    /**
     * This method return preferred route level tod product floor.
     * Caller is responsible to get pending active floor.
     *
     * @param product
     * @param periodId
     * @return
     */
    public FloorRate getFloorRateByProductPeriodId(Product product, int periodId) {
        if (product != null) {
            Map<Integer, FloorRate> pidRates = this.floorRates.get(product);
            FloorRate fr = null;
            if (pidRates != null) {
                fr = pidRates.get(periodId);
            }
            return fr;
        }
        return null;
    }

    public Map<Product, Map<Integer, FloorRate>> getFloorRates() {
        return floorRates;
    }

    /**
     * Get pattern floor by product. If none, get preferred route floor by product.
     *
     * @param dp
     * @param product
     * @param prefRoutePeriodId
     * @return
     * @throws Exception
     */
    public FloorRate getFloorRate(DialPattern dp, Product product, int prefRoutePeriodId) throws Exception {
        FloorRate floorRate = null;
        boolean hasPatternFloor = dp.getPendingActiveFloorRates() != null;

        if (hasPatternFloor) {
            floorRate = dp.getFloorRateByProductPeriodId(product, prefRoutePeriodId);
            if (floorRate == null && DomainConstants.RMS_PEAK_PERIOD_ID != prefRoutePeriodId) {
                floorRate = dp.getFloorRateByProductPeriodId(product, DomainConstants.RMS_PEAK_PERIOD_ID);
            }
        }

        if (floorRate == null) {
            floorRate = getFloorRateByProductPeriodId(product, prefRoutePeriodId);
            if (floorRate == null && DomainConstants.RMS_PEAK_PERIOD_ID != prefRoutePeriodId) {
                // use peak floor if other period's floor is missing
                floorRate = getFloorRateByProductPeriodId(product, DomainConstants.RMS_PEAK_PERIOD_ID);
            }
        }

        if (floorRate == null) {
            // peak floor is still missing
            if (!isMissingFloorReported()) {
                logger.error("getFloorRate(): Preferred Route " + getName() + " is missing Floor for major product!");
                setMissingFloorReported(true);
                if (!getCountry().isMissingFloor()) {
                    getCountry().setMissingFloor(true);
                }
            }
        }
        return floorRate;
    }

    /*
     * This method for adding dialpattern
     */
    public void addPattern(DialPattern dp) {
        dialPatterns.add(dp);
    }

    public void removePattern(DialPattern dp) {
        dialPatterns.remove(dp);
    }

    /**
     * @return
     */
    public boolean isMissingFloorReported() {
        return missingFloorReported;
    }

    /**
     * @param b
     */
    public void setMissingFloorReported(boolean b) {
        missingFloorReported = b;
    }

    public void clearData() {
        dialPatterns = null;
        floorRates = null;
        providerRouteClassifications = null;
        providerRouteSlbr = null;
        timeofDayMap = null;
        tods = null;
    }

    public Map<Integer, TimeOfDay> getTimeofDayMap() {
        return timeofDayMap;
    }

    public void addTimeofDayByPeriodId(int pid, TimeOfDay tod) {
        if (timeofDayMap.get(pid) != null) {
            logger.error("Duplicate TOD period " + pid);
        } else {
            timeofDayMap.put(pid, tod);
        }
    }

    public TimeOfDay getTimeofDayByPeriodId(int pid) {
        return timeofDayMap.get(pid);
    }

    /**
     * Note:
     * peak start/time cannot be null
     * off peak start/end time can be null
     * weekend start/end time, start/end day cannot be null
     *
     * aqrvw_preferred_route_period
     *
     * period start_time end_time isTod comment
     * ----------------------------------------------------
     * case 1 p xxx xxx n peak record is not in the view
     *
     * case 2 p 00:00:00 23:59:59 n
     * o 23:59:59 00:00:00
     *
     * case 3 p xxx xxx y weekend & weekday
     * w 18:00:00 07:00:00 weekend is the only record
     *
     * case 4 p 07:00:00 18:00:00 y
     * o 18:00:00 07:00:00
     *
     * case 4.1 p 07:00:00 14:00:00 n peak and off peak do not cover 24-hr is considered non-tod
     * o 18:00:00 07:00:00
     *
     * case 5 p 00:00:00 23:59:59 y weekend & weekday
     * o 23:59:59 00:00:00
     * w F18:00:00 M07:00:00
     *
     * case 6 p 07:00:00 18:00:00 y
     * o 18:00:00 07:00:00
     * w F18:00:00 M07:00:00
     *
     * case 6.1 p 07:00:00 14:00:00 y weekend & weekday
     * o 18:00:00 07:00:00 peak and off peak do not cover 24-hr will be ignored
     * w F18:00:00 M07:00:00
     *
     * Following cases are not valid since peak and off peak are
     * defined in one record and peak start/end time cannot be null.
     *
     * case 7 p xxx xxx n
     * o 07:00:00 18:00:00 off peak will be ignored
     *
     * case 8 p xxx xxx y weekend & weekday
     * o 23:59:59 00:00:00 off peak will be ignored
     * w F18:00:00 M07:00:00
     *
     * @return boolean value that indicates whether preferred route has tod period
     */
    public boolean isTod() {
        if (-1 == isTod) {
            isTod = 0;
            // Empty timeofDayMap means no period definition for this preferred route so it is non-tod
            if (this.isTodEnabled() && !timeofDayMap.isEmpty()) {
                TimeOfDay peakTod = timeofDayMap.get(DomainConstants.RMS_PEAK_PERIOD_ID);
                TimeOfDay offpeakTod = timeofDayMap.get(DomainConstants.RMS_OFFPEAK_PERIOD_ID);
                TimeOfDay weekendTod = timeofDayMap.get(DomainConstants.RMS_WEEKEND_PERIOD_ID);

                if (1 == timeofDayMap.size()) {
                    if (weekendTod != null) {
                        isTod = 1; // case 3
                    }
                } else if (2 == timeofDayMap.size()) {
                    String defaultStartTime = iTestConfigManager.getInstance().getTodDefaultWeekDayStartTime(); // 00:00:00
                    String defaultEndTime = iTestConfigManager.getInstance().getTodDefaultWeekDayStopTime(); // 23:59:59
                    if (peakTod != null && offpeakTod != null) {
                        // po
                        if (peakTod.getStartTime() == null || peakTod.getEndTime() == null) {
                            isTod = 0; // case 7
                        } else if (peakTod.getStartTime().equals(defaultStartTime) && peakTod.getEndTime().equals(defaultEndTime)
                                && offpeakTod.getStartTime().equals(defaultEndTime) && offpeakTod.getEndTime().equals(defaultStartTime)) {
                            isTod = 0; // case 2
                        } else {
                            if (is24HrPeakOffpeak(peakTod, offpeakTod)) {
                                // case 4
                                isTod = 1;
                            } else {
                                // case 4.1
                                isTod = 0;
                            }
                        }
                    } else if (peakTod != null && weekendTod != null) {
                        // pw
                        if (peakTod.getStartTime() == null || peakTod.getEndTime() == null) {
                            isTod = 1; // case 3
                        }
                    }
                } else { // timeofDayMap.size is 3
                    // pow
                    // off peak and weekend must have start and end time, otherwise data loading will filter them
                    isTod = 1; // case 5, 6, 6.1, 8,
                }
            }
            //case 1 - timeofDayMap is empty or tod is off globally or at preferred route level
        }
        return 1 == isTod;
    }

    public void setTodEnabled(boolean isTodEnabled) {
        this.isTodEnabled = isTodEnabled;
    }

    /**
     * default is true
     *
     * @return
     */
    public boolean isTodEnabled() {
        return this.isTodEnabled;
    }

    /**
     * It prepares a collection of Preferred Route TimeOfDay objects.
     * If global TOD or preferred route level TOD is disabled, this method
     * return a dummy Peak TimeOfDay.
     *
     * @return
     */
    public Collection<TimeOfDay> getPreferredRoutePeriods() {
        if (tods == null) {
            tods = new ArrayList<>();
            if (this.isTod()) {
                tods = this.getTimeofDayMap().values();
            } else {
                // create a dummy peak TimeOfDay for not-tod
                timeofDayMap.clear();
                if (logger.isDebugEnabled()) {
                    logger.debug("creating a dummy peak TimeOfDay for preferred route: " + this.preferredRouteId);
                }
                TimeOfDay tod = new TimeOfDay(DomainConstants.RMS_PEAK_PERIOD_ID, null, null, DomainConstants.NULL_VALUE, DomainConstants.NULL_VALUE);
                timeofDayMap.put(DomainConstants.RMS_PEAK_PERIOD_ID, tod);
                tods.add(tod);
            }

            if (tods == null || tods.isEmpty()) {
                logger.error("getPreferredRoutePeriods() Preferred route, " + this.getName() + ", has no period definition.");
            }
        }
        return tods;
    }

    /**
     * This method determine whether this preferred route has weekend only settings.
     * If so, this method will return weekday and weekend TimeOfDay objects,
     * where weekday settings will be the flip of weekend settings.
     * <p>
     * If this preferred route does not contain weekend only tod, this method
     * will return TimeOfDay objects prepared by getPreferredRoutePeriods method.
     * <p>
     * Weekend Only TOD will have the following settings in RMS:
     * PERIOD START_TIME STOP_TIME START_WEEK_DAY STOP_WEEK_DAY
     * Peak 00:00:00 23:59:59 null null <- hard-coded in rms
     * Off Peak 23:59:59 00:00:00 null null <- hard-coded in rms
     * Weekend 19:00:00 07:00:00 5 1 <- can be anything
     * * @return
     */
    public Collection<TimeOfDay> getPeriodsForLineup() {
        if (lineupTods == null) {
            if (isTod()) {
                if (isWeekendTodSetting()) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("create a weekday TimeOfDay");
                    }
                    TimeOfDay weekendTod = timeofDayMap.get(DomainConstants.RMS_WEEKEND_PERIOD_ID);
                    lineupTods = new ArrayList<>(2);
                    TimeOfDay weekdayTod = new TimeOfDay(DomainConstants.RMS_WEEKDAY_PERIOD_ID, weekendTod.getEndTime(), weekendTod.getStartTime(),
                            weekendTod.getEndWeekDay(), weekendTod.getStartWeekDay());
                    lineupTods.add(weekdayTod);
                    lineupTods.add(weekendTod);
                } else {
                    lineupTods = getPreferredRoutePeriods();
                }
            } else {
                lineupTods = getPreferredRoutePeriods();
            }
        }
        return lineupTods;
    }

    private boolean isWeekendTodSetting() {
        TimeOfDay peakTod = timeofDayMap.get(DomainConstants.RMS_PEAK_PERIOD_ID);
        TimeOfDay offpeakTod = timeofDayMap.get(DomainConstants.RMS_OFFPEAK_PERIOD_ID);
        TimeOfDay weekendTod = timeofDayMap.get(DomainConstants.RMS_WEEKEND_PERIOD_ID);

        if (peakTod != null && offpeakTod != null && weekendTod != null) {
            String startTime = iTestConfigManager.getInstance().getTodDefaultWeekDayStartTime(); // 00:00:00
            String endTime = iTestConfigManager.getInstance().getTodDefaultWeekDayStopTime(); // 23:59:59
            if (is24HrPeakOffpeak(peakTod, offpeakTod)) {
                if (0 == peakTod.getStartTime().compareTo(startTime) && 0 == peakTod.getEndTime().compareTo(endTime)
                        && 0 == offpeakTod.getStartTime().compareTo(endTime) && 0 == offpeakTod.getEndTime().compareTo(startTime)) {
                    //P 00:00:00 23:59:59 and O 23:59:59 00:00:00 situation
                    return true;
                } else {
                    // not P 00:00:00 23:59:59 and O 23:59:59 00:00:00 situation
                    return false;
                }
            } else {
                // peak and offpeak do not cover 24 hrs; or start / end time is null
                return true;
            }
        }

        if (peakTod == null && offpeakTod == null && weekendTod != null) {
            // isTod - case 3
            return true;
        }

        if (peakTod != null && offpeakTod == null && weekendTod != null) {
            if (peakTod.getStartTime() == null || peakTod.getEndTime() == null) {
                // variant of case 3
                return true;
            }
        }

        return false;
    }

    private boolean is24HrPeakOffpeak(TimeOfDay peakTod, TimeOfDay offpeakTod) {
        boolean isTodPeakOffpeak24Hr = false;
        if (peakTod != null && offpeakTod != null) {
            String pStart = peakTod.getStartTime();
            String pEnd = peakTod.getEndTime();
            String oStart = offpeakTod.getStartTime();
            String oEnd = offpeakTod.getEndTime();
            if (pStart != null && pEnd != null && oStart != null && oEnd != null) {
                if (pStart.equals(oEnd) && pEnd.equals(oStart)) {
                    isTodPeakOffpeak24Hr = true;
                } else {
                    if (!isPeakOffpeakNot24HrReported) {
                        // report peak and off-peak not cover 24hr only once per preferred route
                        // only when both peak and off-peak start & end times have values
                        isPeakOffpeakNot24HrReported = true;
                        logger.error("Peak and off-peak periods of preferred route " + this.name
                                + " do not cover a 24-hour period - it will be treated as non-tod.");
                    }
                }
            }
        }

        return isTodPeakOffpeak24Hr;
    }

    @Override
    public String toString() {
        return "{id:" + getPreferredRouteId() + ",countryId:" + getCountryId() + ",desc:" + getName() + "}";
    }

    public RouteClassification getProviderSrc(Provider provider) {
        RouteClassification rc = null;
        if (providerRouteClassifications != null) {
            rc = providerRouteClassifications.get(provider);
        }
        return rc;
    }

    public void setProviderClassification(Provider provider, RouteClassification routeClassification) {
        providerRouteClassifications.put(provider, routeClassification);
    }

    public Integer getProviderSlbr(Provider provider) {
        Integer slbr = null;
        if (providerRouteSlbr != null) {
            slbr = providerRouteSlbr.get(provider);
        }
        return slbr;
    }

    public void setProviderSlbr(Provider provider, int slbr) {
        providerRouteSlbr.put(provider, slbr);
    }

    public boolean isBlacklistVendor(Provider provider) {
        RouteClassification src = getProviderSrc(provider);
        if (src != null && src.getRouteClassificationId() == DomainConstants.SRC_BLACKLIST_ID) {
            return true;
        }
        return false;
    }

    /**
     * This method records vendor status code at preferred route level.
     * If this method is called more than once for the same vendor, the last call
     * will override previously set status code.
     *
     * @param provider
     * @param pvStatus
     * @param cvStatus
     */
    public void addVendorRouteStatus(Provider provider, RouteStatus pvStatus, RouteStatus cvStatus) {
        if (provider != null) {
            if (pvStatus != null) {
                if (vendorRouteStatusPvMap == null) {
                    vendorRouteStatusPvMap = new HashMap<>();
                }
                vendorRouteStatusPvMap.put(provider, pvStatus);
            }
            if (cvStatus != null) {
                if (vendorRouteStatusCvMap == null) {
                    vendorRouteStatusCvMap = new HashMap<>();
                }
                vendorRouteStatusCvMap.put(provider, cvStatus);
            }
        }
    }

    public RouteStatus getVendorRouteStatusPv(Provider provider) {
        RouteStatus status = null;
        if (vendorRouteStatusPvMap != null) {
            status = vendorRouteStatusPvMap.get(provider);
        }
        return status;
    }

    public RouteStatus getVendorRouteStatusCv(Provider provider) {
        RouteStatus status = null;
        if (vendorRouteStatusCvMap != null) {
            status = vendorRouteStatusCvMap.get(provider);
        }
        return status;
    }

    public boolean hasVendorRequestedPvTesting(Provider provider) {
        RouteStatus status = null;
        if (vendorRouteStatusPvMap != null) {
            status = vendorRouteStatusPvMap.get(provider);
            if (status != null && status.isPV() && DomainConstants.TEST == status.getCategoryCode()) {
                return true;
            }
        }
        return false;
    }

    public boolean hasVendorRequestedCvTesting(Provider provider) {
        RouteStatus status = null;
        if (vendorRouteStatusCvMap != null) {
            status = vendorRouteStatusCvMap.get(provider);
            if (status != null && !status.isPV() && DomainConstants.TEST == status.getCategoryCode()) {
                return true;
            }
        }
        return false;
    }

    public void addMultiMtrVendor(Provider provider) {
        this.multiMtrVendors.add(provider);
    }

    public boolean isMultiMtrVendor(Provider provider) {
        return multiMtrVendors.contains(provider);
    }

    public Set<Provider> getMultiMtrVendors() {
        return this.multiMtrVendors;
    }

    public iTestVendor getiTestVendor(Provider provider) {
        return itestVendors.get(provider);
    }

    public void addiTestVendor(iTestVendor testVendor) {
        Provider provider = testVendor.getProvider();
        itestVendors.put(provider, testVendor);
    }

    public Collection<iTestVendor> getiTestVendors() {
        return itestVendors.values();
    }

}
