/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.rulesengine;

import java.util.Collection;

import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.domain.PreferredRoute;

/**
 * @author schan
 *
 */
public interface iTestRules {

    void applyRulesOnCountry(Collection<Country> countries) throws Exception;

    void applyRulesOnCountry(Country country) throws Exception;

    void applyRulesOnPreferredRoute(Collection<PreferredRoute> preferredRoutes) throws Exception;

    void applyRulesOnPreferredRoute(PreferredRoute preferredRoute) throws Exception;

}
