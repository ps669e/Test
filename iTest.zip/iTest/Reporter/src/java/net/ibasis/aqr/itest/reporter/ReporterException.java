/*
 * ReporterException.java
 * Created on October 31, 2004, 3:52 PM
 */

package net.ibasis.aqr.itest.reporter;

/**
 *
 * @author rkarpov
 */
public class ReporterException extends RuntimeException {

    /** Creates a new instance of ReporterException */
    public ReporterException(String s) {
        super(s);
    }

}
