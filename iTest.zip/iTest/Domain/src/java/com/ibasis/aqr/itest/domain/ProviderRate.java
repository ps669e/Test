/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.domain;

/**
 * @author schan
 *
 */
public class ProviderRate implements Comparable {

    private double cost;

    private double minNetCost;

    private double maxNetCost;

    private double maxRate;

    private double minRate;

    private boolean multiRateInd;

    private TimeOfDay timeOfDay = null;

    private Provider provider;

    private long patternKey;

    private long rateKey = DomainConstants.NULL_LONG_VALUE;

    private boolean properRate = false;

    private DialPattern dialPattern;

    private ProviderCoverage providerCoverage;

    public ProviderRate() {
    }

    public ProviderRate(Provider provider, double cost, double minNetCost, double maxNetCost, double minRate, double maxRate, String multiRate,
            boolean isProperRate, DialPattern dp, TimeOfDay tod) {
        this.cost = cost;
        this.minNetCost = minNetCost;
        this.maxNetCost = maxNetCost;
        this.minRate = minRate;
        this.maxRate = maxRate;
        this.multiRateInd = multiRate.toUpperCase().equals("Y");
        this.setProperRate(isProperRate);
        this.setDialPattern(dp);
        this.setProvider(provider);
        this.timeOfDay = tod;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public double getMinNetCost() {
        return minNetCost;
    }

    public void setMinNetCost(double minNetCost) {
        this.minNetCost = minNetCost;
    }

    public double getMaxNetCost() {
        return maxNetCost;
    }

    public void setMaxNetCost(double maxNetCost) {
        this.maxNetCost = maxNetCost;
    }

    public double getMaxRate() {
        return maxRate;
    }

    public void setMaxRate(double maxRate) {
        this.maxRate = maxRate;
    }

    public double getMinRate() {
        return minRate;
    }

    public void setMinRate(double minRate) {
        this.minRate = minRate;
    }

    public boolean getMultiRateInd() {
        return multiRateInd;
    }

    public void setMultiRateInd(boolean multiRateInd) {
        this.multiRateInd = multiRateInd;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public TimeOfDay getTimeOfDay() {
        return timeOfDay;
    }

    public void setTimeOfDay(TimeOfDay timeOfDay) {
        this.timeOfDay = timeOfDay;
    }

    public double getNetCost() {
        return this.maxNetCost;
    }

    //sort by netcost
    @Override
    public int compareTo(Object o) {
        int result = 0;

        if (!(o instanceof ProviderRate)) {
            throw new ClassCastException();
        }
        ProviderRate pr = (ProviderRate) o;
        double res = this.getCost() - pr.getCost();
        if (res > 0) {
            result = 1;
        } else if (res < 0) {
            result = -1;
        } else { //must be zero. Then compare net cost
            res = this.getNetCost() - pr.getNetCost();
            if (res > 0) {
                result = 1;
            } else if (res < 0) {
                result = -1;
            }
        }

        return result;

    }

    public void setPatternKey(long inPatternKey) {
        this.patternKey = inPatternKey;
    }

    public long getPatternKey() {
        return this.patternKey;
    }

    public void setRateKey(long inRateKey) {
        this.rateKey = inRateKey;
    }

    public long getRateKey() {
        return this.rateKey;
    }

    /**
     * @return Returns the properRate.
     */
    public boolean isProperRate() {
        return properRate;
    }

    /**
     * @param properRate The properRate to set.
     */
    public void setProperRate(boolean properRate) {
        this.properRate = properRate;
    }

    /**
     * @return Returns the providerCoverage.
     */
    public ProviderCoverage getProviderCoverage() {
        return providerCoverage;
    }

    /**
     * @param providerCoverage The providerCoverage to set.
     */
    public void setProviderCoverage(ProviderCoverage providerCoverage) {
        this.providerCoverage = providerCoverage;
    }

    /**
     * @return Returns the dialPattern.
     */
    public DialPattern getDialPattern() {
        return dialPattern;
    }

    /**
     * @param dialPattern The dialPattern to set.
     */
    public void setDialPattern(DialPattern dialPattern) {
        this.dialPattern = dialPattern;
    }

    @Override
    public String toString() {
        return "cost=" + this.cost + ",maxNetCost=" + this.maxNetCost;
    }
}
