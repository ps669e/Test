package com.ibasis.aqr.itest.tools;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PreProcess {
    private static final Log logger = LogFactory.getLog(PreProcess.class);
    private PreProcessProc preProcessProc = null;

    public PreProcess() throws Exception {
        try {
            preProcessProc = new PreProcessProc();
        } catch (Exception e) {
            throw e;
        }
    }

    public int runPreProcess() throws Exception {
        int retVal1 = -1;
        try {
            retVal1 = preProcessProc.genRmsFeed();
        } catch (Exception e) {
            throw e;
        }
        if (retVal1 == 0) {
            return 0;
        } else {
            return -1;
        }
    }

    public static void main(String[] args) {
        try {
            PreProcess preprocess = new PreProcess();
            preprocess.runPreProcess();
        } catch (Exception e) {
            logger.error(e);
            System.exit(1);
        }
    }
}
