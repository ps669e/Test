#!/bin/sh
echo Run iRoute ...
cdir=$PWD 
cd ../
./run.sh
cd $cdir
echo iRoute Run completed - Doing checks ...
./runchecks.sh
