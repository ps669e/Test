package com.ibasis.aqr.itest.tools;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.datamanager.iTestDataManager;

public class PreProcessProc {
    private static final Log logger = LogFactory.getLog(PreProcessProc.class);
    private iTestDataManager dataMgr = null;

    public PreProcessProc() throws Exception {
        try {
            dataMgr = new iTestDataManager();
        } catch (Exception e) {
            throw e;
        }
    }

    public int genRmsFeed() throws Exception {
        int retVal = -1;
        try {
            logger.info("genRmsFeed(): Pre Process starting...!");
            retVal = dataMgr.genRmsFeed();
            if (retVal == 0) {
                logger.info("genRmsFeed(): Successfully completed Pre Process run!");
            } else {
                logger.error("genRmsFeed(): Failed to complete Pre Process run!");
            }
        } catch (Exception e) {
            throw e;
        }
        return retVal;
    }

    public static void main(String[] args) {
        try {
            PreProcessProc preprocessProc = new PreProcessProc();
            preprocessProc.genRmsFeed();
        } catch (Exception e) {
            logger.error(e);
            System.exit(1);
        }
    }
}
