/*
 * Created on Sep 22, 2004
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.ibasis.aqr.itest.dpmanager;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.domain.DialPattern;
import com.ibasis.aqr.itest.tree.NodeNavigator;

/**
 * @author csib
 *
 */
public class CountryNavigator implements NodeNavigator {

    private Log logger = LogFactory.getLog(CountryNavigator.class);

    private Collection<DialPattern> dialPatterns = new ArrayList<>();
    private Country country;

    public CountryNavigator(Country country) {
        this.country = country;
    }

    @Override
    public boolean processNodeObject(Object object) {
        if (object instanceof DialPattern) {
            DialPattern pattern = (DialPattern) object;
            if (pattern.getCountry() == this.country) {
                dialPatterns.add(pattern);
                return true;
            }
        } else {
            logger.error("processNodeObject() : Invalid Object Type!");
        }

        return false;
    }

    public Collection<DialPattern> getDialPatterns() {
        return this.dialPatterns;
    }

}
