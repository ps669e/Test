package com.ibasis.aqr.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Set;

/**
 * This class allows clients to lock multiple objects, but only if none of the (equivalent) objects
 * is locked by other clients.
 */
public final class MultiLock {
    /**
     * This singleton is a placeholder for a cluster-aware construct. JBoss Cache with synchronous
     * replication looks like a reasonable solution, but it's not a high priority at the time
     * of writing.
     * Use the JVM's handling of statics to ensure there's only one instance. This is
     * allegedly safer than wading into the double checked locking controversy.
     */
    private static MultiLock ourInstance = new MultiLock();

    private final HashMap<ExpirationDecorator, ExpirationDecorator> locks = new HashMap<ExpirationDecorator, ExpirationDecorator>();
    private int expireSeconds = 30 * 60;

    public static MultiLock getInstance() {
        return ourInstance;
    }

    private MultiLock() {
    }

    /**
     * This method attempts to acquire locks on multiple objects. It succeeds only if none
     * of the objects (where equals is true) are already locked.
     *
     * @param newLocks
     * @return null if all locks were acquired, or the first object that was already locked
     */
    public Object lock(Set newLocks) {
        synchronized (locks) {
            Date expires = new Date(System.currentTimeMillis() + (expireSeconds * 1000));
            Date now = new Date();
            for (Object newLock : newLocks) {
                ExpirationDecorator expirationDecorator = new ExpirationDecorator(expires, newLock);
                MultiLock.ExpirationDecorator previousLock = locks.get(expirationDecorator);
                // If the lock was already there
                if (previousLock != null) {
                    // If the lock has expired
                    if (now.after(previousLock.getExpires())) {
                        // Remove the expired lock
                        locks.remove(previousLock);
                    } else {
                        // Return the non-expired lock
                        return previousLock.getObject();
                    }
                }
            }
            for (Object newLock : newLocks) {
                ExpirationDecorator expirationDecorator = new ExpirationDecorator(expires, newLock);
                locks.put(expirationDecorator, expirationDecorator);
            }
        }
        return null;
    }

    /**
     * This method releases locks previously acquired with the lock method.
     *
     * @param removeLocks
     */
    public void unlock(Set removeLocks) {
        synchronized (locks) {
            Date now = new Date();
            for (Object o : removeLocks) {
                locks.remove(new ExpirationDecorator(now, o));
            }
        }
    }

    /**
     * This method removes expired locks. It is intended to be called from a timer thread,
     * or from an ejbTimeout method.
     */
    public void removeExpired() {
        Date now = new Date();
        ArrayList<ExpirationDecorator> expiredList = new ArrayList<ExpirationDecorator>();
        synchronized (locks) {
            for (ExpirationDecorator expirationDecorator : locks.keySet()) {
                if (now.after(expirationDecorator.getExpires())) {
                    expiredList.add(expirationDecorator);
                }
            }
            for (ExpirationDecorator expirationDecorator : expiredList) {
                locks.remove(expirationDecorator);
            }
        }
    }

    public int getExpireSeconds() {
        return expireSeconds;
    }

    public void setExpireSeconds(int expireSecondsParam) {
        expireSeconds = expireSecondsParam;
    }

    /**
     * This class wraps the lock objects and adds the ability to expire them if the client
     * doesn't release them within a reasonable time.
     */
    private class ExpirationDecorator {
        Date expires;
        Object object;

        public ExpirationDecorator(Date expires, Object object) {
            this.expires = expires;
            this.object = object;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            final ExpirationDecorator that = (ExpirationDecorator) o;

            return object.equals(that.object);
        }

        @Override
        public int hashCode() {
            return object.hashCode();
        }

        public Date getExpires() {
            return expires;
        }

        public Object getObject() {
            return object;
        }
    }
}
