create sequence seq_pattren1 ;
create or replace trigger pattren1_key before insert on pattern1 
for each row
begin
	select seq_pattren1.nextval into :new.pattern_key from dual ;
end ;
/
