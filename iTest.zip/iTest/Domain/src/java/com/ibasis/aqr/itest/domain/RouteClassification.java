package com.ibasis.aqr.itest.domain;

public class RouteClassification {
    private long routeClassificationId;
    private String description;
    private long slbr;
    private boolean allowPvTesting = false;
    private boolean allowCvTesting = false;
    private boolean requirePvBlock = false;
    private boolean requireCvBlock = false;

    public RouteClassification(long routeClassificationId, String description, long slbr) {
        this.routeClassificationId = routeClassificationId;
        this.description = description;
        this.slbr = slbr;
    }

    public long getRouteClassificationId() {
        return routeClassificationId;
    }

    public void setRouteClassificationId(long routeClassificationId) {
        this.routeClassificationId = routeClassificationId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getSlbr() {
        return slbr;
    }

    public void setSLBR(long slbr) {
        this.slbr = slbr;
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof RouteClassification)) {
            return false;
        }
        RouteClassification castOther = (RouteClassification) other;
        return getRouteClassificationId() == castOther.getRouteClassificationId();
    }

    @Override
    public int hashCode() {
        return Long.valueOf(routeClassificationId).hashCode();
    }

    @Override
    public String toString() {
        return "{id:" + getRouteClassificationId() + ",SRC:" + getDescription() + ",SLBR:" + getSlbr() + ",PV Test:" + isAllowPvTesting() + ",CV Test:" + isAllowCvTesting() + "}";
    }

    public boolean isAllowPvTesting() {
        return allowPvTesting;
    }

    public void setAllowPvTesting(boolean allowPvTesting) {
        this.allowPvTesting = allowPvTesting;
    }

    public boolean isAllowCvTesting() {
        return allowCvTesting;
    }

    public void setAllowCvTesting(boolean allowCvTesting) {
        this.allowCvTesting = allowCvTesting;
    }

    public boolean isRequirePvBlock() {
        return requirePvBlock;
    }

    public void setRequirePvBlock(boolean requirePvBlock) {
        this.requirePvBlock = requirePvBlock;
    }

    public boolean isRequireCvBlock() {
        return requireCvBlock;
    }

    public void setRequireCvBlock(boolean requireCvBlock) {
        this.requireCvBlock = requireCvBlock;
    }

}
