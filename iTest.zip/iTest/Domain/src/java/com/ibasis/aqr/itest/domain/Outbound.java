/*
 * Created on Jun 17, 2005
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibasis.aqr.itest.domain;

/**
 * @author csib
 *
 *         Domain class representing Outbound trunkgroup in AQR
 */
public class Outbound implements Comparable {
    private Long csKey; //carrier site key in AQR
    private boolean inSvc; //Is outbound in service
    private Provider provider; //Provider the outbound belongs to

    /**
     * Constructor
     *
     * @param key carrier site key
     * @param b is in service
     * @param prov provider
     */
    public Outbound(long key, boolean b, Provider prov) {
        csKey = new Long(key);
        inSvc = b;
        this.provider = prov;
    }

    /**
     * @return Returns the csKey.
     */
    public Long getCsKey() {
        return csKey;
    }

    /**
     * @param csKey The csKey to set.
     */
    public void setCsKey(long csKey) {
        this.csKey = new Long(csKey);
    }

    /**
     * @return Returns the inSvc.
     */
    public boolean isInSvc() {
        return inSvc;
    }

    /**
     * @param inSvc The inSvc to set.
     */
    public void setInSvc(boolean inSvc) {
        this.inSvc = inSvc;
    }

    @Override
    public int compareTo(Object o) {
        if (!(o instanceof Outbound)) {
            throw new ClassCastException();
        }
        return compareTo((Outbound) o);
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Outbound)) {
            throw new ClassCastException();
        }
        return equals((Outbound) o);
    }

    public boolean equals(Outbound ob) {
        return csKey.equals(ob.csKey);
    }

    @Override
    public int hashCode() {
        return csKey.hashCode();
    }

    public int compareTo(Outbound ob) {
        int retVal = 0;
        if (inSvc && !ob.inSvc) {
            retVal = -1;
        } else if (!inSvc && ob.inSvc) {
            retVal = 1;
        } else {
            retVal = csKey.compareTo(ob.csKey);
        }

        return retVal;
    }

    /**
     * @return Returns the provider.
     */
    public Provider getProvider() {
        return provider;
    }

    /**
     * @param provider The provider to set.
     */
    public void setProvider(Provider provider) {
        this.provider = provider;
    }
}
