/*
	--Author: Madhavi Kanugo
	--Description: Populating percent variance table.
	--Below rules appy.
*/
PROMPT "Sunday -9%"
PROMPT "Monday 10%"
PROMPT "Tuesday 4%"
PROMPT "Wednesday 1%"
PROMPT "Thursday 1%"
PROMPT "Friday 1%"
PROMPT "Saturday -8%"

INSERT INTO PERCENT_VARIANCE(DAY_NUMBER,DAY,DOW_VARIANCE) values (1, 'Sunday','-9');
INSERT INTO PERCENT_VARIANCE(DAY_NUMBER,DAY,DOW_VARIANCE) values (2, 'Monday','10');
INSERT INTO PERCENT_VARIANCE(DAY_NUMBER,DAY,DOW_VARIANCE) values (3, 'Tuesday','4');
INSERT INTO PERCENT_VARIANCE(DAY_NUMBER,DAY,DOW_VARIANCE) values (4, 'Wednesday','1');
INSERT INTO PERCENT_VARIANCE(DAY_NUMBER,DAY,DOW_VARIANCE) values (5, 'Thursday','1');
INSERT INTO PERCENT_VARIANCE(DAY_NUMBER,DAY,DOW_VARIANCE) values (6, 'Friday','1');
INSERT INTO PERCENT_VARIANCE(DAY_NUMBER,DAY,DOW_VARIANCE) values (7, 'Saturday','-8');