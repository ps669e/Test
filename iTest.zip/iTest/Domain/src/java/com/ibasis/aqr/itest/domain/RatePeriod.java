package com.ibasis.aqr.itest.domain;

public class RatePeriod {
    private int periodId;
    private String periodCode;
    private String description;

    public RatePeriod(int ratePeriodId, String periodCode, String desc) {
        this.periodId = ratePeriodId;
        this.periodCode = periodCode;
        this.description = desc;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPeriodCode() {
        return periodCode;
    }

    public void setPeriodCode(String periodCode) {
        this.periodCode = periodCode;
    }

    public int getPeriodId() {
        return periodId;
    }

    public void setPeriodId(int periodId) {
        this.periodId = periodId;
    }

    @Override
    public String toString() {
        return "{id:" + getPeriodId() + ",code:" + getPeriodCode() + ",desc:" + getDescription() + "}";
    }
}
