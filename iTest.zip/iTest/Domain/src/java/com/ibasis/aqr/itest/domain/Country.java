/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.dpmanager.DialPatternMgr;
import com.ibasis.aqr.itest.tree.NodeNavigator;
import com.ibasis.aqr.itest.tree.TenaryTreeNode;

/**
 * Domain class representing a Country
 *
 * @author schan
 *
 */
public class Country {

    private static final Log logger = LogFactory.getLog(Country.class);
    private long countryId; //ID of the country from database COUNTRY.COUNTRY_ID
    private String name; //name of the COUNTRY
    private String countryCode; //country code
    private Map rootNodes = null; //All root nodes of this country for traversing pattern tree

    private Collection<DialPattern> patterns = null; //All dial patterns in the country

    private Map<Long, PreferredRoute> preferredRoutes; //All preferred routes in country

    private DialPatternMgr dialPatternMgr = null; // DialPatternMgr to manage patterns in memory

    private boolean missingFloor = false; //Whether country has missing floor detected

    private boolean excluded = false; //Whether country is excluded from iTest processing

    private boolean overlapping = false; //Is country overlapping - e.g. Kazakhstan overlaps with Russia
    //When a country is set as overlapping it means the countries
    //that overlap it are elligible to inherit codes and attributes
    //from it.

    private int gcsInstance = -1;
    private boolean gcsEnabled = false;
    private boolean itestEnabled = false;

    /**
     * Default Constructor
     */
    public Country() {
    }

    /**
     * Constructor
     *
     * @param inCountryKey country_id
     * @param inName country name
     * @param countryCode country code
     * @param source source of data (RMS. AQR)
     */
    public Country(long inCountryKey, String inName, String countryCode) {
        this.countryId = inCountryKey;
        this.name = inName;
        this.countryCode = countryCode;
    }

    public long getCountryId() {
        return countryId;
    }

    public void setCountryId(long countryId) {
        this.countryId = countryId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String inName) {
        this.name = inName;
    }

    public String getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Collection<PreferredRoute> getPreferredRoutes() {
        if (this.preferredRoutes != null) {
            return preferredRoutes.values();
        }
        return null;
    }

    public void addPreferredRoute(PreferredRoute preferredRoute) {
        if (preferredRoute != null) {
            if (this.preferredRoutes == null) {
                this.preferredRoutes = new HashMap<>();
            }
            this.preferredRoutes.put(preferredRoute.getPreferredRouteId(), preferredRoute);
        }
    }

    public void removePreferredRoute(PreferredRoute preferredRoute) {
        this.preferredRoutes.remove(preferredRoute.getPreferredRouteId());
    }

    /**
     * Delegates recording of a dial pattern to dialPatternMgr
     *
     * @param dpStr the pattern
     * @return DialPattern instance
     * @throws Exception
     */
    public DialPattern recordDialPattern(String dpStr) throws Exception {
        if (dialPatternMgr != null) {
            return dialPatternMgr.recordDialPattern(dpStr, this);
        }
        return null;
    }

    /**
     * Delegates finding of a dial pattern to dialPatternMgr
     *
     * @param dpStr the pattern
     * @return DialPattern instance
     * @throws Exception
     */
    public DialPattern findPattern(String dpStr) {
        if (dialPatternMgr != null) {
            return dialPatternMgr.findPattern(dpStr);
        }
        return null;
    }

    /**
     * Allows the navigator to traverse down the country hierarchy
     * and use the data in tree to run navigator specific logic.
     *
     * Note - the method should be given a generic name as it is
     * reusable by any navigator.
     *
     * @param navigator node navigator
     */
    public void navigateCountry(NodeNavigator navigator) {
        if (this.rootNodes != null) {
            Iterator it = this.rootNodes.values().iterator();
            while (it.hasNext()) {
                TenaryTreeNode root = (TenaryTreeNode) it.next();
                root.navigateNode(navigator);
            }
        }
    }

    public Collection getRootNodes() {
        return rootNodes.values();
    }

    public void setRootNodes(Map rootNodes) {
        this.rootNodes = rootNodes;
    }

    public void addRootNode(TenaryTreeNode node) {
        if (this.rootNodes == null) {
            this.rootNodes = new HashMap();
        }
        this.rootNodes.put(new Integer(node.getDigit()), node);
    }

    public boolean containsRootNode(TenaryTreeNode node) {
        if (this.rootNodes != null) {
            return (this.rootNodes.get(new Integer(node.getDigit())) != null);
        }

        return false;
    }

    public void setPreferredRoutes(Map preferredRoutes) {
        this.preferredRoutes = preferredRoutes;
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof Country)) {
            return false;
        }
        Country castOther = (Country) other;
        return this.getCountryId() == castOther.getCountryId();
    }

    public boolean equals(Country other) {
        return this.getCountryId() == other.getCountryId();
    }

    @Override
    public int hashCode() {
        return Long.valueOf(countryId).hashCode();
    }

    public DialPatternMgr getDialPatternMgr() {
        return this.dialPatternMgr;
    }

    public void setDialPatternMgr(DialPatternMgr dpMgr) {
        this.dialPatternMgr = dpMgr;
    }

    /**
     * @return Returns the missingFloor.
     */
    public boolean isMissingFloor() {
        return missingFloor;
    }

    /**
     * @param missingFloor The missingFloor to set.
     */
    public void setMissingFloor(boolean missingFloor) {
        this.missingFloor = missingFloor;
    }

    /**
     * @return Returns the excluded.
     */
    public boolean isExcluded() {
        return excluded;
    }

    /**
     * @param excluded The excluded to set.
     */
    public void setExcluded(boolean excluded) {
        this.excluded = excluded;
    }

    /**
     * @return Returns the isOverlapping.
     */
    public boolean isOverlapping() {
        return overlapping;
    }

    /**
     * @param isOverlapping The isOverlapping to set.
     */
    public void setOverlapping(boolean overlapping) {
        this.overlapping = overlapping;
    }

    /**
     * clear memory for this country.
     *
     */
    public void clearData() {
        if (preferredRoutes != null && !preferredRoutes.isEmpty()) {
            Iterator<PreferredRoute> pfit = preferredRoutes.values().iterator();
            while (pfit.hasNext()) {
                PreferredRoute pf = pfit.next();
                Collection<DialPattern> dps = pf.getDialPatterns();
                if (dps != null) {
                    Iterator<DialPattern> dpit = dps.iterator();
                    while (dpit.hasNext()) {
                        DialPattern dp = dpit.next();
                        dp.clearCvgData();
                    }
                }
                pf.clearData();
            }
            preferredRoutes = null;
        }
    }

    public void addPattern(DialPattern p) {
        if (patterns == null) {
            patterns = new ArrayList<>();
        }
        patterns.add(p);
    }

    public Collection<DialPattern> getPatterns() {
        return patterns;
    }

    @Override
    public String toString() {
        return "{id:" + getCountryId() + ",code:" + getCountryCode() + ",name:" + getName() + ",gcsEnabled:" + gcsEnabled + ",itestEnabled:" + itestEnabled + (isOverlapping() ? ",overlapping}" : "}");
    }

    public int getGcsInstance() {
        return gcsInstance;
    }

    public void setGcsInstance(int gcsInstance) {
        this.gcsInstance = gcsInstance;
    }

    public boolean isGcsEnabled() {
        return gcsEnabled;
    }

    public void setGcsEnabled(boolean gcsEnabled) {
        this.gcsEnabled = gcsEnabled;
    }

    public boolean isItestEnabled() {
        return itestEnabled;
    }

    public void setItestEnabled(boolean itestEnabled) {
        this.itestEnabled = itestEnabled;
    }
}
