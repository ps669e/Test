package com.ibasis.aqr.itest;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.datamanager.iTestDataManager;

public class ShutdownGuard extends Thread {

    private static Log log = LogFactory.getLog(ShutdownGuard.class);

    private class ConnectionWrapper {
        Connection connection;
        String sqlBeforeDisconnect;

        ConnectionWrapper(Connection c, String sql) {
            connection = c;
            sqlBeforeDisconnect = sql;
        }

        void disconnect() {
            try {
                if (!connection.isClosed()) {

                    log.info("Rolling back connection");
                    connection.rollback();
                    log.info("Done");

                    if (sqlBeforeDisconnect != null) {
                        Statement stm = null;
                        try {
                            stm = connection.createStatement();
                            stm.execute(sqlBeforeDisconnect);
                        } catch (SQLException e) {
                            log.error("Shutdown hook encountered SQL exception", e);
                        } catch (Exception e) {
                            log.error("Shutdown hook encountered exception", e);
                        } finally {
                            if (stm != null) {
                                stm.close();
                                stm = null;
                            }
                        }

                    }

                    log.info("Closing connection");
                    connection.close();
                    log.info("Done");
                }
            } catch (SQLException e) {
                log.error("Shutdown hook encountered SQL exception", e);
            }
        }
    }

    private Vector conList = new Vector();

    private iTestDataManager dataManager;

    public void setDataManager(iTestDataManager dataManager) {
        this.dataManager = dataManager;
    }

    public void addConnection(Connection con, String sql) {
        conList.add(new ConnectionWrapper(con, sql));
    }

    public void addConnection(Connection con) {
        addConnection(con, null);
    }

    @Override
    public void run() {
        log.debug("Shutdown hook invoked.");
        try {
            Iterator coniter = conList.iterator();
            while (coniter.hasNext()) {
                ConnectionWrapper con = (ConnectionWrapper) coniter.next();
                con.disconnect();
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            log.error("Shutdown hook encountered error", e);
        }
    }

}
