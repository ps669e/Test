/*
 * Created on Oct 6, 2004
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.ibasis.aqr.itest.util;

import java.util.Comparator;
import java.util.List;

/**
 * @author csib
 *
 *         To change the template for this generated type comment go to
 *         Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ListUtils {

    /*
     * intersectionSort
     * Simple intersection of two collections. Only works if sorted by the given comparator.
     */
    public static void intersectionSort(final List a, final List b, Comparator cmp, Operator intsctOperator, List result) throws Exception {

        int ai = 0, bi = 0, aSize = 0, bSize = 0;
        if (a != null) {
            aSize = a.size();
        }
        if (b != null) {
            bSize = b.size();
        }
        while (ai != aSize && bi != bSize) {
            Object aObj = a.get(ai);
            Object bObj = b.get(bi);
            int res = cmp.compare(aObj, bObj);
            if (res == 0) {
                Object obj = aObj;
                if (intsctOperator != null) {
                    obj = intsctOperator.operate(aObj, bObj);
                }
                if (obj != null) {
                    result.add(obj);
                }
                ai++;
                bi++;
            } else if (res < 0) {
                ai++;
            } else {
                bi++;
            }
        }
    }

    /*
     * Simple merge sort. Only works if sorted by the given comparator.
     */
    public static void mergeSort(final List a, final List b, Comparator cmp, List result) throws Exception {
        mergeSort(a, b, cmp, result, null, null, null);
    }

    /*
     * Special mergeSort for specialized coverage merge need. Only works if sorted by the given comparator.
     */
    public static void mergeSort(final List a, final List b, Comparator cmp, List result, Operator equalsOperator, Operator aOperator, Operator bOperator)
            throws Exception {

        int ai = 0, bi = 0, aSize = 0, bSize = 0;
        if (a != null) {
            aSize = a.size();
        }
        if (b != null) {
            bSize = b.size();
        }
        while (ai != aSize && bi != bSize) {
            Object aObj = a.get(ai);
            Object bObj = b.get(bi);
            int res = cmp.compare(aObj, bObj);
            if (res == 0) {
                Object obj = aObj;
                if (equalsOperator != null) {
                    obj = equalsOperator.operate(aObj, bObj);
                }
                if (obj != null) {
                    result.add(obj);
                }
                ai++;
                bi++;
            } else if (res < 0) {
                if (aOperator != null) {
                    aObj = aOperator.operate(aObj);
                }
                if (aObj != null) {
                    result.add(aObj);
                }
                ai++;
            } else {
                if (bOperator != null) {
                    bObj = bOperator.operate(bObj);
                }
                if (bObj != null) {
                    result.add(bObj);
                }
                bi++;
            }
        }
        while (ai != aSize) {
            Object aObj = a.get(ai);
            if (aOperator != null) {
                aObj = aOperator.operate(aObj);
            }
            if (aObj != null) {
                result.add(aObj);
            }
            ai++;
        }
        while (bi != bSize) {
            Object bObj = b.get(bi);
            if (bOperator != null) {
                bObj = bOperator.operate(bObj);
            }
            if (bObj != null) {
                result.add(bObj);
            }
            bi++;
        }
    }

    public interface Operator {
        Object operate(Object a, Object b) throws Exception;
        Object operate(Object obj) throws Exception;
    }
}
