package com.ibasis.aqr.itest.test;

import java.util.Collection;

import com.ibasis.aqr.itest.domain.PreferredRoute;
import com.ibasis.aqr.itest.domain.TimeOfDay;

public class PreferredRouteTest extends iRouteTestBase {
    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    /**
     * P 07:00:00 18:00:00 n
     */
    public void testGetPeriodsForLineup_P_Only() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", "18:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", "18:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P xxx xxx n
     */
    public void testGetPeriodsForLineup_P_NullStartNullEnd() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P 07:00:00 xxx n
     */
    public void testGetPeriodsForLineup_P_NullEnd() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", null, NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", null, NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P xxx 07:00:00 n
     */
    public void testGetPeriodsForLineup_P_NullStart() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, "07:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, "07:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P 07:00:00 18:00:00 y
     * O 18:00:00 07:00:00
     */
    public void testGetPeriodsForLineup_PO_Normal() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", "18:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "18:00:00", "07:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 2);
        assertTrue(tods.contains(new TimeOfDay(P, "07:00:00", "18:00:00", NULL_VALUE, NULL_VALUE)));
        assertTrue(tods.contains(new TimeOfDay(O, "18:00:00", "07:00:00", NULL_VALUE, NULL_VALUE)));
        assertTrue(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", "18:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "18:00:00", "07:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P 00:00:00 23:59:59 n
     * O 23:59:59 00:00:00
     */
    public void testGetPeriodsForLineup_PO_P000000_235959_O235959_000000() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P xxx 23:59:59 n
     * O 23:59:59 00:00:00
     */
    public void testGetPeriodsForLineup_PO_PNullStart() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, "23:59:59", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, "23:59:59", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P 00:00:00 xxx n
     * O 23:59:59 00:00:00
     */
    public void testGetPeriodsForLineup_PO_PNullEnd() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "00:00:00", null, NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "00:00:00", null, NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P 07:00:00 14:00:00 n peak and off peak do not cover 24-hr is considered non-tod
     * O 18:00:00 07:00:00
     */
    public void testGetPeriodsForLineup_PO_Not24Hr() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", "14:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "18:00:00", "07:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", "14:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "18:00:00", "07:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P xxx xxx y weekend & weekday
     * W F18:00:00 M07:00:00 weekend is the only record
     */
    public void testGetPeriodsForLineup_PW_PNullStartNullEnd() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 2);
        assertTrue(tods.contains(new TimeOfDay(D, "07:00:00", "18:00:00", 1, 5)));
        assertTrue(tods.contains(new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1)));
        assertTrue(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P 07:00:00 xxx y weekend & weekday
     * W F18:00:00 M07:00:00 weekend is the only record
     */
    public void testGetPeriodsForLineup_PW_PNullEnd() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", null, NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 2);
        assertTrue(tods.contains(new TimeOfDay(D, "07:00:00", "18:00:00", 1, 5)));
        assertTrue(tods.contains(new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1)));
        assertTrue(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", null, NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P xxx 18:00:00 y weekend & weekday
     * W F18:00:00 M07:00:00 weekend is the only record
     */
    public void testGetPeriodsForLineup_PW_PNullStart() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, "18:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 2);
        assertTrue(tods.contains(new TimeOfDay(D, "07:00:00", "18:00:00", 1, 5)));
        assertTrue(tods.contains(new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1)));
        assertTrue(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, "18:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P 07:00:00 18:00:00 y
     * O 18:00:00 07:00:00
     * W F18:00:00 M07:00:00
     */
    public void testGetPeriodsForLineup_POW_Normal() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", "18:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "18:00:00", "07:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 3);
        assertTrue(tods.contains(new TimeOfDay(P, "07:00:00", "18:00:00", NULL_VALUE, NULL_VALUE)));
        assertTrue(tods.contains(new TimeOfDay(O, "18:00:00", "07:00:00", NULL_VALUE, NULL_VALUE)));
        assertTrue(tods.contains(new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1)));
        assertTrue(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", "18:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "18:00:00", "07:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P 00:00:00 23:59:59 y weekend & weekday
     * O 23:59:59 00:00:00
     * W F18:00:00 M07:00:00
     */
    public void testGetPeriodsForLineup_POW_WeekendOnly() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 2);
        assertTrue(tods.contains(new TimeOfDay(D, "07:00:00", "18:00:00", 1, 5)));
        assertTrue(tods.contains(new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1)));
        assertTrue(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "00:00:00", "23:59:59", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * W F18:00:00 M07:00:00 y weekend & weekday
     * Note: this case is not valid because Peak must exist
     */
    public void testGetPeriodsForLineup_W_Only() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 2);
        assertTrue(tods.contains(new TimeOfDay(D, "07:00:00", "18:00:00", 1, 5)));
        assertTrue(tods.contains(new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1)));
        assertTrue(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P 07:00:00 14:00:00 y weekend & weekday
     * O 18:00:00 07:00:00 peak and off peak do not cover 24-hr will be ignored
     * W F18:00:00 M07:00:00
     */
    public void testGetPeriodsForLineup_POW_PONot24Hr() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", "14:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "18:00:00", "07:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 2);
        assertTrue(tods.contains(new TimeOfDay(D, "07:00:00", "18:00:00", 1, 5)));
        assertTrue(tods.contains(new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1)));
        assertTrue(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "07:00:00", "14:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "18:00:00", "07:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P xxx xxx y weekend & weekday
     * O 23:59:59 00:00:00 off peak will be ignored
     * W F18:00:00 M07:00:00
     * Note: this case is not valid since Peak must exist
     */
    public void testGetPeriodsForLineup_POW_PNullStartNullEnd() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 2);
        assertTrue(tods.contains(new TimeOfDay(D, "07:00:00", "18:00:00", 1, 5)));
        assertTrue(tods.contains(new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1)));
        assertTrue(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P 00:00:00 xxx y weekend & weekday
     * O 23:59:59 00:00:00 off peak will be ignored
     * W F18:00:00 M07:00:00
     */
    public void testGetPeriodsForLineup_POW_PNullEnd() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "00:00:00", null, NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 2);
        assertTrue(tods.contains(new TimeOfDay(D, "07:00:00", "18:00:00", 1, 5)));
        assertTrue(tods.contains(new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1)));
        assertTrue(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, "00:00:00", null, NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

    /**
     * P xxx 00:00:00 y weekend & weekday
     * O 23:59:59 00:00:00 off peak will be ignored
     * W F18:00:00 M07:00:00
     */
    public void testGetPeriodsForLineup_POW_PNullStart() {
        Collection<TimeOfDay> tods = null;
        PreferredRoute prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(true);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 2);
        assertTrue(tods.contains(new TimeOfDay(D, "07:00:00", "18:00:00", 1, 5)));
        assertTrue(tods.contains(new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1)));
        assertTrue(prefRoute.isTod());

        // tod off
        prefRoute = new PreferredRoute();
        prefRoute.addTimeofDayByPeriodId(P, new TimeOfDay(P, null, "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(O, new TimeOfDay(O, "23:59:59", "00:00:00", NULL_VALUE, NULL_VALUE));
        prefRoute.addTimeofDayByPeriodId(W, new TimeOfDay(W, "18:00:00", "07:00:00", 5, 1));
        prefRoute.setTodEnabled(false);
        tods = prefRoute.getPeriodsForLineup();
        assertTrue(tods.size() == 1);
        assertTrue(tods.contains(new TimeOfDay(P, null, null, NULL_VALUE, NULL_VALUE)));
        assertFalse(prefRoute.isTod());
    }

}
