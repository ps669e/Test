package com.ibasis.aqr.itest.domain.comparator;

import java.util.Comparator;

import com.ibasis.aqr.itest.domain.ProviderCoverage;

/*
 * Created on April, 2018
 *
 * @author schan
 *
 */
public class PatternRCComparator implements Comparator<ProviderCoverage> {
    @Override
    public int compare(ProviderCoverage choice1, ProviderCoverage choice2) {
        return (int) (choice1.getProvider().getVendorId() - choice2.getProvider().getVendorId());
    }
}
