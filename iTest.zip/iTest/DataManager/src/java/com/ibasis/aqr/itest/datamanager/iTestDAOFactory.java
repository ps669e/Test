/*
 * Created on Oct 18, 2004
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.ibasis.aqr.itest.datamanager;

/**
 * @author Administrator
 *
 *         To change the template for this generated type comment go to Window -
 *         Preferences - Java - Code Generation - Code and Comments
 */
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.datamanager.impl.RMSDAOImpl;
import com.ibasis.aqr.itest.datamanager.intf.RMSDAO;
import com.ibasis.aqr.itest.db.DBConnection;

public class iTestDAOFactory {

    private static final Log logger = LogFactory.getLog(iTestDAOFactory.class);

    public static final DBConnection DB_CONNECTION = new DBConnection();

    public static RMSDAO getRMSDAO() {
        return new RMSDAOImpl(DB_CONNECTION);
    }

}