prompt "loading into default values"

insert into default_values(value_name,value,description) values ('DEFAULT_TEST_CALL_LIMIT',150,null);
insert into default_values(value_name,value,description) values ('DEFAULT_PREMIUM_CERTIFIED_MAX_VENDORS_TEST',1,null);
insert into default_values(value_name,value,description) values ('DEFAULT_PREMIUM_CERTIFIED_MIN_OFFERS_TEST',50,null);
