/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.domain;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.tree.TenaryTreeNode;

/**
 *
 * Domain class representing a Dial Pattern
 *
 * @author schan
 */
public class DialPattern implements Comparable<DialPattern> {

    private static final Log logger = LogFactory.getLog(DialPattern.class);

    /**
     * Compares 2 dial patterns
     */
    public static Comparator<DialPattern> dpComparator = new Comparator<DialPattern>() {
        @Override
        public int compare(DialPattern first, DialPattern second) {
            return first.compareTo(second);
        }
    };

    private long dialPatternKey = DomainConstants.NULL_LONG_VALUE;

    //The pattern
    private String pattern;

    private boolean isPRPattern = false; //is preferred route pattern?

    private TenaryTreeNode dpNode = null; //Node in the tree it's hanging from

    private boolean isProper = false; //Is proper pattern

    // All provider coverage (merged with parent dp's patternRoutingChoices) that have a status code and rate.
    // Populated by PRCMerger.determineCoverage
    private List<ProviderCoverage> patternRoutingChoices = null;

    private Map<Provider, ProviderCoverage> providerCoverages = null; // direct provider coverage loaded from RMS

    private Map<Long, Map<Integer, ProviderRate>> providerRates = null; // Map<vendorId, Map<periodId, ProviderRate>>

    private PreferredRoute preferredRoute; //preferred route pattern belongs to

    private long routeID = -1; //unique key for pattern in RMS

    private boolean newInRMS = true; //Dial pattern new in RMS

    private Map<Product, Map<Integer, FloorRate>> pendingActiveFloors = null;

    /*
     * Default constructor
     */
    public DialPattern() {

    }

    /**
     * Constructor
     *
     * @param inPattern
     */
    public DialPattern(String inPattern) {
        setPattern(inPattern);
    }

    public long getDialPatternKey() {
        return this.dialPatternKey;
    }

    public void setDialPatternKey(long inDialPatternKey) {
        this.dialPatternKey = inDialPatternKey;
    }

    public String getPattern() {
        return this.pattern;
    }

    public void setPattern(String inPattern) {
        this.pattern = inPattern;
    }

    public boolean getIsPRPattern() {
        return this.isPRPattern;
    }

    public void setIsPRPattern(boolean isPRPattern) {
        this.isPRPattern = isPRPattern;
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof DialPattern)) {
            return false;
        }
        DialPattern castOther = (DialPattern) other;
        return this.equals(castOther);
    }

    /**
     * compares routeID if set - otherwise compares the pattern string
     *
     * @param other DialPattern
     * @return
     */
    public boolean equals(DialPattern other) {
        if (this.routeID != -1 && other.routeID != -1) {
            return this.routeID == other.routeID;
        } else {
            return this.getPattern().equals(other.getPattern());
        }
    }

    @Override
    public int hashCode() {
        if (this.routeID != -1) {
            return Long.valueOf(routeID).hashCode();
        }
        return pattern.hashCode();
    }

    public TenaryTreeNode getNode() {
        return this.dpNode;
    }

    public void setNode(TenaryTreeNode inNode) {
        this.dpNode = inNode;
    }

    /**
     *
     * @param origCtry
     * @return
     */
    public DialPattern getParent(Country origCtry) {
        DialPattern parentDP = null;
        TenaryTreeNode node = this.dpNode;
        //Loop through traversing up the tree until you find a parent
        //node within same country (or overlapping country) that has a DialPattern.
        while (node != null) {
            parentDP = (DialPattern) node.getParentNodeObject();
            if (parentDP != null) {
                Country parCtry = parentDP.getCountry();
                if (parCtry == origCtry || parCtry.isOverlapping()) {
                    break;
                } else {
                    node = parentDP.getNode();
                }
            } else {
                //Parent dial pattern found
                break;
            }
        }

        return parentDP;
    }

    /**
     * Whether thid dial pattern has children dial patterns
     *
     * @return true or false
     */
    public boolean hasChildren() {
        //This dial pattern has children if it's node is not a leaf node
        return !this.dpNode.isLeaf();
    }

    public List<ProviderCoverage> getPatternRoutingChoices() {
        return this.patternRoutingChoices;
    }

    public boolean isBlacklistVendor(Provider provider) {
        return getPreferredRoute().isBlacklistVendor(provider);
    }

    /**
     * Sets all coverages that have valid status codes and rates
     *
     * @param patternRoutingChoices all coverages with valid status code and rate
     */
    public void setPatternRoutingChoices(List<ProviderCoverage> patternRoutingChoices) {
        this.patternRoutingChoices = patternRoutingChoices;
    }

    /**
     * Looks for own rates first. if none found recursively looks for nearest parent's rates.
     *
     * @return all provider rates
     */
    public Collection<Map<Integer, ProviderRate>> getProviderRates() {
        Collection<Map<Integer, ProviderRate>> rates = null;
        if (providerRates != null) {
            return providerRates.values();
        } else {
            Country ctry = this.getCountry();
            DialPattern parent = this.getParent(ctry);
            while (parent != null) { //Loop until we find a parent with rates
                rates = parent.getProviderRates(); //recursive call
                if (rates != null && !rates.isEmpty()) {
                    break;
                }
                parent = parent.getParent(ctry);
            }
        }
        return rates;
    }

    /**
     * Looks for own rates for provider. If not found recursively looks for nearest parent's rates
     * for provider
     *
     * @param provider
     * @return Collection&lt;ProviderRate&gt; - rates for the specific provider
     */
    public Map<Integer, ProviderRate> getProviderRates(Provider provider) {
        Map<Integer, ProviderRate> rates = null;
        if (this.providerRates != null) {
            rates = this.providerRates.get(provider.getVendorId());
        }
        if (rates == null) { // If still null look up nearest parent for a rate for this provider
            Country ctry = getCountry();
            DialPattern parent = this.getParent(ctry);
            while (parent != null) {
                rates = parent.getProviderRates(provider); // recursive call
                if (rates != null && !rates.isEmpty()) {
                    break;
                }
                parent = parent.getParent(ctry);
            }
        }

        return rates;
    }

    public boolean getIsProper() {
        return isProper;
    }

    public void setIsProper(boolean isProper) {
        this.isProper = isProper;
    }

    public Collection<ProviderCoverage> getProviderCoverages() {
        if (providerCoverages != null) {
            return providerCoverages.values();
        }
        return null;
    }

    public Country getCountry() {
        return getPreferredRoute().getCountry();
    }

    public PreferredRoute getPreferredRoute() {
        return preferredRoute;
    }

    public void setPreferredRoute(PreferredRoute preferredRoute) {
        this.preferredRoute = preferredRoute;
    }

    public long getRouteID() {
        return routeID;
    }

    public void setRouteID(long routeID) {
        this.routeID = routeID;
    }

    /**
     * Rates are maintained as Map&lt;colo, Map&lt;periodId, ProviderRate&gt;&gt;
     *
     * @param rate
     */
    public void addProviderRate(ProviderRate rate) {
        Map<Integer, ProviderRate> rates;
        if (this.providerRates == null) {
            this.providerRates = new HashMap<>();
            rates = new HashMap<>();
        } else {
            rates = this.providerRates.get(rate.getProvider().getVendorId());
            if (rates == null) {
                rates = new HashMap<>();
            }
        }
        rates.put(rate.getTimeOfDay().getPeriodId(), rate);
        this.providerRates.put(rate.getProvider().getVendorId(), rates);
    }

    /**
     *
     * @param coverage
     */
    public void addProviderCoverage(ProviderCoverage coverage) {
        if (this.providerCoverages == null) {
            this.providerCoverages = new HashMap<>();
        }
        this.providerCoverages.put(coverage.getProvider(), coverage);
    }

    /**
     * This returns direct coverage set against pattern and provider
     *
     * @param provider
     * @return ProviderCoverage
     */
    public ProviderCoverage getCoverageByProvider(Provider provider) {
        if (this.providerCoverages != null) {
            return this.providerCoverages.get(provider);
        }

        return null;
    }

    /**
     * This looks for direct ProviderCoverage first. If not found recursivley looks
     * for nearest paren't coverage for given provider.
     * The method is primarily used to inherit coverage where direct coverage
     * does not exist.
     *
     * @param provider
     * @return ProviderCoverage
     */
    public ProviderCoverage findCoverageByProvider(Provider provider) {
        ProviderCoverage cvg = null;
        DialPattern parent = this;
        Country ctry = getCountry();
        while (parent != null) {
            cvg = parent.getCoverageByProvider(provider); //recursive call
            if (cvg != null) {
                break;
            }
            parent = parent.getParent(ctry);
        }

        return cvg;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(DialPattern other) {
        //        if (!(other instanceof DialPattern)) {
        //            throw new ClassCastException();
        //        }
        //        DialPattern castOther = (DialPattern) other;
        //        return this.getPattern().compareTo(castOther.getPattern());
        return this.getPattern().compareTo(other.getPattern());
    }

    /**
     * @return Returns the inRMS.
     */
    public boolean isNewInRMS() {
        return newInRMS;
    }

    /**
     * @param inRMS
     *            The inRMS to set.
     */
    public void setNewInRMS(boolean newInRMS) {
        this.newInRMS = newInRMS;
    }

    /**
     * memory clearance - primarily used to clear memory for next batch
     *
     */
    public void clearCvgData() {
        patternRoutingChoices = null;
        providerCoverages = null;
        providerRates = null;
    }

    @Override
    public String toString() {
        return pattern;
    }

    public boolean isTod() {
        return preferredRoute.isTod();
    }

    public void addFloorRateByProductPeriodId(Product product, int periodId, FloorRate floorRate) {
        if (this.pendingActiveFloors == null) {
            this.pendingActiveFloors = new HashMap<>();
        }
        Map<Integer, FloorRate> todFloors = this.pendingActiveFloors.get(product);
        if (todFloors != null) {
            FloorRate fr = todFloors.get(periodId);
            if (fr != null) {
                logger.error("addFloorRateByProductPeriodId(): Duplicate Floor Rate of period " + periodId + " for product " + product.getDescription());
            } else {
                todFloors.put(periodId, floorRate);
            }
        } else {
            todFloors = new HashMap<>();
            todFloors.put(periodId, floorRate);
            this.pendingActiveFloors.put(product, todFloors);
        }
    }

    //without TOD, assuming peak
    public FloorRate getFloorRateByProduct(Product product) {
        if (product != null) {
            return getFloorRateByProductPeriodId(product, DomainConstants.RMS_PEAK_PERIOD_ID);
        }
        return null;
    }

    public FloorRate getFloorRateByProductPeriodId(Product product, int periodId) {
        FloorRate fr = null;
        if (product != null) {
            if (this.pendingActiveFloors != null) {
                Map<Integer, FloorRate> todFloors = this.pendingActiveFloors.get(product);
                if (todFloors != null) {
                    fr = todFloors.get(periodId);
                }
            }
        }
        return fr;
    }

    public Map<Product, Map<Integer, FloorRate>> getPendingActiveFloorRates() {
        return this.pendingActiveFloors;
    }

    public void setPendingActiveFloorRates(Map<Product, Map<Integer, FloorRate>> floors) {
        this.pendingActiveFloors = floors;
    }

    public void delCoverage(ProviderCoverage coverage) {
        if (this.providerCoverages != null) {
            this.providerCoverages.remove(coverage.getProvider());
        }
    }

    public RouteClassification getRouteClassificationByProvider(Provider provider) {
        RouteClassification rc = null;
        if (preferredRoute != null) {
            rc = preferredRoute.getProviderSrc(provider);
        }
        return rc;
    }

    private RouteClassification getDefaultSRC() {
        return getCountry().getDialPatternMgr().getDefaultSRC();
    }
}
