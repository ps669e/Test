/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.datamanager;

/**
 *
 * @author schan
 */
public class DataManagerConstants {

    public static final int NULL_ID = -999;
    //public static final String PRE_PROCESS_CALL = "{?=call ITEST_DATA_GENERATION.MAIN(?)}";
    public static final String PRE_PROCESS_CALL = "{?=call ITEST_PRE_PROCESS_WRAPPER(?)}";
    public static final String POST_PROCESS_CALL = "{?=call GCS_ITEST_POST_PKG.POST_PV_TEST_MAIN()}";
    public static final String MID_PROCESS_CALL = "{?=call IROUTE_INTF_MID_PROCESS.GEN_MID_PROCESS(?)}";
}
