package com.ibasis.aqr.itest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.Callable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ConsoleInputReadTask implements Callable<String> {
    private static final Log logger = LogFactory.getLog(ConsoleInputReadTask.class);

    @Override
    public String call() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String input;
        do {
            System.out.println("Are you sure the above properties will be disabled for iTest run? Yes to continue, No to exist: ");
            try {
                // wait until we have data to complete a readLine()
                while (!br.ready()) {
                    Thread.sleep(200);
                }
                input = br.readLine();
            } catch (InterruptedException e) {
                logger.info("call() cancelled");
                return null;
            }
        } while ("".equals(input));
        return input;
    }
}
