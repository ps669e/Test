package com.ibasis.aqr.itest;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public interface iWriter {
    Log logger = LogFactory.getLog(iWriter.class);

    void write(String s) throws IOException;

    void close() throws IOException;
}

class ZipWriter implements iWriter {
    private ZipOutputStream out = null;

    ZipWriter(String fileName) throws Exception {
        FileOutputStream dest = new FileOutputStream(fileName + ".zip");
        // CheckedOutputStream checksum = new
        //CheckedOutputStream(dest, new Adler32());
        out = new ZipOutputStream(new BufferedOutputStream(dest));
        //out.setLevel(Deflater.BEST_SPEED);
        ZipEntry entry = new ZipEntry(fileName);
        out.putNextEntry(entry);
        logger.info("ZipWriter(): Writing output to : " + fileName + ".zip");
    }

    @Override
    public void write(String s) throws IOException {
        if (out != null) {

            int len = s.length();
            byte[] bytes = new byte[len];
            //This is deprecated due to problem with UNICODE, but for ASCII - OK
            //Much faster than getBytes() - not really
            s.getBytes(0, len - 1, bytes, 0);
            out.write(bytes);
        }
    }

    @Override
    public void close() throws IOException {
        if (out != null) {
            out.flush();
            out.close();
        }
    }
}

class RegWriter implements iWriter {
    private BufferedWriter out = null;

    RegWriter(String fileName) throws Exception {
        File outFile = new File(fileName);
        if (!outFile.exists()) {
            outFile.createNewFile();
        }
        logger.info("RegWriter(): Writing output to : " + fileName);
        iTestWriter itestWriter = new iTestWriter();
        out = new BufferedWriter(new FileWriter(outFile));
    }

    @Override
    public void write(String s) throws IOException {
        if (out != null) {
            out.write(s);
        }
    }

    @Override
    public void close() throws IOException {
        if (out != null) {
            out.flush();
            out.close();
        }
    }
}
