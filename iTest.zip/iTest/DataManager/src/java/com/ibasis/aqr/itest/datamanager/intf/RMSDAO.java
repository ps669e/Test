/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.datamanager.intf;

/**
 *
 * @author schan
 */
import java.util.Collection;
import java.util.Map;
import java.util.Set;

import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.domain.PreferredRoute;
import com.ibasis.aqr.itest.domain.Product;
import com.ibasis.aqr.itest.domain.Provider;
import com.ibasis.aqr.itest.domain.RatePeriod;
import com.ibasis.aqr.itest.domain.RouteClassification;
import com.ibasis.aqr.itest.domain.TestRule;
import com.ibasis.aqr.itest.domain.VoiceCarrierGroup;
import com.ibasis.aqr.itest.dpmanager.DialPatternMgr;

public interface RMSDAO {

    String getVersion() throws Exception;

    void loadRatesData(DialPatternMgr dpMgr) throws Exception;

    Collection<Country> loadInitData(DialPatternMgr dpMgr) throws Exception;

    Map<Long, Provider> getProviders();

    Map<Long, Product> getProducts();

    Map<Long, PreferredRoute> getPreferredRoutes();

    void clearData();

    int genRmsFeed() throws Exception;

    int genRmsResult() throws Exception;

    Product getProduct(long productId);

    Country getCountry(long countryId);

    Map<Long, Country> getCountries();

    void loadRMSCvgData(DialPatternMgr dpMgr) throws Exception;

    Provider getProvider(String colo) throws Exception;

    Map<Integer, RatePeriod> getRatePeriods() throws Exception;

    void loadSRCSettings() throws Exception;

    RouteClassification getRouteClassification(long routeClassificationId) throws Exception;

    int genMidProcess() throws Exception;

    Map<Long, VoiceCarrierGroup> getVoiceCarrierGroups();

    Set<Product> getSlbrFloorProducts(Integer slbr);

    void loadiTestConfiguration() throws Exception;

    Map<String, TestRule> getTestRules();

}
