package com.ibasis.aqr.itest.util;

import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class PasswordEncrypter {
    private static PasswordEncrypter instance = null;

    public static final String ALGORITHM_DESEDE = "DESede"; //default
    public static final String ALGORITHM_DES = "DES";
    private static final String DEFAULT_ENCRYPTION_KEY = "this is default encryption key";
    private static final String UNICODE_FORMAT = "UTF8";
    private KeySpec keySpec;
    private SecretKeyFactory keyFactory;
    private Cipher cipher;

    private PasswordEncrypter() throws Exception {
        this(ALGORITHM_DESEDE);
    }

    private PasswordEncrypter(String algorithm) throws Exception {
        this(algorithm, DEFAULT_ENCRYPTION_KEY);
    }

    private PasswordEncrypter(String algorithm, String encryptionKey) throws Exception {
        if (encryptionKey == null) {
            throw new IllegalArgumentException("encryption key was null");
        }
        if (encryptionKey.trim().length() < 24) {
            throw new IllegalArgumentException("encryption key was less than 24 characters");
        }

        byte[] keyAsBytes = encryptionKey.getBytes(UNICODE_FORMAT);

        if (algorithm.equals(ALGORITHM_DESEDE)) {
            keySpec = new DESedeKeySpec(keyAsBytes);
        } else if (algorithm.equals(ALGORITHM_DES)) {
            keySpec = new DESKeySpec(keyAsBytes);
        } else {
            throw new IllegalArgumentException("algorithm not supported: " + algorithm);
        }

        keyFactory = SecretKeyFactory.getInstance(algorithm);
        cipher = Cipher.getInstance(algorithm);

        instance = this;
    }

    public static PasswordEncrypter getInstance() throws Exception {
        if (instance == null) {
            instance = new PasswordEncrypter();
        }
        return instance;
    }

    public synchronized String encrypt(String input) throws Exception {
        if (input == null || input.trim().length() == 0) {
            throw new IllegalArgumentException("input was null or empty");
        }

        input = input.trim();
        SecretKey key = keyFactory.generateSecret(keySpec);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] cleartext = input.getBytes(UNICODE_FORMAT);
        byte[] ciphertext = cipher.doFinal(cleartext);

        BASE64Encoder base64encoder = new BASE64Encoder();
        return base64encoder.encode(ciphertext);
    }

    public synchronized String decrypt(String encryptedString) throws Exception {
        if (encryptedString == null || encryptedString.trim().length() <= 0) {
            throw new IllegalArgumentException("encrypted string was null or empty");
        }

        encryptedString = encryptedString.trim();
        SecretKey key = keyFactory.generateSecret(keySpec);
        cipher.init(Cipher.DECRYPT_MODE, key);
        BASE64Decoder base64decoder = new BASE64Decoder();
        byte[] ciphertext = base64decoder.decodeBuffer(encryptedString);
        byte[] cleartext = cipher.doFinal(ciphertext);
        return bytes2String(cleartext);
    }

    private String bytes2String(byte[] bytes) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < bytes.length; i++) {
            stringBuffer.append((char) bytes[i]);
        }
        return stringBuffer.toString();
    }

    private void printUsage() {
        System.out.println("Usage: java " + this.getClass().getName() + " password");
    }

    public static void main(String[] args) throws Exception {
        PasswordEncrypter encrypter = PasswordEncrypter.getInstance();

        if (args == null || args.length != 1) {
            System.out.println("Please provide the password to be encrypted.");
            encrypter.printUsage();
            return;
        }

        String input = args[0];
        String ciphertext = encrypter.encrypt(input);
        System.out.println("Input: " + args[0]);
        System.out.println("Encrypted: " + ciphertext);
    }
}
