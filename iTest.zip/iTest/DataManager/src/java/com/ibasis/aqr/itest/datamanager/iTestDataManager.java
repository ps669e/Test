/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.datamanager;

/**
 *
 * This class is a facade for data access from different data sources.
 *
 * @author schan
 *
 */
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.common.iTestConstants;
import com.ibasis.aqr.itest.config.iTestConfigManager;
import com.ibasis.aqr.itest.datamanager.intf.RMSDAO;
import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.domain.DialPattern;
import com.ibasis.aqr.itest.domain.DomainConstants;
import com.ibasis.aqr.itest.domain.FloorRate;
import com.ibasis.aqr.itest.domain.PreferredRoute;
import com.ibasis.aqr.itest.domain.Product;
import com.ibasis.aqr.itest.domain.Provider;
import com.ibasis.aqr.itest.domain.RatePeriod;
import com.ibasis.aqr.itest.domain.RouteClassification;
import com.ibasis.aqr.itest.domain.RouteStatus;
import com.ibasis.aqr.itest.domain.TestRule;
import com.ibasis.aqr.itest.dpmanager.DialPatternMgr;
import com.ibasis.aqr.itest.util.AQRPropertyReader;

public class iTestDataManager {
    private static final Log logger = LogFactory.getLog(iTestDataManager.class);

    public static int dataSaveStep = 10000; //default setting for Bulk_save

    private RMSDAO rmsDAO = null;

    //Dial Pattern mgr to manage dial patterns in memory
    private DialPatternMgr dialPatternMgr = new DialPatternMgr();

    private String verData = null; //Version of iTest in database

    private Map<Integer, RatePeriod> ratePeriods = new HashMap<>();

    /**
     * Constructor
     *
     * @throws Exception
     */
    public iTestDataManager() throws Exception {
        try {
            //Get our DAOs from the factory. This is for ability to switch datasources at run-time to facilitate testing.
            rmsDAO = iTestDAOFactory.getRMSDAO();
            if (versionCheck()) { //Check we are running correct version
                logger.info("iTestDataManager() : iTest version check OK : " + getVerData());

                //Load all reference data and configured properties
                String prop = AQRPropertyReader.getProperty("DATA_SAVE_STEP_SIZE");
                if (prop != null && prop.trim().length() > 0) {
                    dataSaveStep = Integer.parseInt(prop);
                }
                logger.info("iTestDataManager() : DATA_SAVE_STEP_SIZE is set to " + dataSaveStep);
            } else {
                throw new Exception("iTestDataManager() iTest version check Failed! \n" + " Running version : " + getVerData() + ", Version in database : "
                        + rmsDAO.getVersion());
            }

        } catch (Exception ex) {
            logger.error("iTestDataManager(): Failed !", ex);
            throw ex;
        }
    }

    /**
     * Top level method call to load all data from different datasources
     *
     * @return all countries
     * @throws Exception
     */
    public Collection<Country> loadiTestData() throws Exception {
        Collection<Country> countries = null;
        try {
            //Initial data load from RMS. Most of the data loaded here is a pre-requisite for
            //correlation with data to be loaded from other sources.
            countries = loadRMSInitData();

            if (countries != null) {
                rmsDAO.loadRatesData(dialPatternMgr); //Load rates from RMS
                rmsDAO.loadRMSCvgData(dialPatternMgr);
                rmsDAO.loadSRCSettings();

                // Default SRC
                RouteClassification defaultSRC = getRouteClassification(DomainConstants.SRC_UNCLASSIFIED_ID);
                dialPatternMgr.setDefaultSRC(defaultSRC);

            } else {
                throw new Exception("No country data loaded!");
            }
        } catch (Exception ex) {
            logger.error("loadiTestData(): Failed loading data", ex);
            throw ex;
        }

        return countries;
    }

    /**
     * Call to RMS Pre-process
     *
     * @return Pre-process return code.
     * @throws Exception
     */
    public int genRmsFeed() throws Exception {
        int retVal = -1;
        try {
            retVal = rmsDAO.genRmsFeed();
            if (retVal != 0) {
                logger.error("genRmsFeed(): Failed with error code : " + retVal);
            }
        } catch (Exception ex) {
            logger.error("genRmsFeed(): Failed!", ex);
            throw ex;
        }

        return retVal;
    }

    /**
     * Call to RMS Post-process
     *
     * @return post-process return code
     * @throws Exception
     */
    public int genRmsResult() throws Exception {
        int retVal = -1;
        try {
            retVal = rmsDAO.genRmsResult();
            if (retVal != 0) {
                logger.error("genRmsResult(): Failed with error code : " + retVal);
            }
        } catch (Exception ex) {
            logger.error("genRmsResult(): Failed!", ex);
            throw ex;
        }

        return retVal;
    }

    /**
     * Loads all initial data from RMS. Also correlates providers loaded from RMS
     * with providers in AQR.
     *
     * @return
     * @throws Exception
     */
    private Collection<Country> loadRMSInitData() throws Exception {
        Collection<Country> retData = null;
        try {
            retData = rmsDAO.loadInitData(dialPatternMgr);
            setRatePeriods(rmsDAO.getRatePeriods());
            rmsDAO.loadiTestConfiguration();
        } catch (Exception ex) {
            logger.error("loadRMSInitData(): Failed to get RMS init data.", ex);
            throw ex;
        }
        return retData;
    }

    /**
     * Given a product and preferred route returns the floor rate
     *
     * @param pfRt Preferred route
     * @param pKey product key
     * @return floor rate
     */
    public double getPendingActiveFloorRate(DialPattern dp, Long pKey) {
        double floorRate = DomainConstants.NULL_DOUBLE_VALUE;
        Product prod = getProduct(pKey);
        if (prod != null) {
            FloorRate flRate = dp.getFloorRateByProduct(prod);
            if (flRate != null) {
                floorRate = flRate.getFloorRate();
            }
        }

        return floorRate;
    }

    public double getPendingActiveFloorRateByPeriodId(DialPattern dp, Long pKey, int periodId) {
        double floorRate = DomainConstants.NULL_DOUBLE_VALUE;
        Product prod = getProduct(pKey);
        if (prod != null) {
            FloorRate flRate = dp.getFloorRateByProductPeriodId(prod, periodId);
            if (flRate != null) {
                floorRate = flRate.getFloorRate();
            }
        }

        return floorRate;
    }

    /**
     * Given a product and preferred route returns the floor rate
     *
     * @param pfRt Preferred route
     * @param pKey product key
     * @return floor rate
     */
    public double getFloorRate(PreferredRoute pfRt, Long pKey) {
        double floorRate = DomainConstants.NULL_DOUBLE_VALUE;
        Product prod = getProduct(pKey);
        if (prod != null) {
            FloorRate flRate = pfRt.getFloorRateByProduct(prod);
            if (flRate != null) {
                floorRate = flRate.getFloorRate();
            }
        }

        return floorRate;
    }

    /**
     * Given a product, preferred route, and a period id, return the floor rate
     *
     * @param pfRt Preferred route
     * @param pKey product key
     * @param periodId period id
     * @return floor rate
     */
    public double getFloorRateByPeriodId(PreferredRoute pfRt, Long pKey, int periodId) {
        double floorRate = DomainConstants.NULL_DOUBLE_VALUE;
        Product prod = getProduct(pKey);
        if (prod != null) {
            FloorRate flRate = pfRt.getFloorRateByProductPeriodId(prod, periodId);
            if (flRate != null) {
                floorRate = flRate.getFloorRate();
            }
        }

        return floorRate;
    }

    /**
     * @param rmsPeriods
     */
    public void setRatePeriods(Map<Integer, RatePeriod> rmsPeriods) {
        ratePeriods.putAll(rmsPeriods);
        iTestConfigManager.getInstance().setRatePeriods(ratePeriods);
    }

    /**
     * Performs a check for version of software against version in database
     *
     * @return true or false
     * @throws Exception
     */
    public boolean versionCheck() throws Exception {
        BufferedReader rd = null;
        try {
            InputStream istr = Thread.currentThread().getContextClassLoader().getResourceAsStream(iTestConstants.VERSION_FILE);
            if (istr != null) {
                rd = new BufferedReader(new InputStreamReader(istr));
                String line;
                while ((line = rd.readLine()) != null) {
                    if (line.trim().length() > 0 && line.trim().charAt(0) != '#') {
                        setVerData(line);
                        break;
                    }
                }
            } else {
                throw new Exception("Could not read version file!");
            }
            if (verData != null && verData.length() > 0) {
                return verData.equals(rmsDAO.getVersion());
            } else {
                verData = "NULL";
            }

        } catch (Exception e) {
            logger.error("versionCheck() : Exception caught", e);
            throw e;
        } finally {
            if (rd != null) {
                rd.close();
            }
        }

        return false;
    }

    /**
     * @return Returns the verData.
     */
    public String getVerData() throws Exception {
        return verData;
    }

    /**
     * @param verData
     *            The verData to set.
     */
    public void setVerData(String verData) {
        this.verData = verData;
    }

    /**
     *
     * @param countryId country id
     * @return
     */
    public Country getCountry(long countryId) {
        return rmsDAO.getCountry(countryId);
    }

    /**
     *
     * @return all countries in RMS
     */
    public Collection<Country> getCountries() {
        if (rmsDAO != null && rmsDAO.getCountries() != null) {
            return rmsDAO.getCountries().values();
        }
        return null;
    }

    /**
     *
     * @param productId product id
     * @return
     */
    public Product getProduct(long productId) {
        if (rmsDAO != null) {
            return rmsDAO.getProduct(productId);
        }
        return null;
    }

    /**
     *
     * @return all products in RMS
     */
    public Collection<Product> getProducts() {
        if (rmsDAO != null) {
            return rmsDAO.getProducts().values();
        }
        return null;
    }

    public Product getPvProduct() {
        return getProduct(iTestConstants.PRODUCT_ID_PV);
    }

    /**
     *
     * @param defaultKey key for default value
     * @return Default value
     */
    public String getDefaultValue(String defaultKey) {
        return iTestConfigManager.getInstance().getDefaultValue(defaultKey);
    }

    public Provider getProvider(String defaultProviderColo) throws Exception {
        return rmsDAO.getProvider(defaultProviderColo);
    }

    /**
     * This method is used for Mid process Generation.
     *
     * @return
     * @throws Exception
     */
    public int genMidProcess() throws Exception {
        int retVal = -1;
        try {
            retVal = rmsDAO.genMidProcess();
            if (retVal != 0) {
                logger.error("genMidProcess(): Failed with error code : " + retVal);
            }
        } catch (Exception ex) {
            logger.error("genMidProcess(): Failed to gen MID Process data.", ex);
            throw ex;
        }
        return retVal;
    }

    public Map<String, String> getDefaultValues() {
        return iTestConfigManager.getInstance().getDefaultValues();
    }

    public RouteClassification getRouteClassification(long routeClassificationId) throws Exception {
        return rmsDAO.getRouteClassification(routeClassificationId);
    }

    public Set<Product> getSlbrFloorProducts(Integer slbr) {
        Set<Product> floorProducts = null;
        if (slbr != null) {
            floorProducts = rmsDAO.getSlbrFloorProducts(slbr);
        }
        return floorProducts == null ? null : Collections.unmodifiableSet(floorProducts);
    }

    /**
     * Return GcsRule by looking up ITVW_ITEST_GCS_RULES table.
     * GcsRule tells how to block(GCS_BLOCK_GROUP_ID) and test(GCS_TEST_GROUP_ID) a test vendor in GCS rules table.
     *
     * @param rule Must be a valid ITVW_ITEST_GCS_RULES.ITEST_RULE
     * @param pvStatus Test vendor's pv status code
     * @param cvStatus Test vendor's cv status code
     * @return GcsRule
     */
    public TestRule getTestRule(String rule, RouteStatus pvStatus, RouteStatus cvStatus) {
        String key = getRuleKey(rule, pvStatus, cvStatus);
        Map<String, TestRule> testRules = rmsDAO.getTestRules();
        return testRules.get(key);
    }

    /**
     * Return key in format: Rule.PvStatusCategory.CvStatusCategory
     * where Rule = matching ITVW_ITEST_GCS_RULES.ITEST_RULE
     *       PvStatusCategory = matching ITVW_ITEST_GCS_RULES.PV_STATUS_CATEGORY, or "" empty if null
     *       CvStatusCategory = matching ITVW_ITEST_GCS_RULES.CV_STATUS_CATEGORY, or "" empty if null
     * @param rule Must be a valid ITVW_ITEST_GCS_RULES.ITEST_RULE
     * @param pvStatus Test vendor's pv status code
     * @param cvStatus Test vendor's cv status code
     * @return
     */
    private String getRuleKey(String rule, RouteStatus pvStatus, RouteStatus cvStatus) {
        return rule + "." + (pvStatus==null?"":pvStatus.getCategoryCodeDesc()) + "." + (cvStatus==null?"":cvStatus.getCategoryCodeDesc());
    }

}
