#!/bin/sh

### REGRESSION CHECK ###
CONNECTION=aqr51_sib_reg/aqr51@aqr1_dev
PATT_DIFF=scripts/patt_diff.sql
PATT_DIFF_FILE=patt_diff.txt
PATT_LINEUP_DIFF=scripts/patt_lineup_diff.sql
PATT_LINEUP_DIFF_FILE=patt_lineup_diff.txt
echo ### Running Regression checks ###
echo - Pattern content check
sqlplus /nolog @${PATT_DIFF} $CONNECTION >> /dev/null
if [ -s $PATT_DIFF_FILE ] ; then
        echo Result -  FAIL!
else
        echo Result -  PASS
fi

echo - Lineup content check
sqlplus /nolog @${PATT_LINEUP_DIFF} $CONNECTION >> /dev/null
if [ -s $PATT_LINEUP_DIFF_FILE ] ; then
        echo Result -  FAIL!
else
        echo Result -  PASS
fi
