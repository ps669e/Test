/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.domain.comparator;

import java.util.Comparator;

import com.ibasis.aqr.itest.common.iTestConstants;
import com.ibasis.aqr.itest.common.iTestConstants.TestProduct;
import com.ibasis.aqr.itest.domain.iTestVendor;

/**
 * @author schan
 *
 */
public class VendorRateComparator implements Comparator<iTestVendor> {
    private int type;

    public VendorRateComparator(int type) {
        this.type = type;
    }

    @Override
    public int compare(iTestVendor first, iTestVendor second) {

        int result = 0;

        if (type == iTestConstants.COST) {
            double maxCost1 = first.getMaxCost();
            double maxCost2 = second.getMaxCost();
            double res = maxCost1 - maxCost2;
            if (res > 0) {
                result = 1;
            } else if (res < 0) {
                result = -1;
            } else {
                double maxNetCost1 = first.getMaxNetCost();
                double maxNetCost2 = second.getMaxNetCost();
                res = maxNetCost1 - maxNetCost2;
                if (res > 0) {
                    result = 1;
                } else if (res < 0) {
                    result = -1;
                }
            }
        } else {
            double maxNetCost1 = first.getMaxNetCost();
            double maxNetCost2 = second.getMaxNetCost();
            double res = maxNetCost1 - maxNetCost2;
            if (res > 0) {
                result = 1;
            } else if (res < 0) {
                result = -1;
            } else {
                double maxCost1 = first.getMaxCost();
                double maxCost2 = second.getMaxCost();
                res = maxCost1 - maxCost2;
                if (res > 0) {
                    result = 1;
                } else if (res < 0) {
                    result = -1;
                }
            }
        }

        if (result == 0) {
            TestProduct prod1 = first.getTestProduct();
            TestProduct prod2 = second.getTestProduct();

//            if (prod1 != prod2) {
//                throw new RuntimeException("VendorRateComparator Error -- Two iTestVendors must have same test product. first:" + first + " | second:" + second);
//            }
//
//            RouteStatus status1 = first.getRouteStatusPv();
//            RouteStatus status2 = second.getRouteStatusPv();
//
//            result = (int) status1.getRank() - (int) status2.getRank();
        }

        if (result == 0) {
            result = second.getSlbr() - first.getSlbr();
        }

        if (result == 0) {
            result = first.getProvider().compareTo(second.getProvider());
        }

        return result;
    }

}
