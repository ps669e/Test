/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.domain;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.config.iTestConfigManager;

/**
 *
 * This class represents a provider's coverage on a dial pattern.
 * It holds information such as status code, rates, attributes, etc
 * for a particular provider and dial pattern combination.
 *
 * @author schan
 */
public class ProviderCoverage implements Cloneable {
    private static Log logger = LogFactory.getLog(ProviderCoverage.class);

    private boolean provPattern = false;

    private DialPattern dialPattern; //Dial pattern to which provider coverage belongs

    private Provider provider; //Provider for which this is the coverage

    private Map<Integer, ProviderRate> rates = null; // Map<periodId, ProviderRate> Provider rates for this coverage.

    private boolean inTesting = false; //Is in testing

    private RouteStatus routeStatus = null;

    private RouteStatus rcMaxStat = null; //route status at routing choice level

    private byte isTod = -1;
    private byte periodMismatch = -1;
    private Map<Integer, RcData> rcDataMap = null; // Map<lineup periodId, RcData>;
    private PreferredRoute preferredRouteUseByClone = null; // used by clone method
    private DialPattern dpUseByClone = null; // used by clone method

    private boolean newPattern = false;

    /**
     * @param provider
     */
    public ProviderCoverage(Provider provider) {
        this.setProvider(provider);
    }

    /**
     * Clones a providerCoverage just for status code. Used in places where
     * only status code needs to be inherited and nothing else.
     */
    public ProviderCoverage statusClone() {
        ProviderCoverage clonedCvg = new ProviderCoverage(this.provider);
        clonedCvg.setInTesting(this.inTesting);
        clonedCvg.setRouteStatus(this.routeStatus);
        return clonedCvg;
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof ProviderCoverage)) {
            return false;
        }
        ProviderCoverage castOther = (ProviderCoverage) other;
        return this.equals(castOther);
    }

    @Override
    public int hashCode() {
        int hash = 17;
        hash = 37 * hash + (null == this.getProvider() ? 0 : this.getProvider().hashCode());
        hash = 37 * hash + (null == this.getDialPattern() ? 0 : this.getDialPattern().hashCode());
        return hash;
    }

    public boolean equals(ProviderCoverage other) {
        return (this.getProvider().equals(other.getProvider()) && this.getDialPattern() == other.getDialPattern());
    }

    public boolean getProvPattern() {
        return provPattern;
    }

    public void setProvPattern(boolean provPattern) {
        this.provPattern = provPattern;
    }

    /**
     * return IP status
     *
     * @return
     */
    public Long getRouteStatusCode() {
        if (routeStatus != null) {
            return routeStatus.getCode();
        }

        return null;
    }

    public Long getRouteStatusCodePV(PreferredRoute prefRoute) {
        RouteStatus pvStatus = getRouteStatusPv(prefRoute);
        if (pvStatus != null) {
            return pvStatus.getCode();
        }

        return null;
    }

    public DialPattern getDialPattern() {
        return dialPattern;
    }

    public void setDialPattern(DialPattern dialPattern) {
        this.dialPattern = dialPattern;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    /**
     * return IP status ID
     *
     * @return
     */
    public long getRouteStatusID() {
        if (routeStatus != null) {
            return routeStatus.getId();
        }
        return DomainConstants.NULL_VALUE;
    }

    public long getRouteStatusIDPV(PreferredRoute prefRoute) {
        RouteStatus pvStatus = getRouteStatusPv(prefRoute);
        if (pvStatus != null) {
            return pvStatus.getId();
        }
        return DomainConstants.NULL_VALUE;
    }

    /**
     * Return IP status rank
     *
     * @return
     */
    public long getRank() {
        if (routeStatus != null) {
            return routeStatus.getRank();
        }
        return DomainConstants.NULL_VALUE;
    }

    public long getRankPV(PreferredRoute prefRoute) {
        RouteStatus pvStatus = getRouteStatusPv(prefRoute);
        if (pvStatus != null) {
            return pvStatus.getRank();
        }
        return DomainConstants.NULL_VALUE;
    }

    /**
     *
     * @return Map&lt;periodId, ProviderRate&gt;
     * @throws Exception
     */
    public Map<Integer, ProviderRate> getProviderRates() {
        //Check if rates is cached. If not cache it and then return the rates.
        if (rates == null) {
            rates = dialPattern.getProviderRates(this.getProvider());
            if (rates == null) {
                if (logger.isDebugEnabled()) {
                    logger.debug("getProviderRates(): Provider rate could not be determined for : " + "Pattern : " + dialPattern.getPattern() + " vendorId "
                            + this.getProvider().getVendorId());
                }
            }
        }
        return rates;
    }

    public int getCategoryCode() {
        if (routeStatus != null) {
            return routeStatus.getCategoryCode();
        }

        return DomainConstants.NON_ROUTABLE;
    }

    /**
     * Return PV status' category code. If PV status is not available,
     * DomainConstants.NULL_VALUE will be returned
     *
     * @return PV status' category code or DomainConstants.NULL_VALUE
     */
    public int getCategoryCodePV(PreferredRoute prefRoute) {
        RouteStatus pvStatus = getRouteStatusPv(prefRoute);
        if (pvStatus != null) {
            return pvStatus.getCategoryCode();
        }
        return DomainConstants.NULL_VALUE;
    }

    public long getVendorId() {
        return this.provider.getVendorId();
    }

    public boolean hasRequestedPVTesting(PreferredRoute pr) {
        return pr.hasVendorRequestedPvTesting(provider);
    }

    /**
     * The provider coverage is routable if it has status, rate in any period, and has routable category.
     *
     * @return boolean value of whether this provider coverage is routable
     */
    public boolean isRoutable() {
        if (routeStatus != null && rates != null) {
            return this.routeStatus.getCategoryCode() == DomainConstants.ROUTABLE;
        }
        return false;
    }

    /**
     * isRoutablePV is for future use
     *
     * @return
     */
    public boolean isRoutablePV(PreferredRoute prefRoute) {
        RouteStatus pvStatus = getRouteStatusPv(prefRoute);
        if (pvStatus != null && rates != null) {
            return pvStatus.getCategoryCode() == DomainConstants.ROUTABLE;
        }
        return false;
    }

    public boolean isNonRoutable() {
        if (routeStatus != null && rates != null) {
            return this.routeStatus.getCategoryCode() == DomainConstants.NON_ROUTABLE;
        }
        return true;
    }

    /**
     * isNonRoutablePV is for future use
     *
     * @return
     */
    public boolean isNonRoutablePV(PreferredRoute prefRoute) {
        RouteStatus pvStatus = getRouteStatusPv(prefRoute);
        if (pvStatus != null && rates != null) {
            return pvStatus.getCategoryCode() == DomainConstants.NON_ROUTABLE;
        }
        return true;
    }

    /**
     * @param inTesting
     *            The inTesting to set.
     */
    public void setInTesting(boolean inTesting) {
        this.inTesting = inTesting;
    }

    /**
     * Inherit from the given provider coverage
     *
     * @param cvg
     * @return
     */
    public Long inheritStatusCode(ProviderCoverage cvg) {
        setRouteStatus(cvg.getRouteStatus());
        return getRouteStatusCode();
    }

    public RouteStatus getRouteStatus() {
        return routeStatus;
    }

    public RouteStatus getRouteStatusPv(PreferredRoute prefRoute) {
        return prefRoute.getVendorRouteStatusPv(provider);
    }

    public void setRouteStatus(RouteStatus routeStatus) {
        this.routeStatus = routeStatus;
        this.rcMaxStat = routeStatus;
    }

    @Override
    public String toString() {
        StringBuffer buf = new StringBuffer(getDialPattern().getPattern());
        buf.append(" - ").append(getProvider().getVendorId()).append(" - ").append(getRouteStatusCode());
        return buf.toString();
    }

    // ***************************
    // Methods refactored from PRC
    // ***************************
    /**
     * @return Returns the rcMaxRank.
     */
    public long getRcMaxRank() {
        if (rcMaxStat != null) {
            return rcMaxStat.getRank();
        }
        return DomainConstants.NULL_LONG_VALUE;
    }

    /**
     * @return Returns the rcMaxRtStatId.
     */
    public long getRcMaxRtStatId() {
        if (rcMaxStat != null) {
            return rcMaxStat.getId();
        }
        return DomainConstants.NULL_LONG_VALUE;
    }

    /**
     * @return Returns the rcMaxRtStstCode.
     */
    public Long getRcMaxRtStatCode() {
        if (rcMaxStat != null) {
            return rcMaxStat.getCode();
        }
        return DomainConstants.NULL_LONG_VALUE;
    }

    // schan - TOD
    public ProviderRate getProviderRate() {
        return getProviderRateByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
    }

    public ProviderRate getProviderRateByPeriodId(int periodId) {
        return this.rates.get(periodId);
    }

    public void setProviderRates(Map<Integer, ProviderRate> rates) {
        this.rates = rates;
    }

    public void setPreferredRouteUseByClone(PreferredRoute preferredRouteUseByClone) {
        this.preferredRouteUseByClone = preferredRouteUseByClone;
    }

    public void setDialPatternUseByClone(DialPattern dp) {
        this.dpUseByClone = dp;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        ProviderCoverage clonedCvg = null;
        try {
            // rcData are based on lineup periods
            Collection<TimeOfDay> lineupTods = preferredRouteUseByClone.getPeriodsForLineup();
            clonedCvg = (ProviderCoverage) super.clone();
            clonedCvg.rcDataMap = new HashMap<>(lineupTods.size());
            for (TimeOfDay tod : lineupTods) {
                int periodId = tod.getPeriodId();
                if (DomainConstants.RMS_WEEKDAY_PERIOD_ID == periodId) {
                    // use peak rates for weekday rc
                    periodId = DomainConstants.RMS_PEAK_PERIOD_ID;
                }

                double cost = getCostByPeriodId(periodId);
                if (DomainConstants.LARGE_DOUBLE_VALUE == cost) {
                    cost = getCostByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
                }

                double maxNetCost = getMaxNetCostByPeriodId(periodId);
                if (DomainConstants.LARGE_DOUBLE_VALUE == maxNetCost) {
                    maxNetCost = getMaxNetCostByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
                }

                RcData rcData = new RcData();
                rcData.setRcCost(cost);
                rcData.setRcMaxNetCost(maxNetCost);
                clonedCvg.rcDataMap.put(tod.getPeriodId(), rcData); // use lineup period
            }
        } catch (CloneNotSupportedException e) {
            throw e;
        }
        return clonedCvg;
    }

    public ProviderCoverage cloneWithoutAttrs(DialPattern dp) throws CloneNotSupportedException {
        ProviderCoverage clonedCvg = statusClone();
        clonedCvg.setDialPattern(dp);
        dp.addProviderCoverage(clonedCvg);
        // schan - set tod provider rates
        clonedCvg.setProviderRates(this.rates);
        return clonedCvg;
    }

    public Collection getOutbounds() {
        return getProvider().getOutbounds();
    }

    /**
     * @param periodId lineup periodId
     * @return
     */
    public double getRcCostByPeriodId(int periodId) {
        double rcCost = DomainConstants.LARGE_DOUBLE_VALUE; //Would rather return a high cost
        if (rcDataMap != null) {
            RcData rcData = rcDataMap.get(periodId);
            if (rcData != null) {
                rcCost = rcData.getRcCost();
                if (DomainConstants.LARGE_DOUBLE_VALUE != rcCost) {
                    return rcCost;
                }
            }

            // only default provider coverage created for blocked route will reach here
            if (rates != null) {
                rcCost = getCostByPeriodId(periodId);
                if (DomainConstants.LARGE_DOUBLE_VALUE == rcCost && DomainConstants.RMS_PEAK_PERIOD_ID != periodId) {
                    rcCost = getCostByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
                }
            }
        }
        return rcCost;
    }

    /**
     *
     * @param rcCost
     * @param periodId lineup periodId
     */
    public void setRcCostByPeriodId(double rcCost, int periodId) {
        if (rcDataMap != null) {
            RcData rcData = rcDataMap.get(periodId);
            if (rcData == null) {
                logger.error("There is no rcData for period: " + periodId);
            } else {
                double currentRcCost = rcData.getRcCost();
                if (DomainConstants.LARGE_DOUBLE_VALUE == currentRcCost) {
                    currentRcCost = rcCost;
                }
                rcData.setRcCost(Math.max(currentRcCost, rcCost));
            }
        }
    }

    /**
     *
     * @param periodId lineup periodId
     * @return
     */
    public double getRcMaxNetCostByPeriodId(int periodId) {
        double rcMaxNetCost = DomainConstants.LARGE_DOUBLE_VALUE; //Would rather return a high cost
        if (rcDataMap != null) {
            RcData rcData = rcDataMap.get(periodId);
            if (rcData != null) {
                rcMaxNetCost = rcData.getRcMaxNetCost();
                if (DomainConstants.LARGE_DOUBLE_VALUE != rcMaxNetCost) {
                    return rcMaxNetCost;
                }
            }

            // only default provider coverage created for blocked route will reach here
            if (rates != null) {
                rcMaxNetCost = getMaxNetCostByPeriodId(periodId);
                if (DomainConstants.LARGE_DOUBLE_VALUE == rcMaxNetCost && DomainConstants.RMS_PEAK_PERIOD_ID != periodId) {
                    rcMaxNetCost = getMaxNetCostByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
                }
            }
        }
        return rcMaxNetCost;
    }

    /**
     *
     * @param rcMaxNetCost
     * @param periodId lineup periodId
     */
    public void setRcMaxNetCostByPeriodId(double rcMaxNetCost, int periodId) {
        if (rcDataMap != null) {
            RcData rcData = rcDataMap.get(periodId);
            if (rcData == null) {
                logger.error("There is no rcData for period: " + periodId);
            } else {
                double currentRcMaxNetCost = rcData.getRcMaxNetCost();
                if (DomainConstants.LARGE_DOUBLE_VALUE == currentRcMaxNetCost) {
                    currentRcMaxNetCost = rcMaxNetCost;
                }
                rcData.setRcMaxNetCost(Math.max(currentRcMaxNetCost, rcMaxNetCost));
            }
        }
    }

    public double getCost() {
        return getCostByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
    }

    /**
     * This method tries to get the cost by period, if the period cost is not there,
     * this method returns DomainConstants.LARGE_DOUBLE_VALUE. Caller is
     * responsible for dealing with the return value.
     *
     * @param periodId
     * @return
     */
    public double getCostByPeriodId(int periodId) {
        double cost = DomainConstants.LARGE_DOUBLE_VALUE; //Would rather return a high cost
        if (this.rates != null) {
            ProviderRate todRate = this.rates.get(periodId);
            if (todRate != null) {
                if (DomainConstants.RMS_OFFPEAK_PERIOD_ID == periodId) {
                    // skip off-peak rate if peak and off-peak do not cover 24 hrs
                    ProviderRate pRate = getProviderRateByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
                    TimeOfDay peakTod = pRate == null ? null : pRate.getTimeOfDay();
                    TimeOfDay offpeakTod = todRate.getTimeOfDay();
                    if (is24HrPeakOffpeak(peakTod, offpeakTod)) {
                        cost = todRate.getCost();
                    }
                } else {
                    cost = todRate.getCost();
                }
            }
        }
        return cost;
    }

    public double getMaxNetCost() {
        return getMaxNetCostByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
    }

    /**
     * This method tries to get the maxnetcost by period, if the period
     * maxnetcost is not there, this method returns DomainConstants.LARGE_DOUBLE_VALUE.
     * Caller is responsible for dealing with the return value.
     *
     * @param periodId
     * @return
     */
    public double getMaxNetCostByPeriodId(int periodId) {
        double maxNetCost = DomainConstants.LARGE_DOUBLE_VALUE; //Would rather return a high maxnetcost
        if (this.rates != null) {
            ProviderRate todRate = this.rates.get(periodId);
            if (todRate != null) {
                if (DomainConstants.RMS_OFFPEAK_PERIOD_ID == periodId) {
                    // skip off-peak rate if peak and off-peak do not cover 24 hrs
                    ProviderRate pRate = getProviderRateByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
                    TimeOfDay peakTod = pRate == null ? null : pRate.getTimeOfDay();
                    TimeOfDay offpeakTod = todRate.getTimeOfDay();
                    if (is24HrPeakOffpeak(peakTod, offpeakTod)) {
                        maxNetCost = todRate.getMaxNetCost();
                    }
                } else {
                    maxNetCost = todRate.getMaxNetCost();
                }
            }
        }
        return maxNetCost;
    }

    public RouteStatus getRcMaxStat() {
        return rcMaxStat;
    }

    public void setRcMaxStat(RouteStatus rcMaxStat) {
        this.rcMaxStat = rcMaxStat;
    }

    /**
     * Determine whether this provider coverage's periods are same as preferred route's periods
     *
     * @return
     */
    public boolean isPeriodMismatch() {
        if (-1 == periodMismatch) {
            periodMismatch = 0;
            if (dialPattern != null) {
                PreferredRoute prefRt = dialPattern.getPreferredRoute();
                // non tod always returns false for period mismatch
                if (prefRt.isTod()) {
                    Map<Integer, TimeOfDay> prefRtTods = prefRt.getTimeofDayMap();
                    if (rates == null || (rates.size() != prefRtTods.size())) {
                        periodMismatch = 1;
                    } else {
                        // same number of periods, now check each period has same time definition or not
                        for (Integer ratePeriodId : rates.keySet()) {
                            TimeOfDay prefRtTod = prefRtTods.get(ratePeriodId);
                            if (prefRtTod == null) {
                                // could not find period from preferred route
                                periodMismatch = 1;
                                break;
                            }
                            ProviderRate rate = rates.get(ratePeriodId);
                            TimeOfDay rateTod = rate.getTimeOfDay();
                            if (rateTod == null) {
                                periodMismatch = 1;
                                break;
                            }
                            if (prefRtTod.compareTo(rateTod) != 0) {
                                periodMismatch = 1;
                                break;
                            }
                        }
                    }
                }
            }
        }
        return 1 == periodMismatch;
    }

    /**
     * aqrvw_vendor_route_summary
     *
     * period start_time end_time isTod
     * ----------------------------------------------------
     * case 1 p xxx xxx n
     *
     * case 2 p 00:00:00 23:59:59 n
     * o 23:59:59 00:00:00
     *
     * case 3 p xxx xxx y - weekend & weekday
     * w 18:00:00 07:00:00
     *
     * case 4 p 07:00:00 18:00:00 y
     * o 18:00:00 07:00:00
     *
     * case 4.1 p 07:00:00 14:00:00 n peak and off peak do not cover 24-hr is considered non-tod
     * o 18:00:00 07:00:00
     *
     * case 5 p 00:00:00 23:59:59 y - weekend & weekday
     * o 23:59:59 00:00:00
     * w F18:00:00 M07:00:00
     *
     * case 6 p 18:00:00 07:00:00 y
     * o 07:00:00 18:00:00
     * w F18:00:00 M07:00:00
     *
     * case 6.1 p 07:00:00 14:00:00 y weekend & weekday
     * o 18:00:00 07:00:00 peak and off peak do not cover 24-hr will be ignored
     * w F18:00:00 M07:00:00
     *
     * Following cases are not valid since peak and off peak are
     * defined in one record and peak start/end time cannot be null.
     *
     * case 7 p xxx xxx n
     * o 07:00:00 18:00:00 off peak will be ignored
     *
     * case 8 p xxx xxx y - weekend & weekday
     * o 23:59:59 00:00:00 off peak will be ignored
     * w 18:00:00 07:00:00
     *
     * @return boolean value that indicates whether provider offers tod rates
     */
    public boolean isTodVendor() {
        if (-1 == isTod) {
            isTod = 0;
            // iTest will filter out provider coverages that do no have rates
            if (rates != null) {
                ProviderRate pRate = rates.get(DomainConstants.RMS_PEAK_PERIOD_ID);
                ProviderRate oRate = rates.get(DomainConstants.RMS_OFFPEAK_PERIOD_ID);
                ProviderRate wRate = rates.get(DomainConstants.RMS_WEEKEND_PERIOD_ID);

                if (1 == rates.size()) {
                    if (pRate != null) {
                        isTod = 0; // case 1
                    }
                } else if (2 == rates.size()) {
                    String defaultStartTime = iTestConfigManager.getInstance().getTodDefaultWeekDayStartTime(); // 00:00:00
                    String defaultEndTime = iTestConfigManager.getInstance().getTodDefaultWeekDayStopTime(); // 23:59:59
                    TimeOfDay peakTod = pRate.getTimeOfDay();
                    TimeOfDay offpeakTod = oRate == null ? null : oRate.getTimeOfDay();
                    TimeOfDay weekendTod = wRate == null ? null : wRate.getTimeOfDay();
                    if (peakTod != null && offpeakTod != null) {
                        // po
                        if (peakTod.getStartTime() == null || peakTod.getEndTime() == null) {
                            isTod = 0; // case 7
                        } else if (peakTod.getStartTime().equals(defaultStartTime) && peakTod.getEndTime().equals(defaultEndTime)
                                && offpeakTod.getStartTime().equals(defaultEndTime) && offpeakTod.getEndTime().equals(defaultStartTime)) {
                            isTod = 0; // case 2
                        } else {
                            if (is24HrPeakOffpeak(peakTod, offpeakTod)) {
                                // case 4
                                isTod = 1;
                            } else {
                                // case 4.1
                                isTod = 0;
                            }
                        }
                    } else if (peakTod != null && weekendTod != null) {
                        // pw
                        if (peakTod.getStartTime() == null || peakTod.getEndTime() == null) {
                            isTod = 1; // case 3
                        }
                    }
                } else {
                    // pow
                    // off peak and weekend must have start and end time, otherwise data loading will filter them
                    isTod = 1;
                }
            }
        }
        return 1 == isTod;
    }

    public boolean is24HrPeakOffpeak(TimeOfDay peakTod, TimeOfDay offpeakTod) {
        boolean isTodPeakOffpeak24Hr = false;
        if (peakTod != null && offpeakTod != null) {
            String pStart = peakTod.getStartTime();
            String pEnd = peakTod.getEndTime();
            String oStart = offpeakTod.getStartTime();
            String oEnd = offpeakTod.getEndTime();
            if (pStart != null && pEnd != null && oStart != null && oEnd != null) {
                if (pStart.equals(oEnd) && pEnd.equals(oStart)) {
                    isTodPeakOffpeak24Hr = true;
                }
            }
        }
        return isTodPeakOffpeak24Hr;
    }

    /**
     * Generic method to compare this period to given provider coverage's period
     *
     * @param coverage
     * @param periodId preferred route period
     * @return
     */
    public int comparePeriod(ProviderCoverage coverage, int periodId) {
        int retVal = 0;
        ProviderRate rate1 = this.getProviderRateByPeriodId(periodId);
        ProviderRate rate2 = coverage.getProviderRateByPeriodId(periodId);
        if (rate1 != null && rate2 != null) {
            TimeOfDay tod1 = rate1.getTimeOfDay();
            TimeOfDay tod2 = rate2.getTimeOfDay();
            if (tod1 != null && tod2 != null) {
                retVal = tod1.compareTo(tod2);
            } else if (tod1 == null && tod2 != null) {
                retVal = -1;
            } else if (tod1 != null && tod2 == null) {
                retVal = 1;
            }
        } else if (rate1 == null && rate2 != null) {
            retVal = -1;
        } else if (rate1 != null && rate2 == null) {
            retVal = 1;
        }
        return retVal;
    }

    /**
     * this method is only used by unit test
     *
     * @param rcDataMap
     */
    public void setUnitTestRcDataMap(Map<Integer, RcData> rcDataMap) {
        this.rcDataMap = rcDataMap;
    }

    public boolean isNewPattern() {
        return newPattern;
    }

    public void setNewPattern(boolean newPattern) {
        this.newPattern = newPattern;
    }

}
