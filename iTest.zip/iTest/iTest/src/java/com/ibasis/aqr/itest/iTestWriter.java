package com.ibasis.aqr.itest;

/*
 * Created on Nov 9, 2004
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author csib
 *
 *         TODO To change the template for this generated type comment go to Window -
 *         Preferences - Java - Code Style - Code Templates
 */
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.common.iTestConstants;
import com.ibasis.aqr.itest.datamanager.iTestDataManager;
import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.domain.DialPattern;
import com.ibasis.aqr.itest.domain.DomainConstants;
import com.ibasis.aqr.itest.domain.PreferredRoute;
import com.ibasis.aqr.itest.domain.Product;
import com.ibasis.aqr.itest.domain.Provider;
import com.ibasis.aqr.itest.domain.ProviderCoverage;
import com.ibasis.aqr.itest.domain.ProviderRate;
import com.ibasis.aqr.itest.domain.RouteClassification;
import com.ibasis.aqr.itest.domain.TimeOfDay;
import com.ibasis.aqr.itest.domain.iTestVendor;
import com.ibasis.aqr.itest.util.AQRPropertyReader;

import EDU.oswego.cs.dl.util.concurrent.CountDown;

public class iTestWriter implements Runnable {
    private static final Log log = LogFactory.getLog(iTestWriter.class);

    private static final String endl = System.getProperty("line.separator");
    private static final String sysDeco = "####################################################".concat(endl);
    private static final String countryDeco = "# ******************************".concat(endl);
    private static final String pfRtDeco = "# ---------------------------".concat(endl);
    private static final String testVendorDeco = "# -------------------------".concat(endl);
    private static final String clpseMarker = " <####> ";
    private static final String routblMarker = " <@@@@> ";
    private static final String ctryHdr = "Country - ";
    private static final String pfrtHdr = "Preferred Route - ";
    private static final String testVendorsHdr = "  TEST VENDORS ";
    private static final String dpTotalMarker = "#### DIAL PATTERNS - Total ";
    private static final String rtHdr = "#### ";
    private static final String totRtHdr = " : TOTAL ROUTES - ";
    private static final String flrCap = ", Floor - ";
    private static final String none = "NONE";
    private static final String rtCap = "Route - ";
    private static final String tab = "\t";
    private static final String csopen = "*[";
    private static final String csclose = "]";
    private static final String oBrack = "(";
    private static final String cBrack = ")";
    private static final String srcOpen = "c[";
    private static final String srcClose = "]";
    private static final String embeddedOpen = "e[";
    private static final String embeddedClose = "]";
    private static final String oSquareBracket = "[";
    private static final String cSqureBracket = "]";
    private static final String comma = ",";
    private static final String perc = "%";
    private static final String tgOOS = ",TG_OOS";
    private static final String OOS = ",OOS";
    private static final String oTest = ",TEST-O";
    private static final String emptyStr = "";
    private static final String poundStr = "#";
    private static final String space = " ";
    private static final String dpStr = "Dial Patterns ";
    private static final String pendingActiveFloor = "PA Floor - ";

    private static final String srcEnabledStr = "SRC Enabled - ";

    private static final String todEnabledStr = "TOD Enabled - ";
    private static final String todPeriodMismatch = "PM";

    private static final String pvRoutingLineup = "PV Routing Lineup";

    private static final String OUT_FILE = "output_file";
    private static final String multiMtrVendors = "MMTR Vendors:";
    private static final String multiMtr = " MMTR";

    private static boolean fixedInfoProcessed = false;
    private final CountDown done;
    private iTestDataManager dMgr = null;
    private String fileName = "";
    private String sysFileName = "";

    public iTestWriter() {
        done = null;
    }

    public iTestWriter(CountDown dn, iTestDataManager dMgr) {
        this.done = dn;
        this.dMgr = dMgr;
        fileName = AQRPropertyReader.getProperty(OUT_FILE);
        if (fileName == null || fileName.length() <= 0) {
            fileName = "output/itest.out";
            sysFileName = "output/itest.out_system";
        }
        sysFileName = fileName.concat("_system");
    }

    private synchronized String getFixedInfo() {
        String fixedInfo = null;
        if (!fixedInfoProcessed) {
            if (log.isDebugEnabled()) {
                log.debug("getFixedInfo(): Output System settings ...");
            }
            fixedInfoProcessed = true;
            StringBuffer tmp = new StringBuffer();
            tmp.append(sysDeco).append(endl);
            tmp.append("****   SYSTEM SETTINGS ****").append(endl);
            if (dMgr != null) {
                tmp.append("RATE_ROLLOVER_HOURS : ").append(iTestConstants.RATE_ROLLOVER_HOURS).append(endl);
                tmp.append("RMS_QRY_TIMEOUT_MIN : ").append(iTestConstants.RMS_QRY_TIMEOUT_MIN).append(endl);
                tmp.append(endl);
                tmp.append("iTest DEFAULT_VALUES Settings: ").append(endl);
                for (Iterator iter = dMgr.getDefaultValues().entrySet().iterator(); iter.hasNext();) {
                    Map.Entry entry = (Map.Entry) iter.next();
                    tmp.append((String) entry.getKey()).append(" : ").append((String) entry.getValue()).append(endl);

                }
                tmp.append(endl);
                tmp.append("Product Settings: ").append(endl);
                Collection<Product> prods = dMgr.getProducts();
                if (prods != null) {
                    for (Product prod : prods) {
                        tmp.append(prod.getDescription());
                    }
                }
                tmp.append(endl).append("RoutingTable Settings: ").append(endl);
            } else {
                tmp.append("FATAL ERROR : iTestDataManager is NULL!").append(endl);
            }
            fixedInfo = tmp.append(endl).append(sysDeco).append(endl).append(endl).toString();
        }

        return fixedInfo;
    }

    private iWriter getWriter(String fileName) throws Exception {
        iWriter out = null;
        if (iTestConstants.WRITER_TYPE == iTestConstants.ZIP_WRITER) {
            if (log.isDebugEnabled()) {
                log.debug("ZipWriter implementation chosen.");
            }
            out = new ZipWriter(fileName);
        } else {
            if (log.isDebugEnabled()) {
                log.debug("RegWriter implementation chosen.");
            }
            out = new RegWriter(fileName);
        }
        return out;
    }

    public void writeOutput(Collection<Country> countries) {
        iWriter sysOut = null;
        iWriter out = null;
        try {
            String outputFileName = null;
            /*
             * Write all system values up front
             * schan - write fixed info only once in a separate file call itest.out_system
             */
            synchronized ("fixedInfoProcessed") {
                if (!fixedInfoProcessed) {
                    sysOut = getWriter(sysFileName);
                    sysOut.write(getFixedInfo());
                    sysOut.close();
                    sysOut = null;
                }
            }

            for (Country country : countries) {
                // one output file per country
                outputFileName = fileName + "_" + country.getCountryCode();
                out = getWriter(outputFileName);

                out.write(countryDeco);
                out.write(ctryHdr.concat(country.getName()).concat(endl));
                out.write(countryDeco);
                if (!country.isExcluded()) {
                    Collection<PreferredRoute> pfRoutes = country.getPreferredRoutes();
                    if (pfRoutes != null) {
                        for (PreferredRoute pRt : pfRoutes) {
                            out.write(pfRtDeco);
                            out.write(pfrtHdr.concat(pRt.getName()).concat(endl));
                            out.write(pfRtDeco);
                            out.write(todEnabledStr.concat(pRt.isTodEnabled() ? "Y" : "N").concat(endl));
                            Collection<TimeOfDay> prefRouteTods = pRt.getPreferredRoutePeriods();
                            if (pRt.isTod()) {
                                for (TimeOfDay tod : prefRouteTods) {
                                    out.write(tod.toString().concat(endl));
                                }
                            }

                            Set<Provider> mmtrVendors = pRt.getMultiMtrVendors();
                            if (mmtrVendors != null && !mmtrVendors.isEmpty()) {
                                out.write(iTestWriter.multiMtrVendors);
                                StringBuffer buf = new StringBuffer();
                                for (Provider provider : mmtrVendors) {
                                    buf.append(" ").append(provider.getVendorId());
                                }
                                out.write(buf.toString().concat(endl));
                            }

                            //Dial Pattern Level choices
                            List<DialPattern> dps = pRt.getDialPatterns();
                            if (dps != null) {
                                out.write(dpTotalMarker + dps.size() + endl);
                                for (DialPattern dp : dps) {
                                    out.write(dp.getPattern().concat(dp.isNewInRMS() ? "n" : "").concat(endl));
                                    List<ProviderCoverage> patrcs = dp.getPatternRoutingChoices();
                                    if (patrcs != null) {
                                        StringBuffer csStr = getPRCs(patrcs, pRt);
                                        if (csStr != null && csStr.length() > 0) {
                                            out.write(csStr.toString());
                                        }
                                    }
                                    out.write(endl);
                                    out.write(endl);
                                }
                            }

                            StringBuffer tmp = new StringBuffer();
                            //Write out the floors first
                            //                            if(rtables != null){
                            //                                Iterator rtit = rtables.iterator();
                            //                                while(rtit.hasNext()){
                            //                                    RoutingTable rtbl = (RoutingTable) rtit.next();
                            //                                    tmp.append(rtbl.getName()).append(flrCap);
                            //                                    for (TimeOfDay tod : prefRouteTods) {
                            //                                        FloorRate flrate = pRt.getFloorRateByProductPeriodId(rtbl.getFloorRateBlockingProduct(), tod.getPeriodId());
                            //                                        if (pRt.isTod()) {
                            //                                            tmp.append(tod.getPeriodCode()).append("=");
                            //                                        }
                            //                                        if (flrate != null)
                            //                                            tmp.append(flrate.getFloorRate()).append(" ");
                            //                                        else
                            //                                            tmp.append(none).append(" ");
                            //                                    }
                            //                                    tmp.append(endl);
                            //                                }
                            //                            }

                            out.write(testVendorDeco);
                            out.write(testVendorsHdr.concat(endl));
                            out.write(testVendorDeco);

                            // Test Vendors summarized at RP level
                            Collection<iTestVendor> testVendors = pRt.getiTestVendors();
                            tmp.append(writeTestVendors(testVendors));

                            out.write(tmp.append(endl).toString());
                            tmp = null;
                            out.write(endl);
                        }
                    }
                } else {
                    out.write("Excluded".concat(endl));
                }

                if (out != null) {
                    try {
                        out.close();
                        out = null;
                    } catch (IOException e1) {
                        log.error("writeOutput() : IOException ", e1);
                    }
                }

                // clear data for current country
                country.clearData();
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            log.error("writeOutput() : IOException ", e);
        } catch (Exception ex) {
            // TODO Auto-generated catch block
            log.error("writeOutput() : Exception ", ex);
        } finally {
            if (sysOut != null) {
                try {
                    sysOut.close();
                } catch (IOException e1) {
                    log.error("writeOutput() : IOException for sysOut", e1);
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    log.error("writeOutput() : IOException ", e1);
                }
            }
        }
    }

    private StringBuffer getPRCs(List<ProviderCoverage> patrcs, PreferredRoute pRt) {
        StringBuffer tmp = new StringBuffer();
        if (patrcs != null && !patrcs.isEmpty()) {
            for (ProviderCoverage prc : patrcs) {
                Long statusCode = prc.getRouteStatusCode();
                Long statusCodePV = prc.getRouteStatusCodePV(pRt);
                tmp.append(prc.getProvider().getVendorId()).append(oBrack);
                RouteClassification src = pRt.getProviderSrc(prc.getProvider());
                tmp.append(src == null ? "x" : src.getRouteClassificationId()).append(comma);

                // TOD - here, provider must have at least peak rate
                Map<Integer, ProviderRate> rates = prc.getProviderRates();
                for (ProviderRate rate : rates.values()) {
                    TimeOfDay tod = rate.getTimeOfDay();
                    int periodId = tod.getPeriodId();
                    if (DomainConstants.RMS_OFFPEAK_PERIOD_ID == periodId) {
                        ProviderRate pRate = prc.getProviderRateByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
                        TimeOfDay peakTod = pRate == null ? null : pRate.getTimeOfDay();
                        if (!prc.is24HrPeakOffpeak(peakTod, tod)) {
                            // skip off-peak if peak and off-peak do not cover 24 hrs
                            continue;
                        }
                    }
                    if (prc.isTodVendor()) {
                        tmp.append(tod.getPeriodCode()).append(oSquareBracket).append(tod.toStringWithoutPeriod()).append(" ");
                    }
                    double maxNetCost = prc.getMaxNetCostByPeriodId(periodId);
                    if (DomainConstants.LARGE_DOUBLE_VALUE == maxNetCost && DomainConstants.RMS_PEAK_PERIOD_ID != periodId) {
                        maxNetCost = prc.getMaxNetCostByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
                    }
                    double cost = prc.getCostByPeriodId(periodId);
                    if (DomainConstants.LARGE_DOUBLE_VALUE == cost && DomainConstants.RMS_PEAK_PERIOD_ID != periodId) {
                        cost = prc.getCostByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
                    }
                    tmp.append(maxNetCost).append(comma).append(cost);
                    if (prc.isTodVendor()) {
                        tmp.append(cSqureBracket);
                    }
                }

                tmp.append(comma).append(statusCode).append(statusCodePV == null ? emptyStr : "|" + statusCodePV)
                        .append(!prc.getProvider().isTgInService() ? tgOOS : emptyStr).append(cBrack);
            }

        }

        return tmp;
    }

    private StringBuffer writeTestVendors(Collection<iTestVendor> testVendors) {
        StringBuffer tmp = new StringBuffer();

        if (testVendors != null) {
            for (iTestVendor testVender : testVendors) {
                long statusCode = -9;
                if (testVender.getRouteStatusPv() != null) {
                    statusCode = testVender.getRouteStatusPv().getCode();
                }
                tmp.append(testVender.getProvider().getVendorId()).append(oBrack);
                RouteClassification src = testVender.getSrc();
                tmp.append(src == null ? "x" : src.getRouteClassificationId() + "|" + src.getSlbr()).append(comma);

                // TOD - here, provider must have at least peak rate
                double maxNetCost = testVender.getMaxNetCost();
                double cost = testVender.getMaxCost();
                tmp.append(maxNetCost).append(comma).append(cost);
                tmp.append(comma).append(statusCode).append(!testVender.isTgInService() ? tgOOS : emptyStr).append(cBrack);
            }

        }
        return tmp;
    }

    @Override
    public void run() {
        try {
            log.info(Thread.currentThread().getName().concat(": Writing output for countries"));
            writeOutput(dMgr.getCountries());
            log.info(Thread.currentThread().getName() + ": done writing output for category countries");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            done.release();
        }
    }

}
