/*
 * Created on Aug 16, 2004
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.ibasis.aqr.itest.dpmanager;

/**
 * @author csib Singleton Class DialPatternMgr To change the template for this
 *         generated type comment go to Window>Preferences>Java>Code
 *         Generation>Code and Comments
 */
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.domain.DialPattern;
import com.ibasis.aqr.itest.domain.PreferredRoute;
import com.ibasis.aqr.itest.domain.RouteClassification;
import com.ibasis.aqr.itest.tree.NodeNavigator;
import com.ibasis.aqr.itest.tree.TenaryTreeMgr;
import com.ibasis.aqr.itest.tree.TenaryTreeNode;

public class DialPatternMgr {
    private static final Log logger = LogFactory.getLog(DialPatternMgr.class);
    private TenaryTreeMgr treeMgr;
    private RouteClassification defaultSRC = null;

    public DialPatternMgr() {
        treeMgr = new TenaryTreeMgr();
    }

    public DialPattern recordDialPattern(String dpStr, Country country) throws Exception {
        DialPattern dp = null;
        try {
            dp = new DialPattern(dpStr);
            TenaryTreeNode node = treeMgr.insertPattern(dpStr, dp);
            dp.setNode(node);
            TenaryTreeNode rootnode = treeMgr.getRootNode(dpStr);
            if (!country.containsRootNode(rootnode)) {
                country.addRootNode(rootnode);
            }
        } catch (Exception ex) {
            logger.error("recordDialPattern() : " + dpStr, ex);
            throw ex;
        }

        return dp;
    }

    public DialPattern findPattern(String dpStr) {
        DialPattern dp = null;
        try {
            TenaryTreeNode node = treeMgr.findPattern(dpStr);
            if (node != null) {
                dp = (DialPattern) node.getNodeObject();
            }
        } catch (Exception ex) {
            logger.error("findPattern() : " + dpStr, ex);
            throw new RuntimeException(ex);
        }
        return dp;
    }

    /**
     * Get the closest match pattern.  If the closest match pattern is not equal to the given dpStr, add the dpStr to the closest pattern's preferred route.
     * @param dpStr
     * @param src
     * @return
     * @throws Exception
     */
    public DialPattern findFit(String dpStr, long routeID) throws Exception {
        DialPattern dp = null;
        try {
            DialPattern fitDP = findClosestMatch(dpStr);
            if (fitDP != null) {
                if (!fitDP.getPattern().equals(dpStr)) {
                    PreferredRoute pfRt = fitDP.getPreferredRoute();
                    dp = pfRt.addDialPattern(dpStr, routeID);
                } else {
                    dp = fitDP;
                }
            }
        } catch (Exception ex) {
            logger.error("findFit() : " + dpStr, ex);
            throw new RuntimeException(ex);
        }
        return dp;
    }

    public void applyToAllDialPatterns(NodeNavigator navigator) {
        treeMgr.navigateAll(navigator);
    }

    public DialPattern findClosestMatch(String dpStr) {
        DialPattern dp = null;
        try {
            TenaryTreeNode rootnode = treeMgr.getRootNode(dpStr);
            if (rootnode != null) {
                dp = (DialPattern) rootnode.getFurthestNodeObject(1, dpStr);
            }
        } catch (Exception ex) {
            logger.error("findFit() : " + dpStr, ex);
            throw new RuntimeException(ex);
        }
        return dp;
    }

    public RouteClassification getDefaultSRC() {
        return defaultSRC;
    }

    public void setDefaultSRC(RouteClassification defaultSRC) {
        this.defaultSRC = defaultSRC;
    }

}