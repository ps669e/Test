/*
 * ReporterCommon.java
 * Created on December 22, 2004, 10:47 AM
 */

package net.ibasis.aqr.itest.reporter;

import com.ibasis.aqr.itest.util.AQRPropertyReader;

public class ReporterCommon {

    /** Creates a new instance of ReporterCommon */

    public static final String REPORT_SAVING_DIR_PARAM = "REPORT_FILE_DIRECTORY";

    public static final String ITEST_VENDOR_REPORT_ENABLED_PARAM = "TEST_VENDOR_REPORT_ENABLED";
    public static final String ITEST_VENDOR_REPORT_SAVING_PARAM = "ITEST_VENDOR_REPORT_SAVING";
    public static final String VENDOR_PATTERN_REPORT_ENABLED_PARAM = "VENDOR_PATTERN_REPORT_ENABLED";
    public static final String VENDOR_PATTERN_REPORT_SAVING_PARAM = "VENDOR_PATTERN_REPORT_SAVING";

    private static final String REPORT_SAVING_FILE = "FILE";
    private static final String REPORT_SAVING_DIRECT = "DIRECT";

    public static final int FILE = 1;
    public static final int DIRECT = 2;

    public static boolean getGLCReportEnabled() {
        String value = AQRPropertyReader.getProperty(ITEST_VENDOR_REPORT_ENABLED_PARAM);
        return (value == null ? true : value.toUpperCase().equals("TRUE"));
    }

    public static int getITestVendorReportSaving() {
        String saving = AQRPropertyReader.getProperty(ITEST_VENDOR_REPORT_SAVING_PARAM);
        if (saving == null) {
            return FILE;
        } else if (saving.toUpperCase().equals(REPORT_SAVING_FILE)) {
            return FILE;
        } else if (saving.toUpperCase().equals(REPORT_SAVING_DIRECT)) {
            return DIRECT;
        } else {
            return FILE;
        }
    }

    public static boolean getVPReportEnabled() {
        String value = AQRPropertyReader.getProperty(VENDOR_PATTERN_REPORT_ENABLED_PARAM);

        return (value == null ? true : value.toUpperCase().equals("TRUE"));
    }

    public static int getVPReportSaving() {
        String saving = AQRPropertyReader.getProperty(VENDOR_PATTERN_REPORT_SAVING_PARAM);
        if (saving == null) {
            return FILE;
        } else if (saving.toUpperCase().equals(REPORT_SAVING_FILE)) {
            return FILE;
        } else if (saving.toUpperCase().equals(REPORT_SAVING_DIRECT)) {
            return DIRECT;
        } else {
            return FILE;
        }
    }

    public static String getReportSavingDirectory() {
        return AQRPropertyReader.getProperty(REPORT_SAVING_DIR_PARAM);
    }
}
