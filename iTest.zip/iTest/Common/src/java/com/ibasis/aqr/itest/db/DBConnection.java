package com.ibasis.aqr.itest.db;

/**
 *
 * Utility class that deals with obtaining jdbc connection related tasks to provide
 * transparency to application from what environment it is running under - stand alone jvm or
 * web/app server
 *
 * @author schan
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.common.iTestConstants;
import com.ibasis.aqr.itest.util.AQRPropertyReader;

public class DBConnection {
    private static final Log logger = LogFactory.getLog(DBConnection.class);

    //This signifies if this is straight jdbc url based or data source based to
    //allow running both under stand alone jvm and web/app servers
    protected static String dbConnectionType = "";

    //Default URLs
    private static String rms_url = "jdbc:oracle:thin:@timsnyc.ibasis.net:1521:timsp";
    private static String rms_user = "aqr_select";
    private static String rms_password = "aqr_select";
    private static final String ITEST_RPT_TNS_PARAM = "ITEST_RPT_TNS";
    private static final String ITEST_RPT_USERNAME_PARAM = "ITEST_RPT_USERNAME";
    private static final String ITEST_RPT_PASSWORD_PARAM = "ITEST_RPT_PASSWORD";

    /**
     * constructor
     *
     */
    public DBConnection() {
        rms_url = AQRPropertyReader.getProperty("rms_url");
        rms_user = AQRPropertyReader.getProperty("rms_user");
        rms_password = AQRPropertyReader.getProperty("rms_password");
        String reportTns = AQRPropertyReader.getProperty(ITEST_RPT_TNS_PARAM);
        String reportUser = AQRPropertyReader.getProperty(ITEST_RPT_USERNAME_PARAM);
        String reportPassword = AQRPropertyReader.getProperty(ITEST_RPT_PASSWORD_PARAM);

        dbConnectionType = AQRPropertyReader.getProperty("db_connection_type");
        if (!dbConnectionType.equals(iTestConstants.DATA_SOURCE)) {
            //DATA_SOURCE Not configured - Do normal JDBC stuff
            if (logger.isInfoEnabled()) {
                logger.info("rms_url: " + rms_url);
                logger.info("rms_user: " + rms_user);
                logger.info("rms_password: " + rms_password);
                logger.info(ITEST_RPT_TNS_PARAM + ": " + reportTns);
                logger.info(ITEST_RPT_USERNAME_PARAM + ": " + reportUser);
                logger.info(ITEST_RPT_PASSWORD_PARAM + ": " + reportPassword);
            }
            try {
                Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
            } catch (Exception e) {
                logger.error("Exception in DBConnection(). ", e);
            }
        } else {
            logger.info("DBConnection(): DATA SOURCE CONFIGURATION SET.");
        }

    }

    public Connection getRMSConnection() throws Exception {
        if (dbConnectionType.equals(iTestConstants.DATA_SOURCE)) {
            return getConnection(iTestConstants.RMS_DATA_SOURCE);
        } else {
            //Normal JDBC Stuff
            return getJDBCConnection(rms_url, rms_user, rms_password);
        }
    }

    /**
     * Obtaind jdbc connection if a datasource is defined when running in web server env.
     *
     * @param dataSource jdbc datasoure
     * @return jdbc Connection
     * @throws Exception
     */
    private Connection getConnection(String dataSource) throws Exception {
        Connection conn = null;

        try {
            InitialContext initctx = new InitialContext();
            if (initctx == null) {
                logger.error("Boom!!! - No Context. ");
            } else {

                //Context envContext  = (Context)initctx.lookup("java:/comp/env");
                DataSource ds = (DataSource) initctx.lookup(dataSource);
                //Should come from property file

                if (ds != null) {
                    conn = ds.getConnection();
                    if (conn != null && conn.getAutoCommit()) {
                        conn.setAutoCommit(false);
                    }
                } else {
                    logger.error("DataSource " + dataSource + " not configured");
                }
            }
        } catch (Exception e) {
            logger.error("Exception in getConnection(). ", e);
            throw e;
        }

        return conn;
    }

    /**
     * Obtains jdbc connection from given jdbc url
     *
     * @param url jdbc URL
     * @param user username
     * @param password password
     * @return jdbc Connection
     * @throws Exception
     */
    private Connection getJDBCConnection(String url, String user, String password) throws Exception {
        Connection c = null;

        try {
            c = DriverManager.getConnection(url, user, password);
            if (c != null && c.getAutoCommit()) {
                c.setAutoCommit(false);
            }
        } catch (SQLException e) {
            logger.error("Exception in getJDBCConnection(). ", e);
            throw e;
        }
        return c;
    }

    public boolean commit(Connection connection) throws Exception {
        boolean isCommitted = false;
        try {
            if (connection != null && !connection.getAutoCommit()) {
                connection.commit();
            }
            isCommitted = true;
        } catch (SQLException e) {
            isCommitted = false;
            logger.error("commit() - SQL Exception found. ", e);
            throw e;
        }

        return isCommitted;
    }

    public boolean rollback(Connection connection) throws Exception {
        boolean success = false;

        try {
            if (connection != null && !connection.getAutoCommit()) {
                connection.rollback();
            }
            success = true;
        } catch (SQLException e) {
            success = false;
            logger.error("rollback() - SQLException found. ", e);
            throw e;
        }

        return success;

    }

}
