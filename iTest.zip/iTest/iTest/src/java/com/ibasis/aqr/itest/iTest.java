/*
 * Created on April 2018
 */
package com.ibasis.aqr.itest;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.Collection;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.common.iTestConstants;
import com.ibasis.aqr.itest.config.iTestConfigManager;
import com.ibasis.aqr.itest.datamanager.iTestDAOFactory;
import com.ibasis.aqr.itest.datamanager.iTestDataManager;
import com.ibasis.aqr.itest.domain.Country;
import com.ibasis.aqr.itest.rulesengine.iTestRulesEngine;
import com.ibasis.aqr.itest.tools.PreProcess;
import com.ibasis.aqr.itest.util.AQRPropertyReader;
import com.ibasis.aqr.itest.util.PasswordEncrypter;
import com.ibasis.aqr.itest.util.iTestThreadPool;

import EDU.oswego.cs.dl.util.concurrent.CountDown;
import net.ibasis.aqr.iroute.db.directload.NativeConnection;
import net.ibasis.aqr.itest.reporter.ReporterCommon;
import net.ibasis.aqr.itest.reporter.iTestVendorReport;

public class iTest {
    private static Log logger = LogFactory.getLog(iTest.class);

    private static final String ITEST_RPT_USERNAME_PARAM = "ITEST_RPT_USERNAME";

    private static final String ITEST_RPT_PWD_PARAM = "ITEST_RPT_PASSWORD";

    private static final String ITEST_RPT_TNS_PARAM = "ITEST_RPT_TNS";

    private static final String REPORT_BACKUP_SQL = "REPORT_TABLE_BACKUP_STATEMENT";

    private static final String REPORT_CLEANUP_SQL_PARAM = "REPORT_TABLE_CLEANUP_STATEMENT";

    public static final String AFTER_ROLLBACK_SQL = "{call aqr51_routes_bulk_updates.after_rollback}";

    private static final String GEN_MID_PROCESS_ENABLED = "GEN_MID_PROCESS_ENABLED";

    private static final String GEN_MID_PROCESS_WAIT = "GEN_MID_PROCESS_WAIT";

    private static iTestConfigManager configMgr = iTestConfigManager.getInstance();

    private static iTestDataManager dataMgr = null;

    public iTest() {

    }

    private void closeConnection(Connection con) {
        if (con != null) {
            try {
                if (!con.isClosed()) {
                    con.close();
                    con = null;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void testDbConnections() {
        System.out.println("\nUse encrypted db password - " + iTestConfigManager.getInstance().isDecryptDbPwd() + "\n");

        new iTestDAOFactory();
        System.out.println();

        Connection con = null;
        try {
            System.out.println("Testing RMS connection using rms_user, rms_url and rms_password itest properties...");
            con = iTestDAOFactory.DB_CONNECTION.getRMSConnection();

            DatabaseMetaData dm = con.getMetaData();
            System.out.println("Database Product Name: " + dm.getDatabaseProductName());
            System.out.println("Database Product Version: " + dm.getDatabaseProductVersion());
            System.out.println("JDBC Driver Name: " + dm.getDriverName());
            System.out.println("JDBC Driver Verison: " + dm.getDriverVersion());
            System.out.println("DB URL: " + dm.getURL());

            System.out.println("RMS connection established successfully!");

        } catch (Exception e) {
            System.out.println("Unable to connect to RMS schema!");
        } finally {
            closeConnection(con);
        }

        System.out.println();
        NativeConnection rptNativeConnection = null;
        try {
            System.loadLibrary("javadirectload");
            System.out.println("Testing report native connection using ITEST_RPT_TNS, ITEST_RPT_USERNAME and ITEST_RPT_PASSWORD itest properties...");

            String rptTns = AQRPropertyReader.getProperty(ITEST_RPT_TNS_PARAM);
            String rptUsername = AQRPropertyReader.getProperty(ITEST_RPT_USERNAME_PARAM);
            String rptPwd = AQRPropertyReader.getProperty(ITEST_RPT_PWD_PARAM);
            // decrypt the password
            if (iTestConfigManager.getInstance().isDecryptDbPwd()) {
                if (!StringUtils.isEmpty(rptPwd)) {
                    rptPwd = PasswordEncrypter.getInstance().decrypt(rptPwd);
                }
            }
            rptNativeConnection = new NativeConnection();
            rptNativeConnection.connect(rptUsername, rptPwd, rptTns);
            System.out.println("Native connection established successfully!");
        } catch (Exception e) {
            System.out.println("Unable to connect to databse using native connection!");
            e.printStackTrace();
        } finally {
            closeConnection(con);
        }

    }

    public void execute() throws Exception {
        boolean doPreProcess = configMgr.isPreProcessEnabled();
        boolean doReport = configMgr.isITestVendorReportEnabled();
        boolean doPostProcess = configMgr.isPostProcessEnabled();
        boolean doOutput = configMgr.isDoOutput();

        CountDown done = null;
        //MidProcessThread midProcessThread = null;

        int itestRunStatus = iTestConstants.ITEST_RUN_SUCCESS;
        try {
            ShutdownGuard guard = new ShutdownGuard();
            Runtime.getRuntime().addShutdownHook(guard);

            dataMgr = new iTestDataManager();
            guard.setDataManager(dataMgr);

            // Load System Library for Report gen
            if (doReport && (ReporterCommon.getITestVendorReportSaving() == ReporterCommon.DIRECT)
                    || (ReporterCommon.getVPReportSaving() == ReporterCommon.DIRECT)) {
                logger.info("execute(): Loading system library javadirectload ...");
                System.loadLibrary("javadirectload");
            }

            if (!doPreProcess) {
                logger.warn("execute(): Pre-Process turned off!");
            }

            if (!doPostProcess) {
                logger.warn("execute(): Post-Process turned off!");
            }

            if (!doReport) {
                logger.warn("execute(): Report turned off.");
            }

            if (doPreProcess) {
                PreProcess preprocess = new PreProcess();
                int preProcessStatus = preprocess.runPreProcess();
                if (preProcessStatus == iTestConstants.PRE_PROCESS_SUCCESS) {
                    logger.info("execute(): Successfully completed Pre-Process run!");
                } else {
                    itestRunStatus = iTestConstants.ITEST_RUN_FAIL;
                    logger.error("execute(): iTest Pre-Process failed!");
                }
            }

            if (itestRunStatus == iTestConstants.ITEST_RUN_SUCCESS) {
                NativeConnection reportNativeConnection = null;

                dataMgr.loadiTestData();

//                guard.addConnection(reportNativeConnection);

                //Apply Rules
                if (dataMgr.getCountries() != null && !dataMgr.getCountries().isEmpty()) {
                    int numIter = 1;
                    if (doOutput) {
                        done = new CountDown(numIter);
                    }

                    iTestRulesEngine rulesEngine = new iTestRulesEngine(dataMgr);

                    Collection<Country> countries = dataMgr.getCountries();
                    if (countries != null && !countries.isEmpty()) {
                        rulesEngine.applyRules(countries);

                        // Mid Process Generation
//                        if (iTestConfigManager.getInstance().isMidProcessEnabled()) {
//                            logger.info("execute(): Initializing Mid Process Gen ...");
//                            if (dataMgr != null) {
//                                try {
//                                    midProcessThread = new MidProcessThread(dataMgr);
//                                    midProcessThread.start();
//                                } catch (Exception e) {
//                                    logger.error("execute() :Mid Process Thread generated exception ", e);
//                                    e.printStackTrace();
//                                }
//                            } else {
//                                logger.error("execute(): iTestDataManager object is null");
//                            }
//                        }

                        //Do Report Generation
                        if (doReport) {
                            if ((reportNativeConnection == null) && ((ReporterCommon.getITestVendorReportSaving() == ReporterCommon.DIRECT)
                                    || (ReporterCommon.getVPReportSaving() == ReporterCommon.DIRECT))) {
                                logger.info("execute(): Initializing Report Gen ...");
                                String itestRptUsername = AQRPropertyReader.getProperty(ITEST_RPT_USERNAME_PARAM);
                                String itestRptPwd = AQRPropertyReader.getProperty(ITEST_RPT_PWD_PARAM);
                                String itestRptTns = AQRPropertyReader.getProperty(ITEST_RPT_TNS_PARAM);

                                reportNativeConnection = new NativeConnection();

                                // decrypt db password
                                if (iTestConfigManager.getInstance().isDecryptDbPwd()) {
                                    if (!StringUtils.isEmpty(itestRptPwd)) {
                                        itestRptPwd = PasswordEncrypter.getInstance().decrypt(itestRptPwd);
                                    }
                                }

                                logger.info("execute(): Database connection for Report - USER:" + itestRptUsername + " TNS:" + itestRptTns);
                                reportNativeConnection.connect(itestRptUsername, itestRptPwd, itestRptTns);

                                String backupSQL = AQRPropertyReader.getProperty(REPORT_BACKUP_SQL);
                                if (backupSQL != null) {
                                    logger.info("execute(): Executing backup procedure " + backupSQL);
                                    reportNativeConnection.executeSQL(backupSQL);
                                } else {
                                    logger.info("execute(): iTest Vendor Report backup skipped.");
                                }

                                String cleanupSQL = AQRPropertyReader.getProperty(REPORT_CLEANUP_SQL_PARAM);
                                if (cleanupSQL != null) {
                                    logger.info("execute(): Executing cleanup procedure " + cleanupSQL);
                                    reportNativeConnection.executeSQL(cleanupSQL);
                                } else {
                                    logger.info("execute(): iTest Vendor Report cleanup skipped.");
                                }
                            }

                            try {
                                iTestVendorReport vendorReport = new iTestVendorReport();
                                vendorReport.report(reportNativeConnection, dataMgr);
                                logger.info("execute(): Successfully completed iTest vendor report!");
                            } catch (Exception ex) {
                                logger.error("execute(): iTest Vendor Report writing failed" + ex.getMessage());
                                throw ex;
                            }
                        }

                        //Do output
                        if (doOutput) {
                            iTestWriter iwriter = new iTestWriter(done, dataMgr);
                            try {
                                iTestThreadPool.pool.execute(iwriter);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    } else {
                        if (doOutput) {
                            done.release();
                        }
                        logger.info("execute(): Did not process any countries");
                    }

                    // Call to Mid-process
//                    if (midProcessThread != null) {
//                        String strGenMidProcessWait = AQRPropertyReader.getProperty(GEN_MID_PROCESS_WAIT);
//                        boolean isGenMidProcessWait = strGenMidProcessWait == null ? true : strGenMidProcessWait.equals("true");
//
//                        if (midProcessThread.isAlive()) {
//                            if (isGenMidProcessWait) {
//                                midProcessThread.join();
//                            } else {
//                                logger.error("execute(): Mid Process did not complete, please contact AQR Support.");
//                                throw new Exception("Mid Process did not complete, please contact AQR Support.");
//                            }
//                        }
//                    }

                    //Generate RMS Result
                    if (doReport && doPostProcess) {
                        int postProcessStatus = dataMgr.genRmsResult();
                        if (postProcessStatus == iTestConstants.RMS_RESULT_SUCCESS) {
                            logger.info("execute(): Successfully completed Post-Process run!");
                        } else {
                            itestRunStatus = iTestConstants.ITEST_RUN_FAIL;
                            logger.error("execute(): iTest Post-Process failed!");
                        }
                    }

                    //Wait for output threads to finish
                    if (done != null) {
                        try {
                            done.acquire();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                } else {
                    logger.error("execute() FAILED: No countries loaded!");
                }
            }
        } catch (Exception ex) {
            logger.error("execute() FAILED: Exception: ", ex);
            itestRunStatus = iTestConstants.ITEST_RUN_FAIL;
        } catch (Throwable th) {
            logger.error("execute() FAILED: Throwable: ", th);
            itestRunStatus = iTestConstants.ITEST_RUN_FAIL;
        } finally {
            try {
                if (doOutput) {
                    logger.info("execute(): Shutting down thread pool");
                    iTestThreadPool.pool.shutdownNow();
                }
                if (itestRunStatus == iTestConstants.RMS_RESULT_SUCCESS) {
                    logger.info("execute(): Successfully completed iTest run!");
                } else {
                    logger.error("execute(): iTest run failed!");
                }
            } catch (Throwable th) {
                logger.error("execute() FAILED in finally: Throwable: ", th);
            }
        }

        logger.info("execute(): Done.");
    }
}
