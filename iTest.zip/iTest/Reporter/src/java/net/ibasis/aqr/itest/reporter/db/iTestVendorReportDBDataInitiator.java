/*
 * Created on April, 2018
 */

package net.ibasis.aqr.itest.reporter.db;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.util.AQRPropertyReader;

/**
 *
 * @author rkarpov
 */

import net.ibasis.aqr.iroute.db.ColumnData;
import net.ibasis.aqr.iroute.db.DatabaseData;
import net.ibasis.aqr.iroute.db.DatabaseDataInitiator;
import net.ibasis.aqr.iroute.db.DatabaseDataInterface;

// TestVendorReportDBDataInitiator sets up columns for saving
public class iTestVendorReportDBDataInitiator implements DatabaseDataInitiator {

    private static final Log logger = LogFactory.getLog(iTestVendorReportDBDataInitiator.class);

    public iTestVendorReportDBDataInitiator() {
    }

    private static final String DEFAULT_TABLE_NAME = "ITEST_VENDOR_REPORT_TABLE";
    private static final String TABLE_NAME_PARAMETER = "ITEST_VENDOR_REPORT_TABLE";

    //DirectLoadProxy implements DatabaseDataInterface
    @Override
    public void initDatabaseData(DatabaseDataInterface db, byte operation) {

        String tableName = AQRPropertyReader.getProperty(TABLE_NAME_PARAMETER);
        if (tableName == null) {
            logger.info(TABLE_NAME_PARAMETER + " parameter is not set. Using default value " + DEFAULT_TABLE_NAME);
            tableName = DEFAULT_TABLE_NAME;
        } else {
            logger.info("report table name: " + tableName);
        }

        db.setTableName(tableName);
        db.setOperationType(operation);
        db.startColumnSetup();
        switch (operation) {
            case DatabaseData.INSERT:
                db.addColumn(ColumnData.INTEGER, false, "COUNTRY_ID", 0);
                db.addColumn(ColumnData.CHAR, false, "GCS_ENABLED", 0);
                db.addColumn(ColumnData.INTEGER, false, "PREFERRED_ROUTE_ID", 0);
                db.addColumn(ColumnData.INTEGER, false, "VENDOR_ID", 0);
                db.addColumn(ColumnData.INTEGER, false, "ORIGINATION_ID", 0);
                db.addColumn(ColumnData.CHAR, false, "IS_PREMIUM", 0);
                db.addColumn(ColumnData.INTEGER, false, "RATE_PERIOD_ID", 0);
                db.addColumn(ColumnData.DOUBLE, false, "MAX_PROD_GROUP_FLOOR_RATE", 0);
                db.addColumn(ColumnData.DOUBLE, false, "MAX_COST", 0);
                db.addColumn(ColumnData.DOUBLE, false, "MAX_NET_COST", 0);
                db.addColumn(ColumnData.INTEGER, false, "PV_ROUTE_STATUS_ID", 0);
                db.addColumn(ColumnData.STRING, false, "PV_ROUTE_STATUS_CODE", 4);
                db.addColumn(ColumnData.INTEGER, false, "CV_ROUTE_STATUS_ID", 0);
                db.addColumn(ColumnData.STRING, false, "CV_ROUTE_STATUS_CODE", 4);
                db.addColumn(ColumnData.INTEGER, false, "PRIORITY", 0);
                db.addColumn(ColumnData.INTEGER, false, "NUM_OF_OFFERS", 0);
                db.addColumn(ColumnData.CHAR, false, "TG_IN_SERVICE", 0);
                db.addColumn(ColumnData.INTEGER, false, "ROUTE_CLASSIFICATION_ID", 0);
                db.addColumn(ColumnData.INTEGER, false, "SLBR", 0);
                db.addColumn(ColumnData.CHAR, false, "PASSED_ELIGIBILITY_TEST", 0);
                db.addColumn(ColumnData.CHAR, false, "GCS_RULE", 0);
                db.addColumn(ColumnData.CHAR, false, "HAS_NEW_PATTERN", 0);
                db.addColumn(ColumnData.CHAR, false, "ITEST_ENABLED", 0);
                break;
        }
        db.stopColumnSetup();

    }

}
