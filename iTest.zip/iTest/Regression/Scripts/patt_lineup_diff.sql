connect &1

set timing off
set pagesize 0
set feedback off
set termout off

spool patt_lineup_diff.txt

col reg_patt format a16
col patt format a16
select p_reg.route_key as reg_route_key, p_reg.pattern as reg_patt, TO_CHAR(p_reg.priority, '9999') as prty, TO_CHAR(p_reg.position, '9999') as pos, TO_CHAR(p_reg.traffic_percentage, '9999.99') as percent, p_reg.is_in_service as OOS, p_reg.in_testing as TEST, p.route_key, p.pattern as patt,TO_CHAR( p.priority, '9999') as prty, TO_CHAR(p.position, '9999') as pos, TO_CHAR(p.traffic_percentage, '9999.99') as percent, p.is_in_service as OOS, p.in_testing as TEST  
from (select mp.route_key, mp.pattern, rc.priority, rc.position, rc.traffic_percentage,rc.in_testing , rc.is_in_service, rc.carrier_site_key, rt.routingtable_key from routes_reg r, routingtable rt, matchpatterns_reg mp, routing_choice_reg rc where r.route_key = rc.route_key and r.route_key = mp.route_key and r.routingtable_key = rt.routingtable_key) p_reg, 
(select mp.route_key, mp.pattern, rc.priority,rc.position ,rc.traffic_percentage, rc.in_testing , rc.is_in_service , rc.carrier_site_key, rt.routingtable_key from routes r, matchpatterns mp, routing_choice rc, routingtable rt where r.route_key = rc.route_key and r.route_key = mp.route_key and r.routingtable_key = rt.routingtable_key and rt.update_by_iroute='Y') p 
where p_reg.pattern(+) = p.pattern and 
p_reg.carrier_site_key(+) = p.carrier_site_key and
p_reg.routingtable_key(+) = p.routingtable_key and
 (
	(p_reg.position is null and p.position is not null) or (p_reg.position is not null and p.position is null) or (p_reg.position is not null and p.position is not null and p_reg.position != p.position) or 
	p_reg.priority != p.priority or 
	(p_reg.traffic_percentage is null and p.traffic_percentage is not null) or (p_reg.traffic_percentage is not null and p.traffic_percentage is null) or (p_reg.traffic_percentage is not null and p.traffic_percentage is not null and p_reg.traffic_percentage != p.traffic_percentage) or p_reg.in_testing != p.in_testing or p_reg.is_in_service != p.is_in_service
);

spool off
exit;



