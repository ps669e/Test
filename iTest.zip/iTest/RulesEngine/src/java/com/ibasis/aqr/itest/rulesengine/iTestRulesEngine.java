/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.rulesengine;

import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.datamanager.iTestDataManager;
import com.ibasis.aqr.itest.domain.Country;

/**
 * @author schan
 *
 */
public class iTestRulesEngine {
    private static final Log logger = LogFactory.getLog(iTestRulesEngine.class);
    private CoverageRules coverageRules;
    private EligibilityRules eligibilityRules;

    public iTestRulesEngine(iTestDataManager dMgr) throws Exception {
        try {
            coverageRules = new CoverageRules(dMgr);
            eligibilityRules = new EligibilityRules(dMgr);
        } catch (Exception ex) {
            logger.error("iTestRulesEngine(): Exception", ex);
            throw ex;
        }
    }

    public void applyRules(Collection<Country> countries) throws Exception {
        try {
            logger.info("applyRules(): Applying Coverage Rules.");
            coverageRules.applyRulesOnCountry(countries);

            logger.info("applyRules(): Applying Vendor Eligibility Rules.");
            eligibilityRules.applyRulesOnCountry(countries);

        } catch (Exception ex) {
            logger.error("applyRules(): Exception", ex);
            throw ex;
        }

    }
}
