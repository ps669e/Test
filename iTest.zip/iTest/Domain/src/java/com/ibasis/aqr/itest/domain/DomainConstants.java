/*
 * Created on April, 2018
 */
package com.ibasis.aqr.itest.domain;

/**
 *
 * @author schan
 */
public class DomainConstants {

    public static final long SOURCE_NETWORK_ID_IP = 1;
    public static final long SOURCE_NETWORK_ID_TDM = 2;

    //Status code Categories
    public static final int ROUTABLE = 1;
    public static final int NON_ROUTABLE = 2;
    public static final int REQUIRED_TEST = 3; //forced test
    public static final int ONNET_TEST = 4;
    public static final int TEST = 5;

    //numeric constants values
    public static final int NULL_VALUE = -999;
    public static final double NULL_DOUBLE_VALUE = Double.NaN;
    public static final long NULL_LONG_VALUE = -999;
    public static final int LARGE_INTEGER_VALUE = Integer.MAX_VALUE;
    public static final double LARGE_DOUBLE_VALUE = Double.MAX_VALUE;
    public static final double SMALL_DOUBLE_VALUE = Double.MIN_VALUE;

    //RMS TOD periods
    public static final int RMS_PEAK_PERIOD_ID = 1;
    public static final int RMS_OFFPEAK_PERIOD_ID = 2;
    public static final int RMS_WEEKEND_PERIOD_ID = 3;
    public static final int RMS_WEEKDAY_PERIOD_ID = 4;

    public static final String WEEKDAY_PERIOD_CODE = "D";

    public static final int ONE_DAY = 24 * 60 * 60; // 24 hours in seconds
    public static final int ONE_WEEK = 7 * ONE_DAY; // 1 week in seconds

    public static final int SRC_BLACKLIST_ID = 5;
    public static final long SRC_UNCLASSIFIED_ID = 4;
}
