package com.ibasis.aqr.util;

public class DoubleComparison {
    public static final boolean compareDoubleValues(double d1, double d2) {
        boolean retVal = false;
        if (Double.isNaN(d1) && Double.isNaN(d2)) {
            retVal = true;
        } else if (Double.isNaN(d1) && !Double.isNaN(d2)) {
            retVal = false;
        } else if (!Double.isNaN(d1) && Double.isNaN(d2)) {
            retVal = false;
        } else {
            long long1;
            long long2;
            String d2Str = String.valueOf(d2);
            if (d2Str.contains(".")) {
                String[] subStr = d2Str.split("\\.");
                double len = subStr[1].length();
                double scale = Math.pow(10, len);
                long1 = (long) (d1 * scale + 0.5);
                long2 = (long) (d2 * scale + 0.5);
            } else {
                long1 = (long) d1;
                long2 = (long) d2;
            }
            if (long1 == long2) {
                retVal = true;
            } else {
                retVal = false;
            }
        }
        return retVal;
    }
}
