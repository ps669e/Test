package com.ibasis.aqr.itest.tools;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MidProcess {
    private static final Log logger = LogFactory.getLog(MidProcess.class);
    private MidProcessProc midProcessProc = null;

    public MidProcess() throws Exception {
        try {
            midProcessProc = new MidProcessProc();
        } catch (Exception e) {
            throw e;
        }
    }

    public void runMidProcess() throws Exception {
        try {
            int retVal = midProcessProc.midProcessProcCall();
        } catch (Exception e) {
            throw e;
        }
    }

    public static void main(String[] args) {
        try {
            MidProcess midprocess = new MidProcess();
            midprocess.runMidProcess();
        } catch (Exception e) {
            logger.error(e);
            System.exit(1);
        }
    }
}
