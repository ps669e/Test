package com.ibasis.aqr.itest.rulesengine;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibasis.aqr.itest.config.iTestConfigManager;
import com.ibasis.aqr.itest.domain.DomainConstants;
import com.ibasis.aqr.itest.domain.FloorRate;
import com.ibasis.aqr.itest.domain.ProviderCoverage;
import com.ibasis.aqr.itest.domain.ProviderRate;
import com.ibasis.aqr.itest.domain.TimeOfDay;

public class OverlappingPeriodRules {
    private static final Log logger = LogFactory.getLog(OverlappingPeriodRules.class);

    public static final int FULLY_OVERLAP = 1; // vendor's period is same as preferred route's period
    public static final int PARTIAL_OVERLAP = 2; // vendor's period overlaps some part of preferred route's period
    public static final int NO_OVERLAP = 3; // vendor's period does not overlap with preferred route's period

    private TimeOfDay[] embeddedTod;
    private double wAvgCost = DomainConstants.LARGE_DOUBLE_VALUE;
    private double wAvgMaxNetCost = DomainConstants.LARGE_DOUBLE_VALUE;

    private int overlappingStatus = FULLY_OVERLAP;

    /**
     *
     * @param lineupPeriod tod lineup TimeOfDay
     * @param floor
     * @param patRoutingChoice routing choice
     * @param isPremium do not mark vendor OOS in Premium product lineup
     */
    public OverlappingPeriodRules(TimeOfDay lineupPeriod, FloorRate floorRate, ProviderCoverage patRoutingChoice, boolean isPremium) {
        double floor = DomainConstants.LARGE_DOUBLE_VALUE;
        if (floorRate != null) {
            floor = floorRate.getFloorRate();
        }
        double cost = patRoutingChoice.getRcCostByPeriodId(lineupPeriod.getPeriodId());
        double maxNetCost = patRoutingChoice.getRcMaxNetCostByPeriodId(lineupPeriod.getPeriodId());
        wAvgCost = cost;
        wAvgMaxNetCost = maxNetCost;

        // get TimeOfDay from vendor's rate period based on lineup period
        TimeOfDay ratePeriod = null;
        if (DomainConstants.RMS_WEEKDAY_PERIOD_ID == lineupPeriod.getPeriodId()) {
            //if lineup period is WEEKDAY, since vendor-pattern rates do not have WEEKDAY,
            //we need to build a WEEKDAY TimeOfDay from rate's WEEKEND period and use it to compare to the WEEKDAY lineup
            ProviderRate weekendRate = patRoutingChoice.getProviderRateByPeriodId(DomainConstants.RMS_WEEKEND_PERIOD_ID);
            if (weekendRate != null) {
                // create a new weekday tod from weekend tod for vendor
                TimeOfDay weekend = weekendRate.getTimeOfDay();
                if (weekend != null) {
                    ratePeriod = new TimeOfDay(DomainConstants.RMS_WEEKDAY_PERIOD_ID, weekend.getEndTime(), weekend.getStartTime(), weekend.getEndWeekDay(),
                            weekend.getStartWeekDay());
                }
            }
        } else {
            ProviderRate rate = patRoutingChoice.getProviderRateByPeriodId(lineupPeriod.getPeriodId());
            if (rate != null) {
                ratePeriod = rate.getTimeOfDay();
            }
        }

        // compare current lineup period and corresponsing vendor-pattern rate period
        if (ratePeriod != null && ratePeriod.getStartTime() != null && ratePeriod.getEndTime() != null) {
            // do overlapping logic when vendor's period definition is different from preferred route's period definition
            if (lineupPeriod.compareTo(ratePeriod) != 0) {
                double overlapCost = DomainConstants.LARGE_DOUBLE_VALUE;
                double overlapNetCost = DomainConstants.LARGE_DOUBLE_VALUE;
                if (DomainConstants.RMS_PEAK_PERIOD_ID == lineupPeriod.getPeriodId()) {
                    overlapCost = patRoutingChoice.getRcCostByPeriodId(DomainConstants.RMS_OFFPEAK_PERIOD_ID);
                    overlapNetCost = patRoutingChoice.getRcMaxNetCostByPeriodId(DomainConstants.RMS_OFFPEAK_PERIOD_ID);
                } else if (DomainConstants.RMS_OFFPEAK_PERIOD_ID == lineupPeriod.getPeriodId()) {
                    overlapCost = patRoutingChoice.getRcCostByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
                    overlapNetCost = patRoutingChoice.getRcMaxNetCostByPeriodId(DomainConstants.RMS_PEAK_PERIOD_ID);
                } else if (DomainConstants.RMS_WEEKEND_PERIOD_ID == lineupPeriod.getPeriodId()) {
                    overlapCost = patRoutingChoice.getRcCostByPeriodId(DomainConstants.RMS_WEEKDAY_PERIOD_ID);
                    overlapNetCost = patRoutingChoice.getRcMaxNetCostByPeriodId(DomainConstants.RMS_WEEKDAY_PERIOD_ID);
                } else if (DomainConstants.RMS_WEEKDAY_PERIOD_ID == lineupPeriod.getPeriodId()) {
                    overlapCost = patRoutingChoice.getRcCostByPeriodId(DomainConstants.RMS_WEEKEND_PERIOD_ID);
                    overlapNetCost = patRoutingChoice.getRcMaxNetCostByPeriodId(DomainConstants.RMS_WEEKEND_PERIOD_ID);
                }

                if (DomainConstants.LARGE_DOUBLE_VALUE != overlapCost) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Lineup period " + lineupPeriod + ", Rate period " + ratePeriod + ", Floor " + floor + ", cost " + cost + ", overlapCost "
                                + overlapCost + ", maxNetCost " + maxNetCost + ", overlapNetCost " + overlapNetCost);
                    }
                    if (cost < floor && overlapCost >= floor) {
                        if (!isPremium) {
                            // only mark vendor OOS in non-premium lineup
                            this.embeddedTod = getEmbeddedTimeOfDay(lineupPeriod, ratePeriod);
                            if (logger.isDebugEnabled()) {
                                logger.debug("Embedded Time(s): " + printTods(this.embeddedTod));
                            }
                        } else {
                            // still need to call getEmbeddedTimeOfDay to determine the overlappingStatus
                            TimeOfDay[] embeddedTod = getEmbeddedTimeOfDay(lineupPeriod, ratePeriod);
                            if (logger.isDebugEnabled()) {
                                logger.debug("Embedded Time(s): " + printTods(embeddedTod));
                                logger.debug("Skip embedded time for premium lineup");
                            }
                        }
                    } else if (cost < floor && overlapCost < floor) {
                        // this local embeddedTod is used by determineWeightedAvg method
                        TimeOfDay[] embeddedTod = getEmbeddedTimeOfDay(lineupPeriod, ratePeriod);
                        if (logger.isDebugEnabled()) {
                            logger.debug("Embedded Time(s): " + printTods(embeddedTod) + ", todCost: " + wAvgCost + ", todNetCost: " + wAvgMaxNetCost);
                        }
                        if (getOverlappingStatus() != OverlappingPeriodRules.NO_OVERLAP) {
                            determineWeightedAvg(lineupPeriod, ratePeriod, embeddedTod, cost, overlapCost, maxNetCost, overlapNetCost);
                        }
                    }

                    if (getOverlappingStatus() == OverlappingPeriodRules.NO_OVERLAP) {
                        if (logger.isInfoEnabled()) {
                            logger.info("Vendor period does not overlap with lineup period! Choice:" + patRoutingChoice.getVendorId() + ", Lineup period "
                                    + lineupPeriod + ", Rate period " + ratePeriod);
                        }
                    }
                }
            }
        }
    }

    private String printTods(TimeOfDay[] tods) {
        StringBuffer todBuff = new StringBuffer();
        if (tods != null) {
            for (int i = 0; i < tods.length; i++) {
                if (tods[i] != null) {
                    todBuff.append(tods[i]).append("  ");
                }
            }
        }

        if (overlappingStatus == FULLY_OVERLAP) {
            todBuff.append(" - fully overlap");
        } else if (overlappingStatus == NO_OVERLAP) {
            todBuff.append(" - no overlap");
        }

        return todBuff.toString();
    }

    /**
     * This method computes the routing choice embedded time (embedded period is based on lineup period)
     * It also determines the overlapping status.
     *
     * @param lineupTod
     * @param rateTod
     */
    private TimeOfDay[] getEmbeddedTimeOfDay(TimeOfDay lineupTod, TimeOfDay rateTod) {
        // preferred route and vendor has same period definition
        if (lineupTod.compareTo(rateTod) == 0) {
            overlappingStatus = FULLY_OVERLAP;
            return null;
        }

        // preferred route and vendor has opposite period definition
        if (lineupTod.getStartTime().equals(rateTod.getEndTime()) && lineupTod.getEndTime().equals(rateTod.getStartTime())
                && lineupTod.getStartWeekDay() == rateTod.getEndWeekDay() && lineupTod.getEndWeekDay() == rateTod.getStartWeekDay()) {
            overlappingStatus = NO_OVERLAP;
            return null;
        }

        TimeOfDay[] embeddedTods = new TimeOfDay[2];
        if (lineupTod.getStartTimeInSeconds() == lineupTod.getAdjEndTimeInSeconds()) {
            // preferred route period covers entire day
            if (rateTod.getStartTimeInSeconds() == rateTod.getAdjEndTimeInSeconds()) {
                // vendor period also covers entire day
                overlappingStatus = FULLY_OVERLAP;
                return null;
            } else {
                overlappingStatus = PARTIAL_OVERLAP;
                embeddedTods[0] = rateTod;
                return embeddedTods;
            }
        } else {
            // preferred route period does not cover entire day
            if (rateTod.getStartTimeInSeconds() == rateTod.getAdjEndTimeInSeconds()) {
                // rate period covers entire day
                overlappingStatus = FULLY_OVERLAP;
                return null;
            }
        }

        // preferred route period and vendor period are different
        boolean isWeekendWeekday = (rateTod.getPeriodId() == DomainConstants.RMS_WEEKEND_PERIOD_ID
                || rateTod.getPeriodId() == DomainConstants.RMS_WEEKDAY_PERIOD_ID);
        int prefRouteStart = lineupTod.getStartTimeInSeconds();
        int prefRouteEnd = lineupTod.getEndTimeInSeconds();
        int prefRouteAdjEnd = lineupTod.getAdjEndTimeInSeconds();
        int rateStart = rateTod.getStartTimeInSeconds();
        int rateEnd = rateTod.getEndTimeInSeconds();
        int rateAdjEnd = rateTod.getAdjEndTimeInSeconds();

        if ((rateStart >= prefRouteStart && rateStart < prefRouteAdjEnd)
                || (rateStart + DomainConstants.ONE_DAY > prefRouteStart && rateStart + DomainConstants.ONE_DAY < prefRouteAdjEnd && !isWeekendWeekday)
                || (rateStart + DomainConstants.ONE_WEEK > prefRouteStart && rateStart + DomainConstants.ONE_WEEK < prefRouteAdjEnd && isWeekendWeekday)) {
            //rate start is between pref route start and end

            if (rateStart + DomainConstants.ONE_DAY > prefRouteStart && rateStart + DomainConstants.ONE_DAY < prefRouteAdjEnd && !isWeekendWeekday) {
                rateStart += DomainConstants.ONE_DAY;
                rateAdjEnd += DomainConstants.ONE_DAY;
            } else if (rateStart + DomainConstants.ONE_WEEK > prefRouteStart && rateStart + DomainConstants.ONE_WEEK < prefRouteAdjEnd && isWeekendWeekday) {
                rateStart += DomainConstants.ONE_WEEK;
                rateAdjEnd += DomainConstants.ONE_WEEK;
            }

            if (rateAdjEnd >= prefRouteStart) {
                if (rateAdjEnd <= prefRouteAdjEnd) {
                    if ((rateEnd > prefRouteStart && rateEnd <= prefRouteEnd) || (rateAdjEnd > prefRouteStart && rateAdjEnd <= prefRouteAdjEnd)) {
                        embeddedTods[0] = new TimeOfDay(lineupTod.getPeriodId(), rateTod.getStartTime(), rateTod.getEndTime(), rateTod.getStartWeekDay(),
                                rateTod.getEndWeekDay());
                    } else {
                        embeddedTods[0] = new TimeOfDay(lineupTod.getPeriodId(), rateTod.getStartTime(), lineupTod.getEndTime(), rateTod.getStartWeekDay(),
                                lineupTod.getEndWeekDay());
                        if (rateAdjEnd > prefRouteStart && rateAdjEnd > prefRouteAdjEnd) {
                            embeddedTods[1] = new TimeOfDay(lineupTod.getPeriodId(), lineupTod.getStartTime(), rateTod.getEndTime(),
                                    lineupTod.getStartWeekDay(), rateTod.getEndWeekDay());
                        }
                    }
                } else if (rateAdjEnd > prefRouteAdjEnd) {
                    embeddedTods[0] = new TimeOfDay(lineupTod.getPeriodId(), rateTod.getStartTime(), lineupTod.getEndTime(), rateTod.getStartWeekDay(),
                            lineupTod.getEndWeekDay());
                    //if (ratePeriodDuration > otherLineupPeriodDuration && rateEnd > prefRouteStart) {
                    if ((rateEnd > prefRouteStart && rateEnd < prefRouteAdjEnd)
                            || (rateEnd + DomainConstants.ONE_DAY > prefRouteStart && rateEnd + DomainConstants.ONE_DAY < prefRouteAdjEnd && !isWeekendWeekday)
                            || (rateEnd + DomainConstants.ONE_WEEK > prefRouteStart && rateEnd + DomainConstants.ONE_WEEK < prefRouteAdjEnd
                                    && isWeekendWeekday)) {
                        embeddedTods[1] = new TimeOfDay(lineupTod.getPeriodId(), lineupTod.getStartTime(), rateTod.getEndTime(), lineupTod.getStartWeekDay(),
                                rateTod.getEndWeekDay());
                    }
                }
            }
        } else if (rateAdjEnd > prefRouteStart && rateAdjEnd < prefRouteAdjEnd) {
            //rate start is outside of pref route start and end
            //but rate end is between pref route start and end
            if (rateStart < prefRouteAdjEnd) {
                if (rateStart >= prefRouteStart) {
                    embeddedTods[0] = new TimeOfDay(lineupTod.getPeriodId(), rateTod.getStartTime(), rateTod.getEndTime(), rateTod.getStartWeekDay(),
                            rateTod.getEndWeekDay());
                } else {
                    embeddedTods[0] = new TimeOfDay(lineupTod.getPeriodId(), lineupTod.getStartTime(), rateTod.getEndTime(), lineupTod.getStartWeekDay(),
                            rateTod.getEndWeekDay());
                }
            }
        } else if (rateEnd > prefRouteStart && rateEnd < prefRouteEnd) {
            //rate start is not between pref route start and end
            //rate end is between pref route start and end
            embeddedTods[0] = new TimeOfDay(lineupTod.getPeriodId(), lineupTod.getStartTime(), rateTod.getEndTime(), lineupTod.getStartWeekDay(),
                    rateTod.getEndWeekDay());
        } else if (rateStart <= prefRouteStart && rateAdjEnd <= prefRouteStart) {
            overlappingStatus = NO_OVERLAP;
        } else if (rateStart >= prefRouteAdjEnd && rateAdjEnd >= prefRouteAdjEnd && rateEnd > rateStart) {
            overlappingStatus = NO_OVERLAP;
        } else if (rateStart <= prefRouteStart && rateEnd >= prefRouteEnd) {
            overlappingStatus = FULLY_OVERLAP;
        } else if (rateStart >= prefRouteStart && rateEnd <= prefRouteStart) {
            overlappingStatus = NO_OVERLAP;
        } else if (rateStart >= prefRouteAdjEnd && rateAdjEnd <= prefRouteStart) {
            overlappingStatus = NO_OVERLAP;
        } else if (rateStart <= prefRouteStart && rateAdjEnd >= prefRouteAdjEnd) {
            overlappingStatus = FULLY_OVERLAP;
        } else if ((rateStart <= prefRouteStart && rateEnd >= prefRouteEnd)
                || (rateStart <= prefRouteStart + DomainConstants.ONE_DAY && rateEnd >= prefRouteEnd)) {
            overlappingStatus = FULLY_OVERLAP;
        } else {
            overlappingStatus = FULLY_OVERLAP;
        }

        if (embeddedTods != null) {
            if (embeddedTods[0] != null) {
                if (lineupTod.compareTo(embeddedTods[0]) == 0) {
                    embeddedTods[0] = null;
                    overlappingStatus = FULLY_OVERLAP;
                }
            }
        }

        if (embeddedTods != null && embeddedTods[0] != null) {
            overlappingStatus = PARTIAL_OVERLAP;
        }

        return overlappingStatus == PARTIAL_OVERLAP ? embeddedTods : null;
    }

    /**
     * Compute wAvgCost and wAvgMaxNetCost using the weighted average formula:
     *
     * L1 x (1+X%) x Net Cost L2 x Net Cost
     * ---------------------- + ------------------
     * (L1 x (1+X%) + L2) (L1 x (1+X%) + L2)
     *
     * where L1 is vendor's current period length (in seconds) within given preferred route's period
     * L2 is vendor's overlap period length (in seconds) within given preferred route's period
     * X% is TOD_WEIGHTED_AVERAGE_PER read from default_values table.
     *
     * @param lineupTod
     * @param rateTod
     * @param cost
     * @param overlapCost
     * @param maxNetCost
     * @param overlapMaxNetCost
     */
    private void determineWeightedAvg(TimeOfDay lineupTod, TimeOfDay rateTod, TimeOfDay[] embeddedTime, double cost, double overlapCost, double maxNetCost,
            double overlapMaxNetCost) {
        if (embeddedTime != null) {
            // ratePeriodLength is L1; overlapPeriodLength is L2
            // we need to get the total period duration from all embedded times
            int ratePeriodLength = 0;
            for (int i = 0; i < embeddedTime.length; i++) {
                if (embeddedTime[i] != null) {
                    ratePeriodLength += embeddedTime[i].getAdjEndTimeInSeconds() - embeddedTime[i].getStartTimeInSeconds();
                }
            }
            int prefRoutePeriodLength = lineupTod.getAdjEndTimeInSeconds() - lineupTod.getStartTimeInSeconds();
            int overlapPeriodLength = prefRoutePeriodLength - ratePeriodLength;
            if (cost != overlapCost) {
                this.wAvgCost = calculateWeightedAvg(ratePeriodLength, overlapPeriodLength, cost, overlapCost);
            }
            if (maxNetCost != overlapMaxNetCost) {
                this.wAvgMaxNetCost = calculateWeightedAvg(ratePeriodLength, overlapPeriodLength, maxNetCost, overlapMaxNetCost);
            }
        }
    }

    private double calculateWeightedAvg(int periodLength, int overlapPeriodLength, double periodCost, double overlapPeriodCost) {
        double percentage = iTestConfigManager.getInstance().getTodWeightedAvgPercentage() / 100d;
        return ((periodLength * (1 + percentage) * periodCost) / (periodLength * (1 + percentage) + overlapPeriodLength))
                + ((overlapPeriodLength * overlapPeriodCost) / (periodLength * (1 + percentage) + overlapPeriodLength));
    }

    public double getWAvgCost() {
        return wAvgCost;
    }

    public double getWAvgMaxNetCost() {
        return wAvgMaxNetCost;
    }

    public TimeOfDay getRcEmbeddedTimeOfDay() {
        TimeOfDay combinatedTod = null;
        if (embeddedTod != null) {
            if (embeddedTod[0] != null && embeddedTod[1] != null) {
                TimeOfDay first = embeddedTod[0];
                TimeOfDay second = embeddedTod[1];
                //combinatedTod = new TimeOfDay(first.getPeriodId(), second.getStartTime(), first.getEndTime(), second.getStartWeekDay(), first.getEndWeekDay());
                combinatedTod = new TimeOfDay(first.getPeriodId(), first.getStartTime(), second.getEndTime(), first.getStartWeekDay(), second.getEndWeekDay());
            } else if (embeddedTod[0] != null) {
                combinatedTod = embeddedTod[0];
            }
        }
        return combinatedTod;
    }

    public int getOverlappingStatus() {
        return overlappingStatus;
    }

    /**
     * This method is for unit test purpose
     *
     * @return
     */
    public TimeOfDay[] getEmbeddedTimeForUnitTest() {
        return embeddedTod;
    }

}
