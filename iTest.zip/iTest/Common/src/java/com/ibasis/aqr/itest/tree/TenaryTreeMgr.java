/*
 * Created on Aug 16, 2004
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package com.ibasis.aqr.itest.tree;

/**
 * Singleton Class DialPatternMgr
 *
 * @author csib
 */
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class TenaryTreeMgr {
    private static final Log logger = LogFactory.getLog(TenaryTreeMgr.class);

    public static final int TOTAL_CHILDREN = 10;

    private TenaryTreeNode[] rootNodes = new TenaryTreeNode[TenaryTreeMgr.TOTAL_CHILDREN];

    public TenaryTreeMgr() {
    }

    public TenaryTreeNode insertPattern(String dpStr, Object nodeObject) throws Exception {
        TenaryTreeNode node = null;
        try {
            int no = Character.digit(dpStr.charAt(0), 10);
            if (no >= 0) {
                if (rootNodes[no] == null) {
                    rootNodes[no] = new TenaryTreeNode(no);
                }
                node = rootNodes[no].insertPattern(1, dpStr, nodeObject);
            } else {
                String err = "Pattern " + dpStr + " has invalid chars.";
                logger.error("insertPattern(): " + err);
                throw new Exception(err);
            }
        } catch (Exception ex) {
            logger.error("insertPattern() : ", ex);
            throw ex;
        }

        return node;
    }

    public TenaryTreeNode findPattern(String dpStr) throws Exception {
        TenaryTreeNode node = null;
        try {
            TenaryTreeNode rootNode = getRootNode(dpStr);
            if (rootNode != null) {
                node = rootNode.findNode(1, dpStr);
            }
        } catch (Exception ex) {
            logger.error("findPattern() : ", ex);
            throw ex;
        }
        return node;
    }

    public TenaryTreeNode getRootNode(String dpStr) throws Exception {
        TenaryTreeNode rootNode = null;
        if (dpStr != null) {
            int no = Character.digit(dpStr.charAt(0), 10);
            if (no >= 0) {
                rootNode = rootNodes[no];
            } else {
                String err = "Pattern " + dpStr + " has invalid chars.";
                logger.error("getRootNode(): " + err);
                throw new Exception(err);
            }
        }

        return rootNode;
    }

    public void navigateAll(NodeNavigator navigator) {
        for (int i = 0; i < TenaryTreeMgr.TOTAL_CHILDREN; i++) {
            TenaryTreeNode node = rootNodes[i];
            if (node != null) {
                node.navigateNode(navigator);
            }
        }
    }

}
